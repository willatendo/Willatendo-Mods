package ca.willatendo.simplelibrary.core.registry.sub;

import ca.willatendo.simplelibrary.core.holder.SimpleHolder;
import ca.willatendo.simplelibrary.core.registry.SimpleRegistry;
import ca.willatendo.simplelibrary.core.utils.CoreUtils;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1747;
import net.minecraft.class_1749;
import net.minecraft.class_1792;
import net.minecraft.class_1822;
import net.minecraft.class_1826;
import net.minecraft.class_2248;
import net.minecraft.class_2508;
import net.minecraft.class_2551;
import net.minecraft.class_5321;
import net.minecraft.class_7707;
import net.minecraft.class_7713;
import net.minecraft.class_7715;
import net.minecraft.class_7924;
import net.minecraft.world.item.*;
import net.minecraft.world.level.block.*;

import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Supplier;

public class ItemSubRegistry extends SimpleRegistry<class_1792> {
    public ItemSubRegistry(String modId) {
        super(class_7924.field_41197, modId);
    }

    public <B extends class_2248> SimpleHolder<class_1747> registerBlock(SimpleHolder<B> block) {
        return this.registerBlock(block, class_1747::new);
    }

    public <B extends class_2248> SimpleHolder<class_1747> registerBlock(SimpleHolder<B> block, Supplier<class_1792.class_1793> properties) {
        return this.registerBlock(block, class_1747::new, properties);
    }

    public <I extends class_1792, B extends class_2248> SimpleHolder<I> registerBlock(SimpleHolder<B> block, BiFunction<B, class_1792.class_1793, I> factory) {
        return this.registerBlock(block, factory, class_1792.class_1793::new);
    }

    public <T extends class_1792, B extends class_2248> SimpleHolder<T> registerBlock(SimpleHolder<B> block, BiFunction<B, class_1792.class_1793, T> factory, Supplier<class_1792.class_1793> properties) {
        return this.registerItem(block.getIdentifier().method_12832(), propertiesIn -> factory.apply(block.get(), propertiesIn), properties.get()::method_63685);
    }

    public <SB extends class_2508, WB extends class_2551> SimpleHolder<class_1822> registerSign(SimpleHolder<SB> signBlock, SimpleHolder<WB> wallSign) {
        return this.registerBlock(signBlock, (block, properties) -> new class_1822(block, wallSign.get(), properties), () -> new class_1792.class_1793().method_7889(16));
    }

    public <CB extends class_7713, WB extends class_7715> SimpleHolder<class_7707> registerHangingSign(SimpleHolder<CB> hangingSignBlock, SimpleHolder<WB> hangingWallSign) {
        return this.registerBlock(hangingSignBlock, (block, properties) -> new class_7707(block, hangingWallSign.get(), properties), () -> new class_1792.class_1793().method_7889(16));
    }

    public SimpleHolder<class_1749> registerBoat(String name, Function<class_1792.class_1793, class_1749> boatItem) {
        return this.registerItem(name, boatItem, () -> new class_1792.class_1793().method_7889(1));
    }

    public SimpleHolder<class_1749> registerChestBoat(String name, Function<class_1792.class_1793, class_1749> boatItem) {
        return this.registerItem(name, boatItem, new class_1792.class_1793().method_7889(1));
    }

    public <T extends class_1297> SimpleHolder<class_1826> registerSpawnEgg(String name, SimpleHolder<class_1299<T>> entityType) {
        return this.registerItem(name, class_1826::new, () -> new class_1792.class_1793().method_72499(entityType.get()));
    }

    public SimpleHolder<class_1792> registerItem(String name) {
        return this.registerItem(name, new class_1792.class_1793());
    }

    public SimpleHolder<class_1792> registerItem(String name, class_1792.class_1793 properties) {
        return this.registerItem(name, () -> properties);
    }

    public SimpleHolder<class_1792> registerItem(String name, Supplier<class_1792.class_1793> properties) {
        return this.registerItem(name, class_1792::new, properties);
    }

    public <T extends class_1792> SimpleHolder<T> registerItem(String name, Function<class_1792.class_1793, T> item) {
        return this.registerItem(name, item, new class_1792.class_1793());
    }

    public <T extends class_1792> SimpleHolder<T> registerItem(String name, Function<class_1792.class_1793, T> item, class_1792.class_1793 properties) {
        return this.registerItem(name, item, () -> properties);
    }

    public <T extends class_1792> SimpleHolder<T> registerItem(String name, Function<class_1792.class_1793, T> item, Supplier<class_1792.class_1793> properties) {
        class_5321<class_1792> id = class_5321.method_29179(this.registryKey, CoreUtils.resource(this.modId, name));
        return this.register(name, () -> item.apply(properties.get().method_63686(id)));
    }

    public class_5321<class_1792> reference(String name) {
        return class_5321.method_29179(this.registryKey, CoreUtils.resource(this.modId, name));
    }
}
