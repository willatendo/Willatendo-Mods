package ca.willatendo.simplelibrary.core.registry.sub;

import ca.willatendo.simplelibrary.core.holder.SimpleHolder;
import ca.willatendo.simplelibrary.core.registry.SimpleRegistry;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.serialization.Codec;
import net.minecraft.class_11845;
import net.minecraft.class_12279;
import net.minecraft.class_1928;
import net.minecraft.class_2378;
import net.minecraft.class_4311;
import net.minecraft.class_5198;
import net.minecraft.class_5321;
import net.minecraft.class_7699;
import net.minecraft.class_7924;
import net.minecraft.world.level.gamerules.*;

import java.util.function.ToIntFunction;

public class GameRuleSubRegistry extends SimpleRegistry<class_12279<?>> {
    public GameRuleSubRegistry(class_5321<? extends class_2378<class_12279<?>>> registryKey, String modId) {
        super(class_7924.field_64253, modId);
    }

    public SimpleHolder<class_12279<Integer>> registerInteger(String name, class_5198 gameRuleCategory, int defaultValue, int min) {
        return this.registerInteger(name, gameRuleCategory, defaultValue, min, Integer.MAX_VALUE, class_7699.method_45397());
    }

    public SimpleHolder<class_12279<Integer>> registerInteger(String name, class_5198 gameRuleCategory, int defaultValue, int min, int max) {
        return this.registerInteger(name, gameRuleCategory, defaultValue, min, max, class_7699.method_45397());
    }

    public SimpleHolder<class_12279<Integer>> registerInteger(String name, class_5198 gameRuleCategory, int defaultValue, int min, int max, class_7699 featureFlagSet) {
        return this.register(name, gameRuleCategory, class_11845.field_62399, IntegerArgumentType.integer(min, max), Codec.intRange(min, max), defaultValue, featureFlagSet, class_4311::method_27330, i -> i);
    }

    private SimpleHolder<class_12279<Boolean>> registerBoolean(String name, class_5198 gameRuleCategory, boolean defaultValue) {
        return this.register(name, gameRuleCategory, class_11845.field_62400, BoolArgumentType.bool(), Codec.BOOL, defaultValue, class_7699.method_45397(), class_4311::method_27329, p_460985_ -> p_460985_ ? 1 : 0);
    }

    public <T> SimpleHolder<class_12279<T>> register(String name, class_5198 gameRuleCategory, class_11845 gameRuleType, ArgumentType<T> argumentType, Codec<T> codec, T defaultValue, class_7699 featureFlagSet, class_1928.class_5199<T> visitorCaller, ToIntFunction<T> commandResultFunction) {
        return this.register(name, () -> new class_12279<>(gameRuleCategory, gameRuleType, argumentType, visitorCaller, codec, commandResultFunction, defaultValue, featureFlagSet));
    }
}
