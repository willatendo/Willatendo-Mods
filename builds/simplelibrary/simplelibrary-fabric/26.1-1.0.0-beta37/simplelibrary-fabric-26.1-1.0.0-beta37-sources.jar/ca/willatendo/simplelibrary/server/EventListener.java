package ca.willatendo.simplelibrary.server;

import ca.willatendo.simplelibrary.core.utils.CoreUtils;
import ca.willatendo.simplelibrary.server.command.CommandRegisterInformation;
import com.google.common.collect.Lists;
import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.Codec;
import net.minecraft.class_10287;
import net.minecraft.class_10355;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1317;
import net.minecraft.class_1538;
import net.minecraft.class_2358;
import net.minecraft.class_2378;
import net.minecraft.class_2902;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3264;
import net.minecraft.class_3302;
import net.minecraft.class_3781;
import net.minecraft.class_3784;
import net.minecraft.class_3785;
import net.minecraft.class_3852;
import net.minecraft.class_3853;
import net.minecraft.class_4158;
import net.minecraft.class_5132;
import net.minecraft.class_5321;
import net.minecraft.class_5350;
import net.minecraft.class_5352;
import net.minecraft.class_5497;
import net.minecraft.class_6880;
import net.minecraft.class_7924;
import net.minecraft.class_9168;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.entity.*;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

public interface EventListener {
    default void commonSetup() {
    }

    // Registry

    default void registerAttributes(EventListener.AttributeRegister attributeRegister) {
    }

    default void registerBuiltInResourcePacks(EventListener.BuiltInResourcePackRegister builtInResourcePackRegister) {
    }

    default void registerCommands(EventListener.CommandRegister commandRegister) {
    }

    default void registerDynamicRegistries(EventListener.DynamicRegistryRegister dynamicRegistryRegister) {
    }

    default void registerNewRegistries(EventListener.NewRegistryRegister newRegistryRegister) {
    }

    default void registerPOI(EventListener.POIRegister poiRegister) {
    }

    default void registerRecipeBookSearchCategory(EventListener.RecipeBookSearchCategoryRegister recipeBookSearchCategoryRegister) {
    }

    default void registerServerReloadListener(EventListener.ServerReloadListenerRegister serverReloadListenerRegister) {
    }

    default void registerSpawnPlacements(EventListener.SpawnPlacementRegister spawnPlacementRegister) {
    }

    // Modification

    default void modifyFlammables(class_2358 fireBlock) {
    }

    default void modifyStructurePools(EventListener.StructurePoolModification structurePoolModification) {
    }

    default void modifyVillagerTrades(EventListener.VillagerTradeModification villagerTradeModification) {
    }

    // Events
    default void preEntityTickEvent(class_1297 entity) {
    }

    default void postEntityTickEvent(class_1297 entity) {
    }

    default void entityStruckByLightningBoltEvent(class_1297 entity, class_1538 lightningBolt, Consumer<Boolean> cancel) {
    }

    default void syncDataPackContentsEvent(class_3222 serverPlayer) {
    }

    default void serverAboutToStartEvent(MinecraftServer minecraftServer) {
    }

    default void serverStoppedEvent(MinecraftServer minecraftServer) {
    }

    // Registry

    @FunctionalInterface
    interface AttributeRegister {
        <T extends class_1309> void apply(class_1299<T> entityType, class_5132 attributeSupplier);
    }

    @FunctionalInterface
    interface BuiltInResourcePackRegister {
        void apply(String modId, String resourcePackName, class_3264 packType, class_5352 packSource);
    }

    @FunctionalInterface
    interface CommandRegister {
        void apply(CommandRegisterInformation commandRegisterInformation);
    }

    interface DynamicRegistryRegister {
        <T> void apply(class_5321<class_2378<T>> resourceKey, Codec<T> codec);

        <T> void apply(class_5321<class_2378<T>> resourceKey, Codec<T> codec, Codec<T> networkCodec);
    }

    @FunctionalInterface
    interface NewRegistryRegister {
        <T> void apply(class_2378<T> registry);
    }

    @FunctionalInterface
    interface POIRegister {
        Supplier<class_4158> apply(String id, Supplier<class_4158> poiType);
    }

    @FunctionalInterface
    interface RecipeBookSearchCategoryRegister {
        void register(class_10287 extendedRecipeBookCategory, class_10355[] recipeBookCategories);
    }

    interface ServerReloadListenerRegister {
        <T extends class_3302> T apply(class_2960 identifier, T preparableReloadListener);

        class_5350 getServerResources();
    }

    @FunctionalInterface
    interface SpawnPlacementRegister {
        <T extends class_1308> void apply(class_1299<T> entityType, class_9168 spawnPlacementType, class_2902.class_2903 types, class_1317.class_4306<T> spawnPredicate);
    }

    // Modification

    interface StructurePoolModification {
        class_5321<class_5497> EMPTY_PROCESSOR_LIST_KEY = class_5321.method_29179(class_7924.field_41247, CoreUtils.minecraft("empty"));

        class_2378<class_3785> getTemplatePoolRegistry();

        class_2378<class_5497> getProcessorListRegistry();

        default class_2960 getPlainsPoolLocation() {
            return CoreUtils.minecraft("village/plains/houses");
        }

        default class_2960 getDesertPoolLocation() {
            return CoreUtils.minecraft("village/desert/houses");
        }

        default class_2960 getSavannaPoolLocation() {
            return CoreUtils.minecraft("village/savanna/houses");
        }

        default class_2960 getSnowyPoolLocation() {
            return CoreUtils.minecraft("village/snowy/houses");
        }

        default class_2960 getTaigaPoolLocation() {
            return CoreUtils.minecraft("village/taiga/houses");
        }

        default void add(class_2378<class_3785> templatePoolRegistry, class_2378<class_5497> processorListRegistry, class_2960 poolRL, String nbtPieceRL, int weight) {
            class_6880.class_6883<class_5497> empty = processorListRegistry.method_46747(EMPTY_PROCESSOR_LIST_KEY);

            class_3785 structureTemplatePool = templatePoolRegistry.method_63535(poolRL);
            if (structureTemplatePool == null) {
                return;
            }

            class_3781 singlePoolElement = class_3781.method_30435(nbtPieceRL, empty).apply(class_3785.class_3786.field_16687);

            for (int i = 0; i < weight; i++) {
                structureTemplatePool.field_16680.add(singlePoolElement);
            }

            List<Pair<class_3784, Integer>> listOfPieceEntries = Lists.newArrayList(structureTemplatePool.field_16864.iterator());
            listOfPieceEntries.add(new Pair<>(singlePoolElement, weight));
            structureTemplatePool.field_16864 = listOfPieceEntries;
        }
    }

    @FunctionalInterface
    interface VillagerTradeModification {
        void apply(class_5321<class_3852> villagerProfession, List<class_3853.class_1652> level1Trades, List<class_3853.class_1652> level2Trades, List<class_3853.class_1652> level3Trades, List<class_3853.class_1652> level4Trades, List<class_3853.class_1652> level5Trades);
    }
}
