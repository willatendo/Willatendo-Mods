package ca.willatendo.simplelibrary.client;

import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.MapCodec;
import java.util.List;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Supplier;
import net.minecraft.class_10295;
import net.minecraft.class_10352;
import net.minecraft.class_10515;
import net.minecraft.class_11697;
import net.minecraft.class_11939;
import net.minecraft.class_11954;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1703;
import net.minecraft.class_2248;
import net.minecraft.class_2394;
import net.minecraft.class_2396;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_322;
import net.minecraft.class_3302;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_3917;
import net.minecraft.class_3929;
import net.minecraft.class_3936;
import net.minecraft.class_437;
import net.minecraft.class_508;
import net.minecraft.class_5601;
import net.minecraft.class_5607;
import net.minecraft.class_5614;
import net.minecraft.class_5617;
import net.minecraft.class_707;

public interface ClientEventListener {
    default void clientSetup() {
    }

    // Registry

    default void registerBlockColors(ClientEventListener.BlockColorRegister blockColorRegister) {
    }

    default void registerClientReloadListener(ClientReloadListenerRegister clientReloadListenerRegister) {
    }

    default void registerKeyMappings(ClientEventListener.KeyMappingRegister keyMappingRegister) {
    }

    default void registerMenuScreens(ClientEventListener.MenuScreenRegister menuScreenRegister) {
    }

    default void registerLayerDefinitions(ClientEventListener.LayerDefinitionRegister layerDefinitionRegister) {
    }

    default void registerRenderers(ClientEventListener.RendererRegister rendererRegister) {
    }

    default void registerRecipeBookOverlay(ClientEventListener.RecipeBookOverlayRegister recipeBookOverlayRegister) {
    }

    default void registerParticleColorExemptions(ClientEventListener.ParticleColorExemptionRegister particleColorExemptionRegister) {
    }

    default void registerParticleProviders(ClientEventListener.ParticleProviderRegister particleProviderRegister) {
    }

    default void registerSpecialModelRenderers(ClientEventListener.SpecialModelRendererRegister specialModelRendererRegister) {
    }

    default void registerTextureAtlases(ClientEventListener.TextureAtlasRegister textureAtlasRegister) {
    }

    // Events

    default void screenInitPreEvent(class_437 screen, Consumer<class_339> widgets) {
    }

    default void screenInitPostEvent(class_437 screen, Consumer<class_339> widgets) {
    }

    default void screenRenderPreEvent(class_437 screen, class_332 guiGraphics, int mouseX, int mouseY) {
    }

    default void screenRenderPostEvent(class_437 screen, class_332 guiGraphics, int mouseX, int mouseY) {
    }

    default void screenCloseEvent(class_437 screen) {
    }

    default void clientPlayerLoggingOut() {
    }

    @FunctionalInterface
    interface BlockColorRegister {
        void apply(class_322 blockColor, class_2248... blocks);
    }

    @FunctionalInterface
    interface ClientReloadListenerRegister {
        void apply(class_2960 identifier, class_3302 preparableReloadListener);
    }

    @FunctionalInterface
    interface KeyMappingRegister {
        void apply(class_304 keyMapping);
    }

    @FunctionalInterface
    interface MenuScreenRegister {
        <M extends class_1703, U extends class_437 & class_3936<M>> void apply(class_3917<? extends M> menuType, class_3929.class_3930<M, U> screenConstructor);
    }

    @FunctionalInterface
    interface LayerDefinitionRegister {
        void apply(class_5601 modelLayerLocation, Supplier<class_5607> layerDefinition);
    }

    interface RendererRegister {
        <T extends class_1297> void apply(class_1299<? extends T> entityType, class_5617<T> entityRendererProvider);

        <T extends class_2586, S extends class_11954> void apply(class_2591<? extends T> blockEntityType, class_5614<T, S> blockEntityRendererProvider);
    }

    @FunctionalInterface
    interface RecipeBookOverlayRegister {
        void apply(class_2960 identifier, Pair<BiFunction<class_10295, class_10352, List<class_508.class_509.class_510>>, BiFunction<Boolean, Boolean, class_2960>> pair);
    }

    @FunctionalInterface
    interface ParticleColorExemptionRegister {
        void apply(class_2248... blocks);
    }

    interface ParticleProviderRegister {
        <T extends class_2394> void apply(class_2396<T> particleType, class_707<T> particleFactory);

        <T extends class_2394> void apply(class_2396<T> particleType, class_707.class_8187<T> sprite);

        <T extends class_2394> void apply(class_2396<T> particleType, class_11939.class_4091<T> particleMetaFactory);
    }

    @FunctionalInterface
    interface SpecialModelRendererRegister {
        void apply(class_2960 id, MapCodec<? extends class_10515.class_10516> codec);
    }

    @FunctionalInterface
    interface TextureAtlasRegister {
        void apply(class_11697.class_11698 atlasConfig);
    }
}
