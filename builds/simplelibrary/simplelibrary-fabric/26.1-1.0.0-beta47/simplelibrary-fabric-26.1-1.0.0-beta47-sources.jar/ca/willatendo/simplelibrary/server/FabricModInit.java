package ca.willatendo.simplelibrary.server;

import ca.willatendo.simplelibrary.core.registry.RegisterFunction;
import ca.willatendo.simplelibrary.core.registry.SimpleRegistry;
import ca.willatendo.simplelibrary.core.registry.sub.AttachmentTypesSubRegistry;
import ca.willatendo.simplelibrary.core.registry.sub.EntityDataSerializerSubRegistry;
import ca.willatendo.simplelibrary.core.utils.CoreUtils;
import ca.willatendo.simplelibrary.network.PacketRegistryListener;
import ca.willatendo.simplelibrary.network.PacketSupplier;
import ca.willatendo.simplelibrary.server.event.AddReloadListenersEvent;
import ca.willatendo.simplelibrary.server.event.EntityTickEvent;
import ca.willatendo.simplelibrary.server.event.LightingBoltEvent;
import ca.willatendo.simplelibrary.server.event.RegisterRecipeBookSearchCategoriesEvent;
import ca.willatendo.simplelibrary.server.utils.WrappedStateAwareListener;
import com.mojang.serialization.Codec;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.registry.DynamicRegistries;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.world.poi.PoiHelper;
import net.fabricmc.fabric.api.resource.v1.pack.PackActivationType;
import net.fabricmc.fabric.impl.resource.ResourceLoaderImpl;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.ReloadableServerResources;
import net.minecraft.server.packs.PackType;
import net.minecraft.server.packs.resources.PreparableReloadListener;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.flag.FeatureFlagSet;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.FireBlock;
import net.minecraft.world.level.levelgen.structure.pools.StructureTemplatePool;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureProcessorList;

import java.util.Arrays;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Supplier;

public record FabricModInit(String modId) implements ModInit {
    @Override
    public void register(SimpleRegistry<?>... simpleRegistries) {
        Arrays.stream(simpleRegistries).forEach(simpleRegistry -> simpleRegistry.addEntries(new RegisterFunction() {
            @Override
            public <T> void register(ResourceKey<? extends Registry<T>> registryKey, Identifier identifier, Supplier<T> value) {
                Registry.register((Registry<T>) BuiltInRegistries.REGISTRY.getValue(registryKey.identifier()), identifier, value.get());
            }
        }));
    }

    @Override
    public void register(EntityDataSerializerSubRegistry entityDataSerializerSubRegistry) {
    }

    @Override
    public void register(AttachmentTypesSubRegistry attachmentTypesSubRegistry) {
    }

    @Override
    public void eventListener(EventListener eventListener) {
        eventListener.commonSetup();

        // Registry

        eventListener.registerAttributes(FabricDefaultAttributeRegistry::register);

        Event<CommandRegistrationCallback> event = CommandRegistrationCallback.EVENT;
        event.register((commandDispatcher, commandBuildContext, commandSelection) -> eventListener.registerCommands(commandRegisterInformation -> commandRegisterInformation.register(commandDispatcher, commandBuildContext, commandSelection)));

        eventListener.registerDynamicRegistries(new EventListener.DynamicRegistryRegister() {
            @Override
            public <T> void apply(ResourceKey<Registry<T>> resourceKey, Codec<T> codec) {
                DynamicRegistries.register(resourceKey, codec);
            }

            @Override
            public <T> void apply(ResourceKey<Registry<T>> resourceKey, Codec<T> codec, Codec<T> networkCodec) {
                DynamicRegistries.registerSynced(resourceKey, codec, networkCodec);
            }
        });

        eventListener.registerNewRegistries(new EventListener.NewRegistryRegister() {
            @Override
            public <T> void apply(Registry<T> registry) {
            }
        });

        eventListener.registerPOI((id, poiType) -> {
            PoiHelper.register(CoreUtils.resource(this.modId, id), poiType.get().maxTickets(), poiType.get().validRange(), poiType.get().matchingStates());
            return poiType;
        });

        RegisterRecipeBookSearchCategoriesEvent.EVENT.register(biConsumer -> eventListener.registerRecipeBookSearchCategory((extendedRecipeBookCategory, recipeBookCategories) -> biConsumer.accept(extendedRecipeBookCategory, Arrays.asList(recipeBookCategories))));

        eventListener.registerBuiltInResourcePacks((modId, resourcePackName, packType, packSource, alwaysActive, position) -> {
            Optional<ModContainer> modContainer = FabricLoader.getInstance().getModContainer(modId);
            boolean datapack = packType == PackType.SERVER_DATA;
            Identifier identifier = CoreUtils.resource(modId, resourcePackName);
            ResourceLoaderImpl.registerBuiltinPack(identifier, (datapack ? "data/" + modId + "/datapacks/" : "resourcepacks/") + identifier.getPath(), modContainer.get(), CoreUtils.translation((datapack ? "dataPack" : "resourcePack"), modId, resourcePackName + ".name"), alwaysActive ? PackActivationType.ALWAYS_ENABLED : PackActivationType.NORMAL);
        });

        AddReloadListenersEvent.EVENT.register((preparableReloadListeners, context, reloadableServerResources) -> eventListener.registerServerReloadListener(new EventListener.ServerReloadListenerRegister() {
            @Override
            public <T extends PreparableReloadListener> T apply(Identifier identifier, T preparableReloadListener) {
                preparableReloadListeners.add(new WrappedStateAwareListener(identifier, preparableReloadListener));
                return preparableReloadListener;
            }

            @Override
            public ReloadableServerResources getServerResources() {
                return reloadableServerResources;
            }
        }));

        eventListener.registerSpawnPlacements(SpawnPlacements::register);

        // Modification

        eventListener.modifyFlammables((FireBlock) Blocks.FIRE);

        // Events
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> eventListener.playerEntityInteractEvent(entity, player));

        EntityTickEvent.PRE.register(eventListener::preEntityTickEvent);

        EntityTickEvent.POST.register(eventListener::postEntityTickEvent);

        LightingBoltEvent.ENTITY_STRUCK_BY_LIGHTING.register((entity, lightningBolt) -> {
            AtomicBoolean cancel = new AtomicBoolean(false);
            eventListener.entityStruckByLightningBoltEvent(entity, lightningBolt, cancel::set);
            return cancel.get();
        });

        ServerLifecycleEvents.END_DATA_PACK_RELOAD.register((minecraftServer, closeableResourceManager, success) -> eventListener.dataReloadEvent(minecraftServer));

        ServerLifecycleEvents.SYNC_DATA_PACK_CONTENTS.register((serverPlayer, joined) -> eventListener.syncDataPackContentsEvent(serverPlayer));

        for (ResourceKey<CreativeModeTab> resourceKey : BuiltInRegistries.CREATIVE_MODE_TAB.registryKeySet()) {
            CreativeModeTabEvents.modifyOutputEvent(resourceKey).register(fabricCreativeModeTabOutput -> {
                eventListener.modifyCreativeModeTabs(new EventListener.CreativeModeTabModification() {
                    @Override
                    public ResourceKey<CreativeModeTab> getCreativeModeTabKey() {
                        return resourceKey;
                    }

                    @Override
                    public CreativeModeTab.ItemDisplayParameters getItemDisplayParameters() {
                        return fabricCreativeModeTabOutput.getContext();
                    }

                    @Override
                    public FeatureFlagSet getEnabledFeatureFlags() {
                        return fabricCreativeModeTabOutput.getEnabledFeatures();
                    }

                    @Override
                    public boolean hasOperatorPermissions() {
                        return fabricCreativeModeTabOutput.shouldShowOpRestrictedItems();
                    }

                    @Override
                    public void remove(ItemStack itemStack, CreativeModeTab.TabVisibility tabVisibility) {
                    }

                    @Override
                    public void insert(ItemStack itemStack, CreativeModeTab.TabVisibility tabVisibility) {
                        fabricCreativeModeTabOutput.accept(itemStack, tabVisibility);
                    }

                    @Override
                    public void insertBeginning(ItemStack itemStack, CreativeModeTab.TabVisibility tabVisibility) {
                        fabricCreativeModeTabOutput.prepend(itemStack, tabVisibility);
                    }

                    @Override
                    public void insertAfter(ItemStack referenceItemStack, CreativeModeTab.TabVisibility tabVisibility, ItemStack... itemStacks) {
                        fabricCreativeModeTabOutput.insertAfter(referenceItemStack, Arrays.asList(itemStacks), tabVisibility);
                    }

                    @Override
                    public void insertBefore(ItemStack referenceItemStack, CreativeModeTab.TabVisibility tabVisibility, ItemStack... itemStacks) {
                        fabricCreativeModeTabOutput.insertBefore(referenceItemStack, Arrays.asList(itemStacks), tabVisibility);
                    }
                });
            });
        }


        ServerLifecycleEvents.SERVER_STARTING.register(minecraftServer -> {
            eventListener.serverAboutToStartEvent(minecraftServer);

            eventListener.modifyStructurePools(new EventListener.StructurePoolModification() {
                @Override
                public Registry<StructureTemplatePool> getTemplatePoolRegistry() {
                    return minecraftServer.registryAccess().lookupOrThrow(Registries.TEMPLATE_POOL);
                }

                @Override
                public Registry<StructureProcessorList> getProcessorListRegistry() {
                    return minecraftServer.registryAccess().lookupOrThrow(Registries.PROCESSOR_LIST);
                }
            });
        });

        ServerLifecycleEvents.SERVER_STOPPED.register(eventListener::serverStoppedEvent);
    }

    @Override
    public void packetRegistryListener(PacketRegistryListener packetRegistryListener) {
        packetRegistryListener.registerServerboundPackets(new PacketRegistryListener.ServerboundPacketRegister() {
            @Override
            public <T extends CustomPacketPayload> void apply(CustomPacketPayload.Type<T> type, StreamCodec<? super RegistryFriendlyByteBuf, T> codec, PacketSupplier<T> packetSupplier) {
                PayloadTypeRegistry.serverboundPlay().register(type, codec);

                ServerPlayNetworking.registerGlobalReceiver(type, (customPacketPayload, context) -> packetSupplier.handle(customPacketPayload, context.player()));
            }
        });
    }
}
