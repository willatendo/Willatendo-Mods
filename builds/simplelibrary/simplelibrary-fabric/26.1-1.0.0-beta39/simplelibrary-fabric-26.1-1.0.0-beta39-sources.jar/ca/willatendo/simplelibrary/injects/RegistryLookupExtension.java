package ca.willatendo.simplelibrary.injects;

import ca.willatendo.simplelibrary.server.data_maps.DataMapType;
import java.util.Map;
import net.minecraft.class_5321;

public interface RegistryLookupExtension<T> {
    default void clearData() {
        throw new RuntimeException("This has not been registered correctly! " + this.getClass());
    }

    default <A> Map<class_5321<T>, A> getDataMap(DataMapType<T, A> dataMapType) {
        throw new RuntimeException("This has not been registered correctly! " + this.getClass());
    }

    default <A> void putData(DataMapType<T, A> type, Map<class_5321<T>, A> map) {
        throw new RuntimeException("This has not been registered correctly! " + this.getClass());
    }

    default <A> A getData(DataMapType<T, A> type, class_5321<T> key) {
        throw new RuntimeException("This has not been registered correctly! " + this.getClass());
    }
}
