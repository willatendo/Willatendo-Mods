package ca.willatendo.simplelibrary.mixin;

import ca.willatendo.simplelibrary.server.data_maps.SimpleLibraryDataMaps;
import ca.willatendo.simplelibrary.server.data_maps.buillt_in.VibrationFrequency;
import net.minecraft.class_5712;
import net.minecraft.class_6880;
import net.minecraft.class_8514;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_8514.class)
public interface VibrationSystemMixin {
    @Inject(at = @At("HEAD"), method = "getGameEventFrequency", cancellable = true)
    private static void getGameEventFrequency(class_6880<class_5712> gameEvent, CallbackInfoReturnable<Integer> cir) {
        VibrationFrequency vibrationFrequency = (VibrationFrequency) gameEvent.getData(SimpleLibraryDataMaps.VIBRATION_FREQUENCIES);
        if (vibrationFrequency != null) {
            cir.setReturnValue(vibrationFrequency.frequency());
        }
    }
}
