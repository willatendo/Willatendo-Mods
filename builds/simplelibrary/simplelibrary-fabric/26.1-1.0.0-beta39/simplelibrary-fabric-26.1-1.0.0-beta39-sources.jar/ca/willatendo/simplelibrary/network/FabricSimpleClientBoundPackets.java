package ca.willatendo.simplelibrary.network;

import ca.willatendo.simplelibrary.network.clientbound.ClientboundCustomRecipeBookSettingsPacket;
import ca.willatendo.simplelibrary.network.clientbound.ClientboundRecipeContentPacket;
import ca.willatendo.simplelibrary.server.recipe.SyncedRecipeData;
import net.minecraft.class_10289;
import net.minecraft.class_1657;
import net.minecraft.class_299;
import net.minecraft.class_310;
import net.minecraft.class_518;
import net.minecraft.class_746;

public final class FabricSimpleClientBoundPackets {
    private FabricSimpleClientBoundPackets() {
    }

    public static void clientboundCustomRecipeBookSettingsPacket(ClientboundCustomRecipeBookSettingsPacket clientboundCustomRecipeBookSettingsPacket, class_1657 player) {
        if (player instanceof class_746 localPlayer) {
            class_310 minecraft = class_310.method_1551();
            class_299 clientRecipeBook = localPlayer.method_3130();
            clientRecipeBook.method_30174(clientboundCustomRecipeBookSettingsPacket.recipeBookSettings());
            clientRecipeBook.setCustomBookSettings(clientboundCustomRecipeBookSettingsPacket.customRecipeBookSettings());
            clientRecipeBook.method_64853();
            minecraft.method_1562().method_60347().method_60352(clientRecipeBook, minecraft.field_1687);
            if (minecraft.field_1755 instanceof class_518 recipeupdatelistener) {
                recipeupdatelistener.method_16891();
            }
        }
    }

    public static void clientboundRecipeContentPacket(ClientboundRecipeContentPacket clientboundRecipeContentPacket, class_1657 player) {
        SyncedRecipeData.addRecipes(class_10289.method_64700(clientboundRecipeContentPacket.recipes()));
    }
}
