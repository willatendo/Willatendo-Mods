package ca.willatendo.simplelibrary.server.data_maps;

import com.mojang.datafixers.util.Either;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import java.util.Optional;
import net.minecraft.class_2378;
import net.minecraft.class_5321;
import net.minecraft.class_6862;

// Modified from Neoforge
@FunctionalInterface
public interface DataMapValueRemover<R, T> {
    Optional<T> remove(T value, class_2378<R> registry, Either<class_6862<R>, class_5321<R>> source, R object);

    class Default<T, R> implements DataMapValueRemover<R, T> {
        public static final Default<?, ?> INSTANCE = new Default<>();

        public static <T, R> Default<T, R> defaultRemover() {
            return (Default<T, R>) INSTANCE;
        }

        public static <T, R> Codec<Default<T, R>> codec() {
            return MapCodec.unitCodec(defaultRemover());
        }

        private Default() {}

        @Override
        public Optional<T> remove(T value, class_2378<R> registry, Either<class_6862<R>, class_5321<R>> source, R object) {
            return Optional.empty();
        }
    }
}
