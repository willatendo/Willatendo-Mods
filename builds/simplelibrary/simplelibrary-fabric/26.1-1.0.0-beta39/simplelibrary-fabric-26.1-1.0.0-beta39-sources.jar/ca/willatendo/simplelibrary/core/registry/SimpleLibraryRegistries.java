package ca.willatendo.simplelibrary.core.registry;

import ca.willatendo.simplelibrary.core.utils.CoreUtils;
import ca.willatendo.simplelibrary.server.biome_modifier.BiomeModifier;
import ca.willatendo.simplelibrary.server.conditions.ICondition;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_2378;
import net.minecraft.class_5321;

public final class SimpleLibraryRegistries {
    public static final class_5321<class_2378<BiomeModifier>> BIOME_MODIFIERS = SimpleLibraryRegistries.neoforgeKey("biome_modifier");
    public static final class_5321<class_2378<MapCodec<? extends BiomeModifier>>> BIOME_MODIFIER_SERIALIZERS = SimpleLibraryRegistries.neoforgeKey("biome_modifier_serializers");
    public static final class_5321<class_2378<MapCodec<? extends ICondition>>> CONDITION_CODECS = SimpleLibraryRegistries.neoforgeKey("condition_codecs");

    private static <T> class_5321<class_2378<T>> neoforgeKey(String name) {
        return class_5321.method_29180(CoreUtils.resource("neoforge", name));
    }
}
