package ca.willatendo.simplelibrary.server.biome_modifier;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2893;
import net.minecraft.class_2922;
import net.minecraft.class_5485;
import net.minecraft.class_6796;
import net.minecraft.class_6880;

// Modified from Neoforge
public final class BiomeGenerationSettingsBuilder extends class_5485.class_7868 {
    public BiomeGenerationSettingsBuilder(class_5485 biomeGenerationSettings) {
        biomeGenerationSettings.method_30976().forEach(this.getCarvers()::add);
        biomeGenerationSettings.method_30983().forEach(placedFeatureHolder -> {
            final ArrayList<class_6880<class_6796>> featureList = new ArrayList<>();
            placedFeatureHolder.forEach(featureList::add);
            this.field_40897.add(featureList);
        });
    }

    public List<class_6880<class_6796>> getFeatures(class_2893.class_2895 decoration) {
        this.method_46672(decoration.ordinal());
        return this.field_40897.get(decoration.ordinal());
    }

    public List<class_6880<class_2922<?>>> getCarvers() {
        return this.field_40896;
    }
}
