package ca.willatendo.simplelibrary.server.conditions;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7924;

// Modified from Neoforge
public record RegisteredCondition<T>(class_5321<T> registryKey) implements ICondition {
    public static final MapCodec<RegisteredCondition<?>> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(class_2960.field_25139.optionalFieldOf("registry", class_7924.field_41197.method_29177()).forGetter(condition -> condition.registryKey().method_41185()), class_2960.field_25139.fieldOf("value").forGetter(condition -> condition.registryKey().method_29177())).apply(instance, RegisteredCondition::new));

    private RegisteredCondition(class_2960 registryType, class_2960 registryName) {
        this(class_5321.method_29179(class_5321.method_29180(registryType), registryName));
    }

    @Override
    public boolean test(IContext context) {
        return context.registryAccess().holder(this.registryKey).map(class_6880::method_40227).orElse(false);
    }

    @Override
    public MapCodec<? extends ICondition> codec() {
        return CODEC;
    }
}
