package ca.willatendo.simplelibrary.client.filter;

import ca.willatendo.simplelibrary.core.utils.SimpleCoreUtils;
import net.minecraft.class_10799;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_5244;
import net.minecraft.class_9848;

public class ArrowButton extends class_4185 {
    public static final class_2960 ARROW_UP = SimpleCoreUtils.resource("textures/gui/arrow_up.png");
    public static final class_2960 ARROW_DOWN = SimpleCoreUtils.resource("textures/gui/arrow_down.png");

    private final boolean up;

    public ArrowButton(int x, int y, boolean up, class_4241 onPress) {
        super(x, y, 20, 20, class_5244.field_39003, onPress, class_4185.field_40754);
        this.up = up;
    }

    @Override
    public void method_75752(class_332 guiGraphics, int mouseX, int mouseY, float partialTicks) {
        this.method_75794(guiGraphics);
        int iconX = this.method_46426() + (this.field_22758 - 10) / 2;
        int iconY = this.method_46427() + (this.field_22759 - 10) / 2;
        int brightness = class_9848.method_61321(0xFFFFFFFF, this.field_22763 ? 1.0F : 0.5F);
        guiGraphics.method_25291(class_10799.field_56883, this.up ? ARROW_UP : ARROW_DOWN, iconX, iconY, 0, 0, 10, 10, 10, 10, brightness);
    }
}
