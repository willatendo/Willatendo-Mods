package ca.willatendo.simplelibrary.mixin;

import ca.willatendo.simplelibrary.injects.WeightedListBuilderExtension;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.function.Predicate;
import net.minecraft.class_6010;
import net.minecraft.class_6012;

@Mixin(class_6012.class_6006.class)
public class WeightedListBuilderMixin<E> implements WeightedListBuilderExtension<E> {
    private final List<class_6010<E>> result = new ArrayList<>();

    @Inject(at = @At("HEAD"), method = "add", cancellable = true)
    private void add(E element, CallbackInfoReturnable<class_6012.class_6006<E>> cir) {
        this.result.add(new class_6010<>(element, 1));
        cir.setReturnValue((class_6012.class_6006<E>) (Object) this);
    }

    @Inject(at = @At("HEAD"), method = "add(Ljava/lang/Object;I)Lnet/minecraft/util/random/WeightedList$Builder;", cancellable = true)
    private void add(E element, int weight, CallbackInfoReturnable<class_6012.class_6006<E>> cir) {
        this.result.add(new class_6010<>(element, weight));
        cir.setReturnValue((class_6012.class_6006<E>) (Object) this);
    }

    @Inject(at = @At("HEAD"), method = "build", cancellable = true)
    private void build(CallbackInfoReturnable<class_6012<E>> cir) {
        cir.setReturnValue(new class_6012<>(this.result));
    }

    @Override
    public class_6012.class_6006<E> addAll(Collection<class_6010<E>> values) {
        this.result.addAll(values);
        return (class_6012.class_6006<E>) (Object) this;
    }

    @Override
    public class_6012.class_6006<E> removeIf(Predicate<class_6010<E>> filter) {
        this.result.removeIf(filter);
        return (class_6012.class_6006<E>) (Object) this;
    }
}
