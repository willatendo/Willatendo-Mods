package ca.willatendo.simplelibrary.network.utils;

import ca.willatendo.simplelibrary.platform.SimpleLibraryPlatformHelper;
import net.minecraft.class_3222;
import net.minecraft.class_8710;

public final class NetworkUtils {
    private NetworkUtils() {
    }

    public static void sendToClient(class_3222 serverPlayer, class_8710 customPacketPayload) {
        SimpleLibraryPlatformHelper.INSTANCE.sendToClient(serverPlayer, customPacketPayload);
    }

    public static void sendToServer(class_8710 customPacketPayload) {
        SimpleLibraryPlatformHelper.INSTANCE.sendToServer(customPacketPayload);
    }
}
