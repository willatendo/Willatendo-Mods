package ca.willatendo.simplelibrary.server.data_maps;

import ca.willatendo.simplelibrary.core.utils.CoreUtils;
import ca.willatendo.simplelibrary.server.data_maps.buillt_in.*;
import ca.willatendo.simplelibrary.server.event.DataMapEvents;
import net.minecraft.class_1299;
import net.minecraft.class_1792;
import net.minecraft.class_1959;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_3852;
import net.minecraft.class_5712;
import net.minecraft.class_7924;

public final class SimpleLibraryDataMaps {
    public static final DataMapType<class_1299<?>, AcceptableVillagerDistance> ACCEPTABLE_VILLAGER_DISTANCES = DataMapType.builder(SimpleLibraryDataMaps.id("acceptable_villager_distances"), class_7924.field_41266, AcceptableVillagerDistance.CODEC).synced(AcceptableVillagerDistance.DISTANCE_CODEC, false).build();
    public static final DataMapType<class_1792, Compostable> COMPOSTABLES = DataMapType.builder(SimpleLibraryDataMaps.id("compostables"), class_7924.field_41197, Compostable.CODEC).synced(Compostable.CHANCE_CODEC, false).build();
    public static final DataMapType<class_1792, FurnaceFuel> FURNACE_FUELS = DataMapType.builder(SimpleLibraryDataMaps.id("furnace_fuels"), class_7924.field_41197, FurnaceFuel.CODEC).synced(FurnaceFuel.BURN_TIME_CODEC, false).build();
    public static final DataMapType<class_1299<?>, MonsterRoomMob> MONSTER_ROOM_MOBS = DataMapType.builder(SimpleLibraryDataMaps.id("monster_room_mobs"), class_7924.field_41266, MonsterRoomMob.CODEC).synced(MonsterRoomMob.WEIGHT_CODEC, false).build();
    public static final DataMapType<class_2248, Oxidizable> OXIDIZABLES = DataMapType.builder(SimpleLibraryDataMaps.id("oxidizables"), class_7924.field_41254, Oxidizable.CODEC).synced(Oxidizable.OXIDIZABLE_CODEC, false).build();
    public static final DataMapType<class_1299<?>, ParrotImitation> PARROT_IMITATIONS = DataMapType.builder(SimpleLibraryDataMaps.id("parrot_imitations"), class_7924.field_41266, ParrotImitation.CODEC).synced(ParrotImitation.SOUND_CODEC, false).build();
    public static final DataMapType<class_3852, RaidHeroGift> RAID_HERO_GIFTS = DataMapType.builder(SimpleLibraryDataMaps.id("raid_hero_gifts"), class_7924.field_41234, RaidHeroGift.CODEC).synced(RaidHeroGift.LOOT_TABLE_CODEC, false).build();
    public static final DataMapType<class_2248, Strippable> STRIPPABLES = DataMapType.builder(SimpleLibraryDataMaps.id("strippables"), class_7924.field_41254, Strippable.CODEC).synced(Strippable.STRIPPED_BLOCK_CODEC, false).build();
    public static final DataMapType<class_5712, VibrationFrequency> VIBRATION_FREQUENCIES = DataMapType.builder(SimpleLibraryDataMaps.id("vibration_frequencies"), class_7924.field_41273, VibrationFrequency.CODEC).synced(VibrationFrequency.FREQUENCY_CODEC, false).build();
    public static final DataMapType<class_1959, BiomeVillagerType> VILLAGER_TYPES = DataMapType.builder(SimpleLibraryDataMaps.id("villager_types"), class_7924.field_41236, BiomeVillagerType.CODEC).synced(BiomeVillagerType.TYPE_CODEC, false).build();
    public static final DataMapType<class_2248, Waxable> WAXABLES = DataMapType.builder(SimpleLibraryDataMaps.id("waxables"), class_7924.field_41254, Waxable.CODEC).synced(Waxable.WAXABLE_CODEC, false).build();

    private SimpleLibraryDataMaps() {
    }

    private static class_2960 id(String name) {
        return CoreUtils.resource("neoforge", name);
    }

    public static void init() {
        DataMapEvents.REGISTER_DATA_MAPS.register(dataMapTypes -> {
            DataMapEvents.register(dataMapTypes, (DataMapType) ACCEPTABLE_VILLAGER_DISTANCES);
            DataMapEvents.register(dataMapTypes, (DataMapType) COMPOSTABLES);
            DataMapEvents.register(dataMapTypes, (DataMapType) FURNACE_FUELS);
            DataMapEvents.register(dataMapTypes, (DataMapType) MONSTER_ROOM_MOBS);
            DataMapEvents.register(dataMapTypes, (DataMapType) OXIDIZABLES);
            DataMapEvents.register(dataMapTypes, (DataMapType) PARROT_IMITATIONS);
            DataMapEvents.register(dataMapTypes, (DataMapType) RAID_HERO_GIFTS);
            DataMapEvents.register(dataMapTypes, (DataMapType) STRIPPABLES);
            DataMapEvents.register(dataMapTypes, (DataMapType) VIBRATION_FREQUENCIES);
            DataMapEvents.register(dataMapTypes, (DataMapType) VILLAGER_TYPES);
            DataMapEvents.register(dataMapTypes, (DataMapType) WAXABLES);
        });
    }
}
