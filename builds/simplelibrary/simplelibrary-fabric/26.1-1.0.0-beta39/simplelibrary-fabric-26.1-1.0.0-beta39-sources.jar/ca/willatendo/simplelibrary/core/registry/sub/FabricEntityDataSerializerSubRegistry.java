package ca.willatendo.simplelibrary.core.registry.sub;

import ca.willatendo.simplelibrary.core.utils.CoreUtils;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricTrackedDataRegistry;
import net.minecraft.class_2941;
import java.util.function.Supplier;

public final class FabricEntityDataSerializerSubRegistry extends EntityDataSerializerSubRegistry {
    public FabricEntityDataSerializerSubRegistry(String modId) {
        super(modId);
    }

    @Override
    public <T> Supplier<class_2941<T>> register(String id, Supplier<class_2941<T>> value) {
        class_2941<T> entityDataSerializer = value.get();
        FabricTrackedDataRegistry.register(CoreUtils.resource(this.getModId(), id), entityDataSerializer);
        return () -> entityDataSerializer;
    }
}
