package ca.willatendo.simplelibrary.client.utils;

import java.util.Optional;
import net.minecraft.class_10287;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_507;

public final class RecipeBookUtils {
    private RecipeBookUtils() {
    }

    public static class_507.class_10329 createSearch(class_10287 extendedRecipeBookCategory) {
        return new class_507.class_10329(new class_1799(class_1802.field_8251), Optional.empty(), extendedRecipeBookCategory);
    }
}
