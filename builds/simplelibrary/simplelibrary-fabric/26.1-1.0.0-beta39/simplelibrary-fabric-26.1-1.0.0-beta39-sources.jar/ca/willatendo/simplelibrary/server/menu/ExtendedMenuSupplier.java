package ca.willatendo.simplelibrary.server.menu;

import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_2338;
import net.minecraft.class_2540;

public interface ExtendedMenuSupplier<T extends class_1703> {
    T create(int windowId, class_1661 inventory, class_2540 friendlyByteBuf);

    T create(int windowId, class_1661 inventory, class_2338 blockPos);
}
