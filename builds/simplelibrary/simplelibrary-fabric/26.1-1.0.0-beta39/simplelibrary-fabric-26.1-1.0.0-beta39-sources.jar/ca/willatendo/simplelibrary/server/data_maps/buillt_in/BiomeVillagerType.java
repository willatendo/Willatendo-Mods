package ca.willatendo.simplelibrary.server.data_maps.buillt_in;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_3854;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

public record BiomeVillagerType(class_5321<class_3854> type) {
    public static final Codec<BiomeVillagerType> TYPE_CODEC = class_5321.method_39154(class_7924.field_41235).xmap(BiomeVillagerType::new, BiomeVillagerType::type);
    public static final Codec<BiomeVillagerType> CODEC = Codec.withAlternative(RecordCodecBuilder.create(instance -> instance.group(class_5321.method_39154(class_7924.field_41235).fieldOf("villager_type").forGetter(BiomeVillagerType::type)).apply(instance, BiomeVillagerType::new)), TYPE_CODEC);
}
