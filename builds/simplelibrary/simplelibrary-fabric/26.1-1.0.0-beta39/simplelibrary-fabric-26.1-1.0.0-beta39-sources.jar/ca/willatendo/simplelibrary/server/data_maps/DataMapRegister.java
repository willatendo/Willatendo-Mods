package ca.willatendo.simplelibrary.server.data_maps;

import ca.willatendo.simplelibrary.server.event.DataMapEvents;
import java.util.Collections;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.Map;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;

public final class DataMapRegister {
    private static Map<class_5321<class_2378<?>>, Map<class_2960, DataMapType<?, ?>>> dataMaps = Map.of();

    public static <R> DataMapType<R, ?> getDataMap(class_5321<? extends class_2378<R>> registry, class_2960 key) {
        final var map = dataMaps.get(registry);
        return map == null ? null : (DataMapType<R, ?>) map.get(key);
    }

    public static Map<class_5321<class_2378<?>>, Map<class_2960, DataMapType<?, ?>>> getDataMaps() {
        return dataMaps;
    }

    public static void initDataMaps() {
        final Map<class_5321<class_2378<?>>, Map<class_2960, DataMapType<?, ?>>> dataMapTypes = new HashMap<>();
        DataMapEvents.REGISTER_DATA_MAPS.invoker().register(dataMapTypes);
        dataMaps = new IdentityHashMap<>();
        dataMapTypes.forEach((key, values) -> dataMaps.put(key, Collections.unmodifiableMap(values)));
        dataMaps = Collections.unmodifiableMap(dataMapTypes);
    }
}
