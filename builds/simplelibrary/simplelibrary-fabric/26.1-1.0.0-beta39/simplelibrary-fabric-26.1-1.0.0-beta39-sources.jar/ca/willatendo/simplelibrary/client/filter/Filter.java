package ca.willatendo.simplelibrary.client.filter;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_6862;
import net.minecraft.class_7923;

public final class Filter {
    private final class_6862<class_1792> filterTag;
    private final class_1799 filterIcon;
    private List<class_1792> items;
    private boolean enabled = true;
    private FilterButton filterButton;

    public Filter(class_6862<class_1792> filterTag, class_1799 filterIcon) {
        this.filterTag = filterTag;
        this.filterIcon = filterIcon;
    }

    public class_6862<class_1792> getFilterTag() {
        return this.filterTag;
    }

    public class_1799 getFilterIcon() {
        return this.filterIcon;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public Optional<List<class_1792>> getItems() {
        return Optional.ofNullable(this.items);
    }

    public void setFilterButton(FilterButton filterButton) {
        this.filterButton = filterButton;
    }

    public FilterButton getFilterButton() {
        return this.filterButton;
    }

    public void setVisible(boolean visible) {
        if (this.filterButton != null) {
            this.filterButton.field_22764 = visible;
        }
    }

    public void setY(int y) {
        if (this.filterButton != null) {
            this.filterButton.method_46419(y);
        }
    }

    public void loadItems() {
        if (this.items != null) return;
        this.items = new ArrayList<>();
        class_7923.field_41178.method_10220().forEach(item -> {
            if (item.method_40131().method_40220(this.getFilterTag())) {
                this.items.add(item);
            }
        });
    }

    public void resetItems() {
        this.items = null;
    }
}
