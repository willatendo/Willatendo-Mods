package ca.willatendo.simplelibrary.client.screen.recipe_book;

import net.minecraft.class_2960;

public interface IdentifiableRecipeBookComponent {
    class_2960 getIdentifier();
}
