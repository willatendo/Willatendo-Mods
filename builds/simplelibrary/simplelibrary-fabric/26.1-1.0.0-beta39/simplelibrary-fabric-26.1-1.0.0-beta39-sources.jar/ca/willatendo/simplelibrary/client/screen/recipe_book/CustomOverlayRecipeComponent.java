package ca.willatendo.simplelibrary.client.screen.recipe_book;

import ca.willatendo.simplelibrary.client.CustomRecipeBooks;
import java.util.Collections;
import java.util.List;
import java.util.function.BiFunction;
import net.minecraft.class_10295;
import net.minecraft.class_10297;
import net.minecraft.class_10298;
import net.minecraft.class_10352;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_508;
import net.minecraft.class_516;
import net.minecraft.class_9938;

public final class CustomOverlayRecipeComponent extends class_508 {
    private IdentifiableRecipeBookComponent identifiableRecipeBookComponent;

    public CustomOverlayRecipeComponent(class_9938 slotSelectTime, IdentifiableRecipeBookComponent identifiableRecipeBookComponent) {
        super(slotSelectTime, false);
        this.identifiableRecipeBookComponent = identifiableRecipeBookComponent;
    }

    @Override
    public void method_2617(class_516 recipeCollection, class_10352 contextMap, boolean isFiltering, int x, int y, int overlayX, int overlayY, float width) {
        this.field_3111 = recipeCollection;
        List<class_10297> craftable = recipeCollection.method_64885(class_516.class_9937.field_52848);
        List<class_10297> notCraftable = isFiltering ? Collections.emptyList() : recipeCollection.method_64885(class_516.class_9937.field_52849);
        int craftableSize = craftable.size();
        int fullSize = craftableSize + notCraftable.size();
        int k = fullSize <= 16 ? 4 : 5;
        int l = (int) Math.ceil((float) fullSize / (float) k);
        this.field_3105 = x;
        this.field_3103 = y;
        float f = (float) (this.field_3105 + Math.min(fullSize, k) * 25);
        float f1 = (float) (overlayX + 50);
        if (f > f1) {
            this.field_3105 = (int) ((float) this.field_3105 - width * (float) ((int) ((f - f1) / width)));
        }

        float f2 = (float) (this.field_3103 + l * 25);
        float f3 = (float) (overlayY + 50);
        if (f2 > f3) {
            this.field_3103 = (int) ((float) this.field_3103 - width * (float) class_3532.method_15386((f2 - f3) / width));
        }

        float f4 = (float) this.field_3103;
        float f5 = (float) (overlayY - 100);
        if (f4 < f5) {
            this.field_3103 = (int) ((float) this.field_3103 - width * (float) class_3532.method_15386((f4 - f5) / width));
        }

        this.field_3107 = true;
        this.field_3106.clear();

        for (int i = 0; i < fullSize; ++i) {
            boolean flag = i < craftableSize;
            class_10297 recipedisplayentry = flag ? craftable.get(i) : notCraftable.get(i - craftableSize);
            int buttonX = this.field_3105 + 4 + 25 * (i % k);
            int buttonY = this.field_3103 + 5 + 25 * (i / k);
            CustomRecipeBooks.getButton(this.identifiableRecipeBookComponent.getIdentifier(), buttonX, buttonY, recipedisplayentry.comp_3262(), recipedisplayentry.comp_3263(), contextMap, flag, this.field_3106, CustomOverlayRecipeComponent.CustomOverlayRecipeButton::new);
        }

        this.field_3104 = null;
    }

    public static class_508.class_509.class_510 createGridPos(int x, int y, List<class_1799> possibleItems) {
        return new class_508.class_509.class_510(3 + x * 7, 3 + y * 7, possibleItems);
    }

    public class CustomOverlayRecipeButton extends class_508.class_509 {
        private final BiFunction<Boolean, Boolean, class_2960> sprite;

        public CustomOverlayRecipeButton(int x, int y, class_10298 recipeDisplayId, class_10295 recipeDisplay, class_10352 contextMap, boolean isCraftable, BiFunction<class_10295, class_10352, List<class_508.class_509.class_510>> slots, BiFunction<Boolean, Boolean, class_2960> sprite) {
            super(x, y, recipeDisplayId, isCraftable, slots.apply(recipeDisplay, contextMap));
            this.sprite = sprite;
        }

        @Override
        protected class_2960 method_62039(boolean enabled) {
            return this.sprite.apply(enabled, this.method_25367());
        }
    }
}
