package ca.willatendo.simplelibrary.server.data_maps.buillt_in;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_2248;
import net.minecraft.class_7923;

public record Strippable(class_2248 strippedBlock) {
    public static final Codec<Strippable> STRIPPED_BLOCK_CODEC = class_7923.field_41175.method_39673().xmap(Strippable::new, Strippable::strippedBlock);
    public static final Codec<Strippable> CODEC = Codec.withAlternative(RecordCodecBuilder.create(instance -> instance.group(class_7923.field_41175.method_39673().fieldOf("stripped_block").forGetter(Strippable::strippedBlock)).apply(instance, Strippable::new)), STRIPPED_BLOCK_CODEC);
}
