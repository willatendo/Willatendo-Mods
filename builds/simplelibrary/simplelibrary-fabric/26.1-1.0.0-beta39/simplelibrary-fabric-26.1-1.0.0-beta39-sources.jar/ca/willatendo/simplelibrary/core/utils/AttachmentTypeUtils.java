package ca.willatendo.simplelibrary.core.utils;

import ca.willatendo.simplelibrary.platform.SimpleLibraryPlatformHelper;
import net.minecraft.class_2960;

public final class AttachmentTypeUtils {
    private AttachmentTypeUtils() {
    }

    public static <T> boolean hasData(T value, class_2960 attachmentType) {
        return SimpleLibraryPlatformHelper.INSTANCE.hasData(value, attachmentType);
    }

    public static <T, V> V getData(T value, class_2960 attachmentType) {
        return SimpleLibraryPlatformHelper.INSTANCE.getData(value, attachmentType);
    }

    public static <T, V> void setData(T value, class_2960 attachmentType, V data) {
        SimpleLibraryPlatformHelper.INSTANCE.setData(value, attachmentType, data);
    }

    public static <T> void removeData(T value, class_2960 attachmentType) {
        SimpleLibraryPlatformHelper.INSTANCE.removeData(value, attachmentType);
    }
}
