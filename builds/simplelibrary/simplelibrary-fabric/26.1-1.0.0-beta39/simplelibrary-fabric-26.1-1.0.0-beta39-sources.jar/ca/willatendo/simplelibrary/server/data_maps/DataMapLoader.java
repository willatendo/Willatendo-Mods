package ca.willatendo.simplelibrary.server.data_maps;

import ca.willatendo.simplelibrary.core.utils.SimpleCoreUtils;
import ca.willatendo.simplelibrary.server.conditions.ConditionalOps;
import ca.willatendo.simplelibrary.server.conditions.ICondition;
import ca.willatendo.simplelibrary.server.event.DataMapEvents;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.mojang.datafixers.util.Either;
import com.mojang.serialization.Codec;
import com.mojang.serialization.JsonOps;
import java.io.Reader;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.function.Consumer;
import net.minecraft.class_10209;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import net.minecraft.class_3302;
import net.minecraft.class_3695;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_6903;
import net.minecraft.class_7654;

public final class DataMapLoader implements class_3302 {
    public static final String PATH = "data_maps";
    private Map<class_5321<? extends class_2378<?>>, LoadResult<?>> results;
    private final ICondition.IContext conditionContext;
    private final class_5455 registryAccess;

    public DataMapLoader(ICondition.IContext conditionContext, class_5455 registryAccess) {
        this.conditionContext = conditionContext;
        this.registryAccess = registryAccess;
    }

    @Override
    public CompletableFuture<Void> method_25931(class_11558 sharedState, Executor exectutor, class_4045 barrier, Executor applyExectutor) {
        return this.load(sharedState.method_72361(), exectutor, class_10209.method_64146()).thenCompose(barrier::method_18352).thenAcceptAsync(values -> this.results = values, applyExectutor);
    }

    public void apply() {
        this.results.forEach((key, result) -> this.apply((class_2378) this.registryAccess.method_30530(key), result));

        this.results = null;
    }

    private <T> void apply(class_2378<T> registry, LoadResult<T> result) {
        registry.clearData();
        result.results().forEach((key, entries) -> registry.putData(key, this.buildDataMap(registry, key, (List) entries)));
        DataMapEvents.UPDATE_DATA_MAPS.invoker().update(this.registryAccess, registry, DataMapEvents.UpdateCause.SERVER_RELOAD);
    }

    private <T, R> Map<class_5321<R>, T> buildDataMap(class_2378<R> registry, DataMapType<R, T> attachment, List<DataMapFile<T, R>> entries) {
        record WithSource<T, R>(T attachment, Either<class_6862<R>, class_5321<R>> source) {
        }
        final Map<class_5321<R>, WithSource<T, R>> result = new IdentityHashMap<>();
        final DataMapValueMerger<R, T> merger = attachment instanceof AdvancedDataMapType<R, T, ?> adv ? adv.merger() : DataMapValueMerger.defaultMerger();
        entries.forEach(entry -> {
            if (entry.replace()) {
                result.clear();
            }

            entry.values().forEach((tKey, value) -> {
                if (value.isEmpty()) return;

                this.resolve(registry, tKey, true, holder -> {
                    final var newValue = value.get().carrier();
                    final var key = holder.getKey();
                    final var oldValue = result.get(key);
                    if (oldValue == null || newValue.replace()) {
                        result.put(key, new WithSource<>(newValue.value(), tKey));
                    } else {
                        result.put(key, new WithSource<>(merger.merge(registry, oldValue.source(), oldValue.attachment(), tKey, newValue.value()), tKey));
                    }
                });
            });

            for (var removal : entry.removals()) {
                if (removal.remover().isPresent()) {
                    var remover = removal.remover().orElseThrow();
                    this.resolve(registry, removal.key(), false, holder -> {
                        class_5321 key = holder.getKey();
                        var oldValue = result.get(key);
                        if (oldValue != null) {
                            Optional<T> newValue = remover.remove(oldValue.attachment(), registry, oldValue.source(), holder.comp_349());
                            if (newValue.isEmpty()) {
                                result.remove(key);
                            } else {
                                result.put(key, new WithSource<>(newValue.get(), oldValue.source()));
                            }
                        }
                    });
                } else {
                    this.resolve(registry, removal.key(), false, holder -> result.remove(holder.getKey()));
                }
            }
        });
        Map<class_5321<R>, T> newMap = new IdentityHashMap<>();
        result.forEach((key, withSource) -> newMap.put(key, withSource.attachment()));
        return newMap;
    }


    private <R> void resolve(class_2378<R> registry, Either<class_6862<R>, class_5321<R>> value, boolean required, Consumer<class_6880<R>> consumer) {
        if (value.left().isPresent()) {
            registry.method_40286(value.left().orElseThrow()).forEach(consumer);
        } else {
            var object = registry.method_46746(value.right().orElseThrow());
            if (object.isPresent()) {
                consumer.accept(object.get());
            } else if (required) {
                SimpleCoreUtils.LOGGER.error("Object with ID {} specified in data map for registry {} doesn't exist", value.right().orElseThrow().method_29177(), registry.method_46765().method_29177());
            }
        }
    }

    private CompletableFuture<Map<class_5321<? extends class_2378<?>>, LoadResult<?>>> load(class_3300 resourceManager, Executor executor, class_3695 profiler) {
        return CompletableFuture.supplyAsync(() -> load(resourceManager, profiler, registryAccess, conditionContext), executor);
    }

    private static Map<class_5321<? extends class_2378<?>>, LoadResult<?>> load(class_3300 manager, class_3695 profiler, class_5455 access, ICondition.IContext context) {
        class_6903<JsonElement> ops = new ConditionalOps<>(class_6903.method_46632(JsonOps.INSTANCE, access), context);

        Map<class_5321<? extends class_2378<?>>, LoadResult<?>> values = new HashMap<>();
        access.method_40311().forEach(registryEntry -> {
            class_5321<? extends class_2378<?>> registryKey = registryEntry.comp_350();
            profiler.method_15396("registry_data_maps/" + registryKey.method_29177() + "/locating");
            class_7654 fileToId = class_7654.method_45114(PATH + "/" + getFolderLocation(registryKey.method_29177()));
            for (Map.Entry<class_2960, List<class_3298>> entry : fileToId.method_45116(manager).entrySet()) {
                class_2960 key = entry.getKey();
                class_2960 attachmentId = fileToId.method_45115(key);
                DataMapType<?, ?> attachment = DataMapRegister.getDataMap((class_5321) registryKey, attachmentId);
                if (attachment == null) {
                    SimpleCoreUtils.LOGGER.warn("Found data map file for non-existent data map type '{}' on registry '{}'.", attachmentId, registryKey.method_29177());
                    continue;
                }
                profiler.method_15405("registry_data_maps/" + registryKey.method_29177() + "/" + attachmentId + "/loading");
                values.computeIfAbsent(registryKey, k -> new LoadResult<>(new HashMap<>())).results.put((DataMapType) attachment, readData(ops, attachment, (class_5321) registryKey, entry.getValue()));
            }
            profiler.method_15407();
        });

        return values;
    }

    public static String getFolderLocation(class_2960 registryId) {
        return (registryId.method_12836().equals(class_2960.field_33381) ? "" : registryId.method_12836() + "/") + registryId.method_12832();
    }

    private static <A, T> List<DataMapFile<A, T>> readData(class_6903<JsonElement> ops, DataMapType<T, A> attachmentType, class_5321<class_2378<T>> registryKey, List<class_3298> resources) {
        Codec<DataMapFile<A, T>> codec = DataMapFile.codec(registryKey, attachmentType);
        List<DataMapFile<A, T>> entries = new LinkedList<>();
        for (class_3298 resource : resources) {
            try (Reader reader = resource.method_43039()) {
                JsonElement jsonelement = JsonParser.parseReader(reader);
                entries.add(codec.decode(ops, jsonelement).getOrThrow().getFirst());
            } catch (Exception exception) {
                SimpleCoreUtils.LOGGER.error("Could not read data map of type {} for registry {}", attachmentType.id(), registryKey, exception);
            }
        }
        return entries;
    }

    private record LoadResult<T>(Map<DataMapType<T, ?>, List<DataMapFile<?, T>>> results) {
    }
}
