package ca.willatendo.simplelibrary.platform;

import ca.willatendo.simplelibrary.core.registry.SimpleRegistryBuilder;
import ca.willatendo.simplelibrary.core.registry.sub.AttachmentTypesSubRegistry;
import ca.willatendo.simplelibrary.core.registry.sub.EntityDataSerializerSubRegistry;
import ca.willatendo.simplelibrary.platform.utils.PlatformUtils;
import ca.willatendo.simplelibrary.server.menu.ExtendedMenuSupplier;
import com.mojang.datafixers.util.Pair;
import java.util.List;
import java.util.Map;
import java.util.function.BiFunction;
import net.minecraft.class_10295;
import net.minecraft.class_10352;
import net.minecraft.class_1703;
import net.minecraft.class_1761;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2400;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3908;
import net.minecraft.class_3917;
import net.minecraft.class_508;
import net.minecraft.class_5321;
import net.minecraft.class_5421;
import net.minecraft.class_7696;
import net.minecraft.class_8710;

public interface SimpleLibraryPlatformHelper {
    SimpleLibraryPlatformHelper INSTANCE = PlatformUtils.ofPlatformHelper(SimpleLibraryPlatformHelper.class);

    // Platform
    Platform getPlatform();

    // Packets
    void sendToServer(class_8710 customPacketPayload, class_8710... customPacketPayloads);

    void sendToClient(class_3222 serverPlayer, class_8710 customPacketPayload);

    // Creation
    class_7696 getFeatureFlag(class_2960 identifier);

    class_5421 getRecipeBookType(String modId, String name);

    <T> class_2378<T> createRegistry(class_5321<class_2378<T>> resourceKey, SimpleRegistryBuilder simpleRegistryBuilder);

    AttachmentTypesSubRegistry createAttachmentTypesSubRegistry(String modId);

    EntityDataSerializerSubRegistry createEntityDataSerializerSubRegistry(String modId);

    class_2400 createSimpleParticleType(boolean overrideLimiter);

    <T extends class_1703> class_3917<T> createMenuType(ExtendedMenuSupplier<T> extendedMenuSupplier);

    class_1761.class_7913 createCreativeModeTab();

    // Attachment Types
    <T> boolean hasData(T value, class_2960 attachmentType);

    <T, V> V getData(T value, class_2960 attachmentType);

    <T, V> void setData(T value, class_2960 attachmentType, V data);

    <T> void removeData(T value, class_2960 attachmentType);

    // Interactions
    void openContainer(class_3908 menuProvider, class_2338 blockPos, class_3222 serverPlayer);

    void registerRecipeBookOverlayEvent(Map<class_2960, Pair<BiFunction<class_10295, class_10352, List<class_508.class_509.class_510>>, BiFunction<Boolean, Boolean, class_2960>>> map);
}
