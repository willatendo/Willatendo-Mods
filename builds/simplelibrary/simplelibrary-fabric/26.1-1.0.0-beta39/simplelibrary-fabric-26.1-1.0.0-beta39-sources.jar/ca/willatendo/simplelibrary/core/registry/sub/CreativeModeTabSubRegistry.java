package ca.willatendo.simplelibrary.core.registry.sub;

import ca.willatendo.simplelibrary.core.holder.SimpleHolder;
import ca.willatendo.simplelibrary.core.registry.SimpleRegistry;
import ca.willatendo.simplelibrary.core.utils.CoreUtils;
import ca.willatendo.simplelibrary.platform.SimpleLibraryPlatformHelper;
import java.util.function.Supplier;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_7924;

public class CreativeModeTabSubRegistry extends SimpleRegistry<class_1761> {
    public CreativeModeTabSubRegistry(String modId) {
        super(class_7924.field_44688, modId);
    }

    public SimpleHolder<class_1761> register(String name, Supplier<class_1799> itemStackIcon, class_1761.class_7914 displayItemsGenerator) {
        return this.register(name, name, itemStackIcon, displayItemsGenerator);
    }

    public SimpleHolder<class_1761> register(String name, String tabName, Supplier<class_1799> itemStackIcon, class_1761.class_7914 displayItemsGenerator) {
        return this.register(name, () -> SimpleLibraryPlatformHelper.INSTANCE.createCreativeModeTab().method_47321(CoreUtils.translation("itemGroup", this.modId, tabName)).method_47320(itemStackIcon).method_47317(displayItemsGenerator).method_47324());
    }
}
