package ca.willatendo.simplelibrary.core.registry.sub;

import ca.willatendo.simplelibrary.core.registry.SimpleRegistry;
import ca.willatendo.simplelibrary.core.utils.CoreUtils;
import com.google.common.collect.Maps;
import java.util.Map;
import net.minecraft.class_2960;
import net.minecraft.class_3446;
import net.minecraft.class_3468;
import net.minecraft.class_7924;

public class CustomStatsSubRegistry extends SimpleRegistry<class_2960> {
    private final Map<class_2960, class_3446> statFormatters = Maps.newHashMap();

    public CustomStatsSubRegistry(String modId) {
        super(class_7924.field_41263, modId);
    }

    public void registerStatFormatters() {
        this.statFormatters.forEach(class_3468.field_15419::method_14955);
    }

    public class_2960 registerCustomStat(String name, class_3446 statFormatter) {
        class_2960 statIdentifier = CoreUtils.resource(this.modId, name);
        this.register(name, () -> statIdentifier);
        this.statFormatters.put(statIdentifier, statFormatter);
        return statIdentifier;
    }
}
