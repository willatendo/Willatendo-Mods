package ca.willatendo.simplelibrary.server.data_maps.buillt_in;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

public record RaidHeroGift(class_5321<class_52> lootTable) {
    public static final Codec<RaidHeroGift> LOOT_TABLE_CODEC = class_5321.method_39154(class_7924.field_50079).xmap(RaidHeroGift::new, RaidHeroGift::lootTable);
    public static final Codec<RaidHeroGift> CODEC = Codec.withAlternative(RecordCodecBuilder.create(instance -> instance.group(class_5321.method_39154(class_7924.field_50079).fieldOf("loot_table").forGetter(RaidHeroGift::lootTable)).apply(instance, RaidHeroGift::new)), LOOT_TABLE_CODEC);
}
