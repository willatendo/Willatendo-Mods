package ca.willatendo.simplelibrary.mixin;

import ca.willatendo.simplelibrary.server.data_maps.DataMapHooks;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Optional;
import net.minecraft.class_2680;
import net.minecraft.class_5953;

@Mixin(class_5953.class)
public class HoneycombItemMixin {
    @Inject(at = @At("HEAD"), method = "getWaxed", cancellable = true)
    private static void getWaxed(class_2680 blockState, CallbackInfoReturnable<Optional<class_2680>> cir) {
        cir.setReturnValue(Optional.ofNullable(DataMapHooks.getBlockWaxed(blockState.method_26204())).map(block -> block.method_34725(blockState)));
    }
}
