package ca.willatendo.simplelibrary.server.biome_modifier;

import java.util.Collections;
import java.util.Set;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_5483;
import net.minecraft.class_6012;

// Modified from Neoforge
public final class MobSpawnSettingsBuilder extends class_5483.class_5496 {
    private final Set<class_1311> typesView = Collections.unmodifiableSet(this.field_26647.keySet());
    private final Set<class_1299<?>> costView = Collections.unmodifiableSet(this.field_26648.keySet());

    public MobSpawnSettingsBuilder(class_5483 mobSpawnSettings) {
        mobSpawnSettings.getSpawnerTypes().forEach(mobCategory -> this.field_26647.get(mobCategory).addAll(mobSpawnSettings.method_31004(mobCategory)));
        mobSpawnSettings.getEntityTypes().forEach(entityType -> this.field_26648.put(entityType, mobSpawnSettings.method_31003(entityType)));
        field_26649 = mobSpawnSettings.method_31002();
    }

    public Set<class_1311> getSpawnerTypes() {
        return this.typesView;
    }

    public class_6012.class_6006<class_5483.class_1964> getSpawner(class_1311 type) {
        return this.field_26647.get(type);
    }

    public Set<class_1299<?>> getEntityTypes() {
        return this.costView;
    }

    public class_5483.class_5265 getCost(class_1299<?> type) {
        return this.field_26648.get(type);
    }

    public float getProbability() {
        return this.field_26649;
    }

    public MobSpawnSettingsBuilder disablePlayerSpawn() {
        return this;
    }

    public MobSpawnSettingsBuilder removeSpawnCost(class_1299<?>... entityTypes) {
        for (class_1299<?> entityType : entityTypes) {
            this.field_26648.remove(entityType);
        }
        return this;
    }
}
