package ca.willatendo.simplelibrary.core.registry;

import ca.willatendo.simplelibrary.server.biome_modifier.BiomeModifier;
import ca.willatendo.simplelibrary.server.conditions.ICondition;
import ca.willatendo.simplelibrary.server.utils.ServerUtils;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_2378;

public final class SimpleLibraryBuiltInRegistries {
    public static final class_2378<MapCodec<? extends BiomeModifier>> BIOME_MODIFIER_SERIALIZERS = ServerUtils.createRegistry(SimpleLibraryRegistries.BIOME_MODIFIER_SERIALIZERS, SimpleRegistryBuilder.of());
    public static final class_2378<MapCodec<? extends ICondition>> CONDITION_SERIALIZERS = ServerUtils.createRegistry(SimpleLibraryRegistries.CONDITION_CODECS, SimpleRegistryBuilder.of());

    public static void init() {
    }
}
