package ca.willatendo.simplelibrary.mixin;

import ca.willatendo.simplelibrary.injects.ChunkGeneratorExtension;
import ca.willatendo.simplelibrary.server.utils.Lazy;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.util.List;
import java.util.function.Function;
import java.util.function.Supplier;
import net.minecraft.class_1959;
import net.minecraft.class_1966;
import net.minecraft.class_2794;
import net.minecraft.class_5485;
import net.minecraft.class_6880;
import net.minecraft.class_7510;

@Mixin(class_2794.class)
public class ChunkGeneratorMixin implements ChunkGeneratorExtension {
    @Shadow
    @Final
    protected class_1966 biomeSource;
    @Shadow
    private Supplier<List<class_7510.class_6827>> featuresPerStep;
    @Shadow
    @Final
    private Function<class_6880<class_1959>, class_5485> generationSettingsGetter;

    @Redirect(at = @At(value = "FIELD", target = "Lnet/minecraft/world/level/chunk/ChunkGenerator;featuresPerStep:Ljava/util/function/Supplier;", opcode = Opcodes.PUTFIELD), method = "<init>(Lnet/minecraft/world/level/biome/BiomeSource;Ljava/util/function/Function;)V")
    private void init(class_2794 chunkGenerator, Supplier<List<class_7510.class_6827>> featuresPerStep) {
        chunkGenerator.field_39412 = Lazy.of(() -> class_7510.method_44210(List.copyOf(this.biomeSource.method_28443()), biomeHolder -> this.generationSettingsGetter.apply(biomeHolder).method_30983(), true));
    }

    @Override
    public void refreshFeaturesPerStep() {
        ((Lazy) this.featuresPerStep).invalidate();
    }
}
