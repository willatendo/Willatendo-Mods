package ca.willatendo.simplelibrary.client;

import ca.willatendo.simplelibrary.platform.SimpleLibraryPlatformHelper;
import com.google.common.collect.Maps;
import com.mojang.datafixers.util.Pair;
import java.util.List;
import java.util.Map;
import java.util.function.BiFunction;
import net.minecraft.class_10295;
import net.minecraft.class_10298;
import net.minecraft.class_10352;
import net.minecraft.class_2960;
import net.minecraft.class_508;

public final class CustomRecipeBooks {
    private static final Map<class_2960, Pair<BiFunction<class_10295, class_10352, List<class_508.class_509.class_510>>, BiFunction<Boolean, Boolean, class_2960>>> MAP = Maps.newHashMap();

    public static void init() {
        MAP.clear();
        SimpleLibraryPlatformHelper.INSTANCE.registerRecipeBookOverlayEvent(MAP);
    }

    public static void getButton(class_2960 identifier, int buttonX, int buttonY, class_10298 recipeDisplayId, class_10295 recipeDisplay, class_10352 contextMap, boolean isCraftable, List<class_508.class_509> overlayRecipeButtonList, NewButtonInstance newButtonInstance) {
        Pair<BiFunction<class_10295, class_10352, List<class_508.class_509.class_510>>, BiFunction<Boolean, Boolean, class_2960>> pair = MAP.get(identifier);
        class_508.class_509 button = newButtonInstance.newButton(buttonX, buttonY, recipeDisplayId, recipeDisplay, contextMap, isCraftable, pair.getFirst(), pair.getSecond());
        overlayRecipeButtonList.add(button);
    }

    public interface NewButtonInstance {
        class_508.class_509 newButton(int x, int y, class_10298 recipeDisplayId, class_10295 recipeDisplay, class_10352 contextMap, boolean isCraftable, BiFunction<class_10295, class_10352, List<class_508.class_509.class_510>> slots, BiFunction<Boolean, Boolean, class_2960> sprite);
    }
}
