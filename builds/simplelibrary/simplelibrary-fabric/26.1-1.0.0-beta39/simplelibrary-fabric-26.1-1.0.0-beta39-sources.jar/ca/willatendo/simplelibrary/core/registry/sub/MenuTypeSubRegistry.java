package ca.willatendo.simplelibrary.core.registry.sub;

import ca.willatendo.simplelibrary.core.holder.SimpleHolder;
import ca.willatendo.simplelibrary.core.registry.SimpleRegistry;
import ca.willatendo.simplelibrary.platform.SimpleLibraryPlatformHelper;
import ca.willatendo.simplelibrary.server.menu.ExtendedMenuSupplier;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_3917;
import net.minecraft.class_7924;

public class MenuTypeSubRegistry extends SimpleRegistry<class_3917<?>> {
    public MenuTypeSubRegistry(String modId) {
        super(class_7924.field_41207, modId);
    }

    public <T extends class_1703> SimpleHolder<class_3917<T>> registerSimple(String name, CreateSimple<T> createSimple) {
        return this.register(name, () -> SimpleLibraryPlatformHelper.INSTANCE.createMenuType(new ExtendedMenuSupplier<T>() {
            @Override
            public T create(int windowId, class_1661 inventory, class_2540 friendlyByteBuf) {
                return createSimple.create(windowId, inventory);
            }

            @Override
            public T create(int windowId, class_1661 inventory, class_2338 blockPos) {
                return createSimple.create(windowId, inventory);
            }
        }));
    }

    public <T extends class_1703> SimpleHolder<class_3917<T>> registerSimple(String name, CreateFromServer<T> createFromServer, CreateFromBlockPos<T> createFromBlockPos) {
        return this.register(name, () -> SimpleLibraryPlatformHelper.INSTANCE.createMenuType(new ExtendedMenuSupplier<T>() {
            @Override
            public T create(int windowId, class_1661 inventory, class_2540 friendlyByteBuf) {
                return createFromServer.create(windowId, inventory, friendlyByteBuf);
            }

            @Override
            public T create(int windowId, class_1661 inventory, class_2338 blockPos) {
                return createFromBlockPos.create(windowId, inventory, blockPos);
            }
        }));
    }

    public interface CreateSimple<T extends class_1703> {
        T create(int windowId, class_1661 inventory);
    }

    public interface CreateFromServer<T extends class_1703> {
        T create(int windowId, class_1661 inventory, class_2540 friendlyByteBuf);
    }

    public interface CreateFromBlockPos<T extends class_1703> {
        T create(int windowId, class_1661 inventory, class_2338 blockPos);
    }
}
