package ca.willatendo.simplelibrary.server.event;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_11697;
import java.util.function.Consumer;

public interface RegisterTextureAtlasesEvent {
    Event<RegisterTextureAtlasesEvent> EVENT = EventFactory.createArrayBacked(RegisterTextureAtlasesEvent.class, callbacks -> consumer -> {
        for (RegisterTextureAtlasesEvent callback : callbacks) {
            callback.register(consumer);
        }
    });

    void register(Consumer<class_11697.class_11698> consumer);
}
