package ca.willatendo.simplelibrary.network;

import net.minecraft.class_1657;
import net.minecraft.class_8710;

public interface PacketSupplier<T extends class_8710> {
    void handle(T customPacketPayload, class_1657 player);
}
