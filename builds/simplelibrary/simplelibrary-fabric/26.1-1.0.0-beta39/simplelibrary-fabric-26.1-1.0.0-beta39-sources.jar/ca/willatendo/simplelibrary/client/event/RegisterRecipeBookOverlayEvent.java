package ca.willatendo.simplelibrary.client.event;

import com.mojang.datafixers.util.Pair;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_10295;
import net.minecraft.class_10352;
import net.minecraft.class_2960;
import net.minecraft.class_508;
import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;

@FunctionalInterface
public interface RegisterRecipeBookOverlayEvent {
    Event<RegisterRecipeBookOverlayEvent> EVENT = EventFactory.createArrayBacked(RegisterRecipeBookOverlayEvent.class, callbacks -> biConsumer -> {
        for (RegisterRecipeBookOverlayEvent callback : callbacks) {
            callback.register(biConsumer);
        }
    });

    void register(BiConsumer<class_2960, Pair<BiFunction<class_10295, class_10352, List<class_508.class_509.class_510>>, BiFunction<Boolean, Boolean, class_2960>>> biConsumer);
}
