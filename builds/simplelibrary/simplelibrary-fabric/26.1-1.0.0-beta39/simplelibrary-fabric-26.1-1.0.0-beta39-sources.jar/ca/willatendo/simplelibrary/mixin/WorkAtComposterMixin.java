package ca.willatendo.simplelibrary.mixin;

import ca.willatendo.simplelibrary.server.data_maps.SimpleLibraryDataMaps;
import ca.willatendo.simplelibrary.server.data_maps.buillt_in.Compostable;
import it.unimi.dsi.fastutil.objects.Reference2IntMap;
import it.unimi.dsi.fastutil.objects.Reference2IntOpenHashMap;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import net.minecraft.class_1277;
import net.minecraft.class_1646;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3962;
import net.minecraft.class_4208;
import net.minecraft.class_4983;

@Mixin(class_4983.class)
public abstract class WorkAtComposterMixin {
    @Shadow
    @Final
    private static List<class_1792> COMPOSTABLE_ITEMS;

    @Shadow
    abstract void spawnComposterFillEffects(class_3218 level, class_2680 preState, class_2338 pos, class_2680 postState);

    @Inject(at = @At("HEAD"), method = "compostItems", cancellable = true)
    private void compostItems(class_3218 serverLevel, class_1646 villager, class_4208 globalPos, class_2680 preBlockState, CallbackInfo ci) {
        class_2338 blockpos = globalPos.comp_2208();
        if (preBlockState.method_11654(class_3962.field_17565) == 8) {
            preBlockState = class_3962.method_26374(villager, preBlockState, serverLevel, blockpos);
        }

        int i = 20;
        Reference2IntMap<class_1792> amounts = new Reference2IntOpenHashMap<>(COMPOSTABLE_ITEMS.size() * 2);
        class_1277 simpleContainer = villager.method_35199();
        class_2680 postBlockState = preBlockState;

        for (class_1799 itemStack : simpleContainer) {
            Compostable compostable = (Compostable) itemStack.method_41409().getData(SimpleLibraryDataMaps.COMPOSTABLES);
            if (compostable != null && compostable.canVillagerCompost()) {
                int itemStackCount = itemStack.method_7947();
                int k1 = amounts.getInt(itemStack.method_7909()) + itemStackCount;
                amounts.put(itemStack.method_7909(), k1);
                int l1 = Math.min(Math.min(k1 - 10, i), itemStackCount);
                if (l1 > 0) {
                    i -= l1;

                    for (int i2 = 0; i2 < l1; i2++) {
                        postBlockState = class_3962.method_26373(villager, postBlockState, serverLevel, itemStack, blockpos);
                        if (postBlockState.method_11654(class_3962.field_17565) == 7) {
                            this.spawnComposterFillEffects(serverLevel, preBlockState, blockpos, postBlockState);
                            ci.cancel();
                        }
                    }
                }
            }
        }
    }
}
