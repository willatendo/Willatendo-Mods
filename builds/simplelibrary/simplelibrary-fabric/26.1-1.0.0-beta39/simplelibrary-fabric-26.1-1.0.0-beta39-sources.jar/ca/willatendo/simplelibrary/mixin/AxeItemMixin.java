package ca.willatendo.simplelibrary.mixin;

import ca.willatendo.simplelibrary.server.data_maps.SimpleLibraryDataMaps;
import ca.willatendo.simplelibrary.server.data_maps.buillt_in.Strippable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Optional;
import net.minecraft.class_1743;
import net.minecraft.class_2680;

@Mixin(class_1743.class)
public class AxeItemMixin {
    @Inject(at = @At("HEAD"), method = "getStripped", cancellable = true)
    private void simpleLibrary$getStripped(class_2680 unstrippedState, CallbackInfoReturnable<Optional<class_2680>> cir) {
        Strippable strippable = (Strippable) unstrippedState.method_26204().method_40142().getData(SimpleLibraryDataMaps.STRIPPABLES);
        if (strippable != null) {
            cir.setReturnValue(Optional.of(strippable.strippedBlock().method_34725(unstrippedState)));
        }
    }
}
