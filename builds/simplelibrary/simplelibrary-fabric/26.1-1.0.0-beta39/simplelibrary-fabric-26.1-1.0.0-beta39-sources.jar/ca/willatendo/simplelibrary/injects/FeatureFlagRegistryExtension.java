package ca.willatendo.simplelibrary.injects;

import net.minecraft.class_2960;
import net.minecraft.class_7696;

public interface FeatureFlagRegistryExtension {
    default class_7696 getFlag(class_2960 name) {
        throw new RuntimeException("This has not been registered correctly! " + this.getClass());
    }
}
