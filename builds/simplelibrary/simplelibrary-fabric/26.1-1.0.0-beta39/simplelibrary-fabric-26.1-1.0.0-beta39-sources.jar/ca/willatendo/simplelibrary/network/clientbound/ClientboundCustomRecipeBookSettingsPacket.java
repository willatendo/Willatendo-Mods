package ca.willatendo.simplelibrary.network.clientbound;

import ca.willatendo.simplelibrary.core.utils.SimpleCoreUtils;
import ca.willatendo.simplelibrary.server.stats.CustomRecipeBookSettings;
import net.minecraft.class_5411;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record ClientboundCustomRecipeBookSettingsPacket(class_5411 recipeBookSettings, CustomRecipeBookSettings customRecipeBookSettings) implements class_8710 {
    public static final class_8710.class_9154<ClientboundCustomRecipeBookSettingsPacket> TYPE = new class_8710.class_9154<>(SimpleCoreUtils.resource("custom_recipe_book_settings"));
    public static final class_9139<class_9129, ClientboundCustomRecipeBookSettingsPacket> STREAM_CODEC = class_9139.method_56435(class_5411.field_54548, ClientboundCustomRecipeBookSettingsPacket::recipeBookSettings, CustomRecipeBookSettings.STREAM_CODEC, ClientboundCustomRecipeBookSettingsPacket::customRecipeBookSettings, ClientboundCustomRecipeBookSettingsPacket::new);

    @Override
    public class_8710.class_9154<ClientboundCustomRecipeBookSettingsPacket> method_56479() {
        return TYPE;
    }
}
