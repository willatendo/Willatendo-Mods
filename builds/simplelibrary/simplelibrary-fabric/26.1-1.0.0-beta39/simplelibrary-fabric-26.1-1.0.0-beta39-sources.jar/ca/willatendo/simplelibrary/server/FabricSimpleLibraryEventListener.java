package ca.willatendo.simplelibrary.server;

import ca.willatendo.simplelibrary.core.registry.SimpleLibraryRegistries;
import ca.willatendo.simplelibrary.core.utils.CoreUtils;
import ca.willatendo.simplelibrary.core.utils.SimpleCoreUtils;
import ca.willatendo.simplelibrary.mixin.MappedRegistryAccessor;
import ca.willatendo.simplelibrary.network.clientbound.ClientboundRecipeContentPacket;
import ca.willatendo.simplelibrary.network.utils.NetworkUtils;
import ca.willatendo.simplelibrary.server.biome_modifier.BiomeModifier;
import ca.willatendo.simplelibrary.server.data_maps.DataMapLoader;
import ca.willatendo.simplelibrary.server.event.TagEvents;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1959;
import net.minecraft.class_1972;
import net.minecraft.class_2378;
import net.minecraft.class_3222;
import net.minecraft.class_5350;
import net.minecraft.class_5455;
import net.minecraft.class_5483;
import net.minecraft.class_6010;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_9248;
import net.minecraft.server.MinecraftServer;
import java.util.List;
import java.util.Optional;

public record FabricSimpleLibraryEventListener() implements EventListener {
    private static DataMapLoader DATA_MAP_LOADER;

    @Override
    public void commonSetup() {
        TagEvents.UPDATE_TAGS.register((provider, fromClientPacket, isIntegratedServerConnection) -> {
            if (!fromClientPacket) {
                DATA_MAP_LOADER.apply();
            }
        });
    }

    @Override
    public void registerDynamicRegistries(DynamicRegistryRegister dynamicRegistryRegister) {
        dynamicRegistryRegister.apply(SimpleLibraryRegistries.BIOME_MODIFIERS, BiomeModifier.DIRECT_CODEC);
    }

    @Override
    public void syncDataPackContentsEvent(class_3222 serverPlayer) {
        NetworkUtils.sendToClient(serverPlayer, ClientboundRecipeContentPacket.create(class_7923.field_41188.method_10220().toList(), serverPlayer.field_13995.method_3772().field_54638));
    }

    @Override
    public void registerServerReloadListener(ServerReloadListenerRegister serverReloadListenerRegister) {
        class_5350 reloadableServerResources = serverReloadListenerRegister.getServerResources();
        serverReloadListenerRegister.apply(CoreUtils.resource("neoforge", "data_maps"), DATA_MAP_LOADER = new DataMapLoader(reloadableServerResources.getConditionContext(), reloadableServerResources.getConditionContext().registryAccess()));
    }

    @Override
    public void serverAboutToStartEvent(MinecraftServer minecraftServer) {
        ServerLifecycleHooks.handleServerAboutToStart(minecraftServer);

        class_5455 registries = minecraftServer.method_30611();
        List<BiomeModifier> biomeModifiers = registries.method_30530(SimpleLibraryRegistries.BIOME_MODIFIERS).method_42017().map(class_6880::comp_349).toList();

        class_2378<class_1959> registry = registries.method_30530(class_7924.field_41236);
        registry.method_42017().forEach(biomeHolder -> {
            class_1959 biome = biomeHolder.comp_349();

            FabricSimpleLibraryEventListener.ensureProperSync(biome.modifiableBiomeInfo().applyBiomeModifiers(biomeHolder, biomeModifiers, registries), biomeHolder, registry);

            class_5483 mobSpawnSettings = biome.method_30966();
            for (class_1311 mobCategory : mobSpawnSettings.getSpawnerTypes()) {
                for (class_6010<class_5483.class_1964> spawnerData : mobSpawnSettings.method_31004(mobCategory).method_34994()) {
                    if (spawnerData.comp_2542().comp_3488().method_5891() != mobCategory) {
                        boolean isVanillaBug = spawnerData.comp_2542().comp_3488() == class_1299.field_6081 && (biomeHolder.method_40225(class_1972.field_9417) || biomeHolder.method_40225(class_1972.field_9440));
                        if (!isVanillaBug) {
                            SimpleCoreUtils.LOGGER.warn("Detected {} that was registered with {} mob category but was added under {} mob category for {} biome! " + "Mobs should be added to biomes under the same mob category that the mob was registered as to prevent mob cap spawning issues.", class_7923.field_41177.method_10221(spawnerData.comp_2542().comp_3488()), spawnerData.comp_2542().comp_3488().method_5891(), mobCategory, biomeHolder.method_40237().method_29177());
                        }
                    }
                }
            }
        });
        registries.method_30530(class_7924.field_41224).forEach(levelStem -> levelStem.comp_1013().refreshFeaturesPerStep());
    }

    @Override
    public void serverStoppedEvent(MinecraftServer minecraftServer) {
        ServerLifecycleHooks.handleServerStopped(minecraftServer);
    }

    private static <T> void ensureProperSync(boolean modified, class_6880.class_6883<T> holder, class_2378<T> registry) {
        if (modified) {
            Optional<class_9248> originalInfo = registry.method_57058(holder.method_40237());
            originalInfo.ifPresent(registrationInfo -> {
                class_9248 newInfo = new class_9248(Optional.empty(), registrationInfo.comp_2355());
                ((MappedRegistryAccessor<T>) registry).simpleLibrary$getRegistrationInfos().put(holder.method_40237(), newInfo);
            });
        }
    }
}
