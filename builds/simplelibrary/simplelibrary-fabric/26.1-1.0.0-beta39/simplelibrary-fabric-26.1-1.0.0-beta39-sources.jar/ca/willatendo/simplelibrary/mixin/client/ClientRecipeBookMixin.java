package ca.willatendo.simplelibrary.mixin.client;

import ca.willatendo.simplelibrary.client.RecipeBookManager;
import ca.willatendo.simplelibrary.injects.ClientRecipeBookExtension;
import ca.willatendo.simplelibrary.server.stats.CustomRecipeBookSettings;
import com.google.common.collect.HashBasedTable;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Table;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.*;
import net.minecraft.class_10287;
import net.minecraft.class_10297;
import net.minecraft.class_10298;
import net.minecraft.class_10331;
import net.minecraft.class_10355;
import net.minecraft.class_299;
import net.minecraft.class_3439;
import net.minecraft.class_516;

@Mixin(class_299.class)
public class ClientRecipeBookMixin extends class_3439 implements ClientRecipeBookExtension {
    @Shadow
    @Final
    private Map<class_10298, class_10297> known;
    @Shadow
    private Map<class_10287, List<class_516>> collectionsByTab;
    @Shadow
    private List<class_516> allCollections;

    @Override
    public void setCustomBookSettings(CustomRecipeBookSettings customRecipeBookSettings) {
        this.getCustomRecipeBookSettings().replaceFrom(customRecipeBookSettings);
    }

    @Inject(at = @At("HEAD"), method = "rebuildCollections", cancellable = true)
    private void rebuildCollections(CallbackInfo ci) {
        Map<class_10355, List<List<class_10297>>> map = ClientRecipeBookMixin.categorizeAndGroupRecipes(this.known.values());
        Map<class_10287, List<class_516>> collections = new HashMap<>();
        ImmutableList.Builder<class_516> builder = ImmutableList.builder();
        map.forEach((recipeBookCategory, lists) -> {
            Objects.requireNonNull(builder);
            collections.put(recipeBookCategory, lists.stream().map(class_516::new).peek(builder::add).collect(ImmutableList.toImmutableList()));
        });

        for (class_10331 searchRecipeBookCategory : class_10331.values()) {
            collections.put(searchRecipeBookCategory, searchRecipeBookCategory.method_64888().stream().flatMap(recipeBookCategory -> collections.getOrDefault(recipeBookCategory, List.of()).stream()).collect(ImmutableList.toImmutableList()));
        }

        for (Map.Entry<class_10287, List<class_10355>> entry : RecipeBookManager.getSearchCategories().entrySet()) {
            collections.put(entry.getKey(), entry.getValue().stream().flatMap(category -> collections.getOrDefault(category, List.of()).stream()).collect(ImmutableList.toImmutableList()));
        }

        this.collectionsByTab = Map.copyOf(collections);
        this.allCollections = builder.build();
        ci.cancel();
    }


    private static Map<class_10355, List<List<class_10297>>> categorizeAndGroupRecipes(Iterable<class_10297> recipes) {
        Map<class_10355, List<List<class_10297>>> map = new HashMap<>();
        Table<class_10355, Integer, List<class_10297>> table = HashBasedTable.create();

        for (class_10297 recipeDisplayEntry : recipes) {
            class_10355 recipeBookCategory = recipeDisplayEntry.comp_3265();
            OptionalInt optionalint = recipeDisplayEntry.comp_3264();
            if (optionalint.isEmpty()) {
                map.computeIfAbsent(recipeBookCategory, recipeBookCategoryIn -> new ArrayList<>()).add(List.of(recipeDisplayEntry));
            } else {
                List<class_10297> list = table.get(recipeBookCategory, optionalint.getAsInt());
                if (list == null) {
                    list = new ArrayList<>();
                    table.put(recipeBookCategory, optionalint.getAsInt(), list);
                    map.computeIfAbsent(recipeBookCategory, recipeBookCategoryIn -> new ArrayList<>()).add(list);
                }

                list.add(recipeDisplayEntry);
            }
        }

        return map;
    }
}
