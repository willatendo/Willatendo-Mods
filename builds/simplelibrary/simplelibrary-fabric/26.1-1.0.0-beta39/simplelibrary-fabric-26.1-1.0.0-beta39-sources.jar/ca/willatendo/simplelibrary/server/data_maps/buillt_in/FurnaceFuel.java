package ca.willatendo.simplelibrary.server.data_maps.buillt_in;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_5699;

public record FurnaceFuel(int burnTime) {
    public static final Codec<FurnaceFuel> BURN_TIME_CODEC = class_5699.field_33442.xmap(FurnaceFuel::new, FurnaceFuel::burnTime);
    public static final Codec<FurnaceFuel> CODEC = Codec.withAlternative(RecordCodecBuilder.create(instance -> instance.group(class_5699.field_33442.fieldOf("burn_time").forGetter(FurnaceFuel::burnTime)).apply(instance, FurnaceFuel::new)), BURN_TIME_CODEC);
}
