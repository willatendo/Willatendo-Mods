package ca.willatendo.simplelibrary.core.utils;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.Arrays;
import java.util.Locale;
import java.util.stream.Collectors;
import net.minecraft.class_2561;
import net.minecraft.class_2960;

public final class CoreUtils {
    public static final Logger LOGGER = LogManager.getLogger("Debug!");

    private CoreUtils() {
    }

    public static class_2960 resource(String modId, String path) {
        return class_2960.method_60655(modId, path);
    }

    public static class_2960 minecraft(String path) {
        return class_2960.method_60656(path);
    }

    public static class_2561 translation(String type, String modId, String key) {
        return class_2561.method_43471(type + "." + modId + "." + key);
    }

    public static String simpleAutoName(String internalName) {
        return Arrays.stream(internalName.toLowerCase(Locale.ROOT).split("_")).map(StringUtils::capitalize).collect(Collectors.joining(" "));
    }
}
