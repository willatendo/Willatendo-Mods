package ca.willatendo.simplelibrary.client.filter;

import ca.willatendo.simplelibrary.core.utils.SimpleCoreUtils;
import net.minecraft.class_10799;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_481;
import net.minecraft.class_5244;
import net.minecraft.class_9848;

public class FilterSelectButton extends class_4185 {
    public static final class_2960 SELECT_ALL = SimpleCoreUtils.resource("textures/gui/select_all.png");
    public static final class_2960 DESELECT_ALL = SimpleCoreUtils.resource("textures/gui/deselect_all.png");
    private final boolean selectAll;

    public FilterSelectButton(CreativeModeTabFilter creativeModeTabFilter, class_481 creativeModeInventoryScreen, int x, int y, boolean selectAll) {
        super(x, y, 20, 20, class_5244.field_39003, button -> {
            if (selectAll) {
                creativeModeTabFilter.getCategories().forEach(filter -> filter.setEnabled(true));
            } else {
                creativeModeTabFilter.getCategories().forEach(filter -> filter.setEnabled(false));
            }
            creativeModeTabFilter.updateItems(creativeModeInventoryScreen);
        }, class_4185.field_40754);
        this.selectAll = selectAll;
    }

    @Override
    public void method_75752(class_332 guiGraphics, int mouseX, int mouseY, float partialTicks) {
        this.method_75794(guiGraphics);
        int iconX = this.method_46426() + (this.field_22758 - 10) / 2;
        int iconY = this.method_46427() + (this.field_22759 - 10) / 2;
        int brightness = class_9848.method_61321(0xFFFFFFFF, this.field_22763 ? 1.0F : 0.5F);
        guiGraphics.method_25291(class_10799.field_56883, this.selectAll ? SELECT_ALL : DESELECT_ALL, iconX, iconY, 0, 0, 10, 10, 10, 10, brightness);
    }
}
