package ca.willatendo.simplelibrary.mixin;

import ca.willatendo.simplelibrary.server.data_maps.SimpleLibraryDataMaps;
import ca.willatendo.simplelibrary.server.data_maps.buillt_in.Compostable;
import it.unimi.dsi.fastutil.objects.Object2FloatMap;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1935;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2758;
import net.minecraft.class_3218;
import net.minecraft.class_3468;
import net.minecraft.class_3962;
import net.minecraft.class_3965;
import net.minecraft.class_5712;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_3962.class)
public class ComposterBlockMixin {
    @Shadow
    @Final
    public static Object2FloatMap<class_1935> COMPOSTABLES;
    @Shadow
    @Final
    public static class_2758 LEVEL;

    @Inject(at = @At("HEAD"), method = "useItemOn", cancellable = true)
    private void useItemOn(class_1799 itemStack, class_2680 blockState, class_1937 level, class_2338 blockPos, class_1657 player, class_1268 interactionHand, class_3965 blockHitResult, CallbackInfoReturnable<class_1269> cir) {
        int currentLevel = blockState.method_11654(LEVEL);
        if (currentLevel < 8 && ComposterBlockMixin.getValue(itemStack) > 0.0F) {
            if (currentLevel < 7 && !level.method_8608()) {
                class_2680 composterBlockState = class_3962.method_17756(player, blockState, level, blockPos, itemStack);
                level.method_20290(1500, blockPos, blockState != composterBlockState ? 1 : 0);
                player.method_7259(class_3468.field_15372.method_14956(itemStack.method_7909()));
                itemStack.method_57008(1, player);
            }

            cir.setReturnValue(class_1269.field_5812);
        }
    }

    @Inject(at = @At("HEAD"), method = "insertItem", cancellable = true)
    private static void insertItem(class_1297 entity, class_2680 blockStateIn, class_3218 serverLevel, class_1799 itemStack, class_2338 blockPos, CallbackInfoReturnable<class_2680> cir) {
        int currentLevel = blockStateIn.method_11654(LEVEL);
        if (currentLevel < 7 && ComposterBlockMixin.getValue(itemStack) > 0.0F) {
            class_2680 composterBlockState = class_3962.method_17756(entity, blockStateIn, serverLevel, blockPos, itemStack);
            itemStack.method_7934(1);
            cir.setReturnValue(composterBlockState);
        }
    }

    @Inject(at = @At("HEAD"), method = "addItem", cancellable = true)
    private static void addItem(class_1297 entity, class_2680 blockStateIn, class_1936 levelAccessor, class_2338 blockPos, class_1799 itemStack, CallbackInfoReturnable<class_2680> cir) {
        int currentLevel = blockStateIn.method_11654(LEVEL);
        float chance = ComposterBlockMixin.getValue(itemStack);
        if ((currentLevel == 0 || (chance > 0.0F)) && (levelAccessor.method_8409().method_43058() < (double) chance)) {
            int newLevel = currentLevel + 1;
            class_2680 blockState = blockStateIn.method_11657(LEVEL, newLevel);
            levelAccessor.method_8652(blockPos, blockState, 3);
            levelAccessor.method_43276(class_5712.field_28733, blockPos, class_5712.class_7397.method_43286(entity, blockState));
            if (newLevel == 7) {
                levelAccessor.method_64310(blockPos, blockStateIn.method_26204(), 20);
            }

            cir.setReturnValue(blockState);
        }
    }

    private static float getValue(class_1799 itemStack) {
        Compostable compostable = (Compostable) itemStack.method_41409().getData(SimpleLibraryDataMaps.COMPOSTABLES);
        if (compostable != null) {
            return compostable.chance();
        }
        return 0.0F;
    }
}
