package ca.willatendo.simplelibrary.core.registry.sub;

import ca.willatendo.simplelibrary.core.holder.SimpleHolder;
import ca.willatendo.simplelibrary.core.registry.SimpleRegistry;
import ca.willatendo.simplelibrary.core.utils.CoreUtils;
import ca.willatendo.simplelibrary.server.utils.BlockUtils;
import net.minecraft.class_10716;
import net.minecraft.class_2248;
import net.minecraft.class_2269;
import net.minecraft.class_2323;
import net.minecraft.class_2349;
import net.minecraft.class_2354;
import net.minecraft.class_2362;
import net.minecraft.class_2397;
import net.minecraft.class_2440;
import net.minecraft.class_2465;
import net.minecraft.class_2473;
import net.minecraft.class_2482;
import net.minecraft.class_2498;
import net.minecraft.class_2508;
import net.minecraft.class_2510;
import net.minecraft.class_2533;
import net.minecraft.class_2551;
import net.minecraft.class_2766;
import net.minecraft.class_3619;
import net.minecraft.class_3620;
import net.minecraft.class_4719;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7713;
import net.minecraft.class_7715;
import net.minecraft.class_7924;
import net.minecraft.class_8177;
import net.minecraft.class_8813;
import net.minecraft.world.level.block.*;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Supplier;

public class BlockSubRegistry extends SimpleRegistry<class_2248> {
    public BlockSubRegistry(String modId) {
        super(class_7924.field_41254, modId);
    }

    public SimpleHolder<class_2248> registerPlanks(String name, class_3620 mapColor) {
        return this.registerBlock(name, class_4970.class_2251.method_9637().method_31710(mapColor).method_51368(class_2766.field_12651).method_9629(2.0F, 3.0F).method_9626(class_2498.field_11547).method_50013());
    }

    public SimpleHolder<class_2473> registerSapling(String name, class_8813 treeGrower) {
        return this.registerBlock(name, properties -> new class_2473(treeGrower, properties), () -> class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971));
    }

    public SimpleHolder<class_2465> registerLog(String name, class_3620 topColor, class_3620 sideColor, class_2498 soundType) {
        return this.registerBlock(name, class_2465::new, () -> BlockUtils.logProperties(topColor, sideColor, soundType));
    }

    public SimpleHolder<class_2465> registerStrippedLog(String name, class_3620 mapColor, class_2498 soundType) {
        return this.registerBlock(name, class_2465::new, () -> BlockUtils.logProperties(mapColor, mapColor, soundType));
    }

    public SimpleHolder<class_2465> registerWood(String name, class_3620 mapColor) {
        return this.registerBlock(name, class_2465::new, () -> class_4970.class_2251.method_9637().method_31710(mapColor).method_51368(class_2766.field_12651).method_9632(2.0F).method_9626(class_2498.field_11547).method_50013());
    }

    public SimpleHolder<class_2465> registerStrippedWood(String name, class_3620 mapColor) {
        return this.registerBlock(name, class_2465::new, () -> class_4970.class_2251.method_9637().method_31710(mapColor).method_51368(class_2766.field_12651).method_9632(2.0F).method_9626(class_2498.field_11547).method_50013());
    }

    public SimpleHolder<class_2397> registerLeaves(String name, float leafParticleChance) {
        return this.registerBlock(name, properties -> new class_10716(leafParticleChance, properties), () -> BlockUtils.leavesProperties(class_2498.field_11535));
    }

    public SimpleHolder<class_2510> registerWoodStairs(String name, Supplier<class_2248> planks) {
        SimpleHolder<class_2510> stairs = this.registerStairs(name, planks);
        return stairs;
    }

    public SimpleHolder<class_2510> registerStairs(String name, Supplier<class_2248> block) {
        return this.registerBlock(name, properties -> new class_2510(block.get().method_9564(), properties), () -> class_4970.class_2251.method_9630(block.get()));
    }

    public <SB extends class_2508> SimpleHolder<SB> registerSign(String name, BiFunction<class_4719, class_4970.class_2251, SB> block, class_4719 woodType, class_3620 mapColor) {
        return this.registerBlock(name, properties -> block.apply(woodType, properties), () -> class_4970.class_2251.method_9637().method_31710(mapColor).method_51369().method_51368(class_2766.field_12651).method_9634().method_9632(1.0F).method_50013());
    }

    public <WB extends class_2551, SB extends class_2508> SimpleHolder<WB> registerWallSign(String name, BiFunction<class_4719, class_4970.class_2251, WB> block, Supplier<SB> standingSignBlock) {
        return this.registerBlock(name, properties -> block.apply(standingSignBlock.get().method_24025(), properties), () -> BlockUtils.wallVariant(standingSignBlock.get(), false));
    }

    public SimpleHolder<class_2323> registerDoor(String name, class_8177 blockSetType, Supplier<class_2248> planks) {
        return this.registerBlock(name, properties -> new class_2323(blockSetType, properties), () -> class_4970.class_2251.method_9637().method_31710(planks.get().method_26403()).method_51368(class_2766.field_12651).method_9632(3.0F).method_22488().method_50013().method_50012(class_3619.field_15971));
    }

    public <CB extends class_7713> SimpleHolder<CB> registerHangingSign(String name, BiFunction<class_4719, class_4970.class_2251, CB> block, class_4719 woodType, Supplier<class_2465> logBlock) {
        return this.registerBlock(name, properties -> block.apply(woodType, properties), () -> class_4970.class_2251.method_9637().method_31710(logBlock.get().method_26403()).method_51369().method_51368(class_2766.field_12651).method_9634().method_9632(1.0F).method_50013());
    }

    public <WB extends class_7715, CB extends class_7713> SimpleHolder<WB> registerWallHangingSign(String name, BiFunction<class_4719, class_4970.class_2251, WB> block, Supplier<CB> hangingSign) {
        return this.registerBlock(name, properties -> block.apply(hangingSign.get().method_24025(), properties), () -> BlockUtils.wallVariant(hangingSign.get(), false));
    }

    public SimpleHolder<class_2440> registerPressurePlate(String name, class_8177 blockSetType, Supplier<class_2248> planks) {
        return this.registerBlock(name, properties -> new class_2440(blockSetType, properties), () -> class_4970.class_2251.method_9637().method_31710(planks.get().method_26403()).method_51369().method_51368(class_2766.field_12651).method_9634().method_9632(0.5F).method_50013().method_50012(class_3619.field_15971));
    }

    public SimpleHolder<class_2354> registerFence(String name, Supplier<class_2248> planks) {
        return this.registerBlock(name, class_2354::new, () -> class_4970.class_2251.method_9637().method_31710(planks.get().method_26403()).method_51369().method_51368(class_2766.field_12651).method_9629(2.0F, 3.0F).method_9626(class_2498.field_11547).method_50013());
    }

    public SimpleHolder<class_2533> registerTrapdoor(String name, class_8177 blockSetType, class_3620 mapColor) {
        return this.registerBlock(name, properties -> new class_2533(blockSetType, properties), () -> class_4970.class_2251.method_9637().method_31710(mapColor).method_51368(class_2766.field_12651).method_9632(3.0F).method_22488().method_26235(BlockUtils::never).method_50013());
    }

    public SimpleHolder<class_2349> registerFenceGate(String name, class_4719 woodType, Supplier<class_2248> planks) {
        return this.registerBlock(name, properties -> new class_2349(woodType, properties), () -> class_4970.class_2251.method_9637().method_31710(planks.get().method_26403()).method_51369().method_51368(class_2766.field_12651).method_9629(2.0F, 3.0F).method_50013());
    }

    public SimpleHolder<class_2362> registerPottedSapling(String name, Supplier<class_2473> sapling) {
        return this.registerBlock(name, properties -> new class_2362(sapling.get(), properties), BlockUtils::flowerPotProperties);
    }

    public SimpleHolder<class_2269> registerButton(String name, class_8177 blockSetType) {
        return this.registerBlock(name, properties -> new class_2269(blockSetType, 30, properties), BlockUtils::buttonProperties);
    }

    public SimpleHolder<class_2482> registerWoodSlab(String name, class_3620 mapColor) {
        return this.registerBlock(name, class_2482::new, () -> class_4970.class_2251.method_9637().method_31710(mapColor).method_51368(class_2766.field_12651).method_9629(2.0F, 3.0F).method_9626(class_2498.field_11547).method_50013());
    }

    public SimpleHolder<class_2482> registerStoneSlab(String name, class_3620 mapColor) {
        return this.registerBlock(name, class_2482::new, () -> class_4970.class_2251.method_9637().method_31710(mapColor).method_51368(class_2766.field_12653).method_29292().method_9629(2.0F, 6.0F));
    }

    public SimpleHolder<class_2248> registerBlock(String name, class_4970.class_2251 properties) {
        return this.registerBlock(name, () -> properties);
    }

    public SimpleHolder<class_2248> registerBlock(String name, Supplier<class_4970.class_2251> properties) {
        return this.registerBlock(name, class_2248::new, properties);
    }

    public <T extends class_2248> SimpleHolder<T> registerBlock(String name, Function<class_4970.class_2251, T> block, Supplier<class_4970.class_2251> properties) {
        class_5321<class_2248> id = class_5321.method_29179(this.registryKey, CoreUtils.resource(this.modId, name));
        return this.register(name, () -> block.apply(properties.get().method_63500(id)));
    }

    public class_5321<class_2248> reference(String name) {
        return class_5321.method_29179(this.registryKey, CoreUtils.resource(this.modId, name));
    }
}
