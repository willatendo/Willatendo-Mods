package ca.willatendo.simplelibrary.mixin.client;

import ca.willatendo.simplelibrary.client.screen.recipe_book.CustomOverlayRecipeComponent;
import ca.willatendo.simplelibrary.client.screen.recipe_book.IdentifiableRecipeBookComponent;
import net.minecraft.class_507;
import net.minecraft.class_508;
import net.minecraft.class_513;
import net.minecraft.class_9938;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_513.class)
public class RecipeBookPageMixin {
    @Shadow
    @Final
    private class_507<?> parent;
    @Final
    private static class_9938 slotSelectTime;

    @Inject(at = @At("INVOKE"), method = "<init>")
    private static void init(class_507<?> parent, class_9938 slotSelectTime, boolean isFurnaceMenu, CallbackInfo ci) {
        RecipeBookPageMixin.slotSelectTime = slotSelectTime;
    }

    @Redirect(method = "<init>", at = @At(value = "FIELD", target = "Lnet/minecraft/client/gui/screens/recipebook/RecipeBookPage;overlay:Lnet/minecraft/client/gui/screens/recipebook/OverlayRecipeComponent;", opcode = 181))
    private void init(class_513 recipeBookPage, class_508 overlayRecipeComponent) {
        recipeBookPage.field_3132 = this.parent instanceof IdentifiableRecipeBookComponent identifiableRecipeBookComponent ? new CustomOverlayRecipeComponent(RecipeBookPageMixin.slotSelectTime, identifiableRecipeBookComponent) : overlayRecipeComponent;
    }
}
