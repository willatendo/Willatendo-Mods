package ca.willatendo.simplelibrary.core.registry.sub;

import ca.willatendo.simplelibrary.platform.SimpleLibraryPlatformHelper;
import java.util.function.Supplier;
import net.minecraft.class_2941;

public abstract class EntityDataSerializerSubRegistry {
    private final String modId;

    public static EntityDataSerializerSubRegistry create(String modId) {
        return SimpleLibraryPlatformHelper.INSTANCE.createEntityDataSerializerSubRegistry(modId);
    }

    protected EntityDataSerializerSubRegistry(String modId) {
        this.modId = modId;
    }

    public String getModId() {
        return this.modId;
    }

    public abstract <T> Supplier<class_2941<T>> register(String id, Supplier<class_2941<T>> value);
}
