package ca.willatendo.simplelibrary.mixin;

import ca.willatendo.simplelibrary.server.event.TagEvents;
import net.minecraft.class_2535;
import net.minecraft.class_2790;
import net.minecraft.class_310;
import net.minecraft.class_5455;
import net.minecraft.class_634;
import net.minecraft.class_8673;
import net.minecraft.class_8675;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_634.class)
public abstract class ClientPacketListenerMixin extends class_8673 {
    @Shadow
    @Final
    private class_5455.class_6890 registryAccess;

    protected ClientPacketListenerMixin(class_310 minecraft, class_2535 connection, class_8675 commonListenerCookie) {
        super(minecraft, connection, commonListenerCookie);
    }

    @Inject(at = @At("HEAD"), method = "handleUpdateTags")
    private void handleUpdateTags(class_2790 clientboundUpdateTagsPacket, CallbackInfo ci) {
        boolean flag = this.field_45589.method_10756();
        TagEvents.UPDATE_TAGS.invoker().update(this.registryAccess, true, flag);
    }
}
