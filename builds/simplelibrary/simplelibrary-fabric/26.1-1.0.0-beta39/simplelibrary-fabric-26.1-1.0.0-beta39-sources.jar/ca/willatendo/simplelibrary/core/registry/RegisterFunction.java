package ca.willatendo.simplelibrary.core.registry;

import java.util.function.Supplier;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;

@FunctionalInterface
public interface RegisterFunction {
    <T> void register(class_5321<? extends class_2378<T>> registryKey, class_2960 identifier, Supplier<T> value);
}
