package ca.willatendo.simplelibrary.mixin;


import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Map;
import net.minecraft.class_2370;
import net.minecraft.class_5321;
import net.minecraft.class_9248;

@Mixin(class_2370.class)
public interface MappedRegistryAccessor<T> {
    @Accessor("registrationInfos")
    Map<class_5321<T>, class_9248> simpleLibrary$getRegistrationInfos();
}