package ca.willatendo.simplelibrary.client.filter;

import ca.willatendo.simplelibrary.core.utils.CoreUtils;
import ca.willatendo.simplelibrary.core.utils.SimpleCoreUtils;
import net.minecraft.class_10799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_5244;

public class FilterButton extends class_4185 {
    private static final class_2960 SELECTED_FILTER_TAB = SimpleCoreUtils.resource("container/creative_inventory/filter_tab_selected");
    private static final class_2960 UNSELECTED_FILTER_TAB = SimpleCoreUtils.resource("container/creative_inventory/filter_tab_unselected");

    private final Filter filter;
    private final class_2561 filterTooltip;

    FilterButton(int x, int y, Filter filter, class_4185.class_4241 onPress) {
        super(x, y, 32, 26, class_5244.field_39003, onPress, class_4185.field_40754);
        this.filter = filter;
        this.filter.setFilterButton(this);
        class_2960 tagIdentifier = filter.getFilterTag().comp_327();
        this.filterTooltip = CoreUtils.translation("itemGroup.filter", tagIdentifier.method_12836(), tagIdentifier.method_12832().replace("/", "."));
    }

    public class_2561 getFilterTooltip() {
        return this.filterTooltip;
    }

    @Override
    protected void method_75752(class_332 guiGraphics, int mouseX, int mouseY, float partialTicks) {
        guiGraphics.method_52706(class_10799.field_56883, this.filter.isEnabled() ? SELECTED_FILTER_TAB : UNSELECTED_FILTER_TAB, this.method_46426(), this.method_46427(), 32, 26);
        guiGraphics.method_51427(this.filter.getFilterIcon(), this.method_46426() + 8, this.method_46427() + 5);
    }
}
