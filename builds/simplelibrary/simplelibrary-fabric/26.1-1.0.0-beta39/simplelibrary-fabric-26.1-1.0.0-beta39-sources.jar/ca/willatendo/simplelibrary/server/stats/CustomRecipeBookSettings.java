package ca.willatendo.simplelibrary.server.stats;

import ca.willatendo.simplelibrary.core.utils.SimpleCoreUtils;
import ca.willatendo.simplelibrary.server.stats.utils.RecipeBookUtils;
import com.google.common.base.CaseFormat;
import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.*;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.EnumMap;
import java.util.Iterator;
import java.util.Map;
import java.util.function.UnaryOperator;
import java.util.stream.Stream;
import net.minecraft.class_5411;
import net.minecraft.class_5421;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public final class CustomRecipeBookSettings {
    public static final MapCodec<CustomRecipeBookSettings> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(CustomRecipeBookSettings.makeModdedRecipeBookTypesSettingsCodec().forGetter(customRecipeBookSettings -> customRecipeBookSettings.moddedSettings)).apply(instance, CustomRecipeBookSettings::new));
    public static final class_9139<class_9129, CustomRecipeBookSettings> STREAM_CODEC = new class_9139<>() {
        @Override
        public CustomRecipeBookSettings decode(class_9129 registryFriendlyByteBuf) {
            Map<class_5421, class_5411.class_5412> map = new EnumMap<>(class_5421.class);

            for (class_5421 recipeBookType : RecipeBookUtils.getModdedRecipeBookTypes().toList()) {
                map.put(recipeBookType, class_5411.class_5412.field_60345.decode(registryFriendlyByteBuf));
            }

            return new CustomRecipeBookSettings(map);
        }

        @Override
        public void encode(class_9129 registryFriendlyByteBuf, CustomRecipeBookSettings customRecipeBookSettings) {
            for (class_5421 recipeBookType : RecipeBookUtils.getModdedRecipeBookTypes().toList()) {
                class_5411.class_5412 typeSettings = customRecipeBookSettings.moddedSettings.getOrDefault(recipeBookType, class_5411.class_5412.field_54549);
                class_5411.class_5412.field_60345.encode(registryFriendlyByteBuf, typeSettings);
            }
        }
    };

    private final Map<class_5421, class_5411.class_5412> moddedSettings;

    public static MapCodec<Map<class_5421, class_5411.class_5412>> makeModdedRecipeBookTypesSettingsCodec() {
        final Map<class_5421, MapCodec<class_5411.class_5412>> codecs = RecipeBookUtils.getModdedRecipeBookTypes().map(recipeBookType -> {
            String name = CaseFormat.UPPER_UNDERSCORE.to(CaseFormat.UPPER_CAMEL, recipeBookType.name());
            String openName = "is" + name + "GuiOpen";
            String filteringName = "is" + name + "FilteringCraftable";
            MapCodec<class_5411.class_5412> codec = class_5411.class_5412.method_71340(openName, filteringName);
            return Pair.of(recipeBookType, codec);
        }).collect(Pair.toMap());
        return new MapCodec<>() {
            @Override
            public <T> Stream<T> keys(DynamicOps<T> dynamicOps) {
                return codecs.values().stream().flatMap(codec -> codec.keys(dynamicOps));
            }

            @Override
            public <T> DataResult<Map<class_5421, class_5411.class_5412>> decode(DynamicOps<T> dynamicOps, MapLike<T> mapLikeInput) {
                Map<class_5421, class_5411.class_5412> map = new EnumMap<>(class_5421.class);

                for (Map.Entry<class_5421, MapCodec<class_5411.class_5412>> entry : codecs.entrySet()) {
                    DataResult<class_5411.class_5412> result = entry.getValue().decode(dynamicOps, mapLikeInput);
                    result.error().ifPresent(error -> SimpleCoreUtils.LOGGER.error("Failed to decode RecipeBookSettings.TypeSettings for key {}: {}", entry.getKey(), error));
                    result.result().ifPresent(settings -> map.put(entry.getKey(), settings));
                }

                return DataResult.success(map);
            }

            @Override
            public <T> RecordBuilder<T> encode(Map<class_5421, class_5411.class_5412> mapInput, DynamicOps<T> dynamicOps, RecordBuilder<T> recordBuilder) {
                Map.Entry<class_5421, MapCodec<class_5411.class_5412>> entry;
                for (Iterator<Map.Entry<class_5421, MapCodec<class_5411.class_5412>>> iterator = codecs.entrySet().iterator(); iterator.hasNext(); recordBuilder = ((MapCodec) entry.getValue()).encode(mapInput.getOrDefault(entry.getKey(), class_5411.class_5412.field_54549), dynamicOps, recordBuilder)) {
                    entry = iterator.next();
                }

                return recordBuilder;
            }
        };
    }

    public CustomRecipeBookSettings() {
        this(new EnumMap<>(class_5421.class));
    }

    public CustomRecipeBookSettings(Map<class_5421, class_5411.class_5412> moddedSettings) {
        this.moddedSettings = moddedSettings;
    }

    public class_5411.class_5412 getSettings(class_5421 recipeBookType) {
        return this.moddedSettings.getOrDefault(recipeBookType, class_5411.class_5412.field_54549);
    }

    public void updateSettings(class_5421 recipeBookType, UnaryOperator<class_5411.class_5412> updater) {
        this.moddedSettings.put(recipeBookType, updater.apply(this.moddedSettings.getOrDefault(recipeBookType, class_5411.class_5412.field_54549)));
    }

    public boolean isOpen(class_5421 recipeBookType) {
        return this.getSettings(recipeBookType).comp_3247();
    }

    public void setOpen(class_5421 recipeBookType, boolean open) {
        this.updateSettings(recipeBookType, typeSettings -> typeSettings.method_64586(open));
    }

    public boolean isFiltering(class_5421 recipeBookType) {
        return this.getSettings(recipeBookType).comp_3248();
    }

    public void setFiltering(class_5421 recipeBookType, boolean filtering) {
        this.updateSettings(recipeBookType, typeSettings -> typeSettings.method_64587(filtering));
    }

    public void replaceFrom(CustomRecipeBookSettings customRecipeBookSettings) {
        this.moddedSettings.clear();
        this.moddedSettings.putAll(customRecipeBookSettings.moddedSettings);
    }

    public CustomRecipeBookSettings copy() {
        return new CustomRecipeBookSettings(new EnumMap<>(this.moddedSettings));
    }
}
