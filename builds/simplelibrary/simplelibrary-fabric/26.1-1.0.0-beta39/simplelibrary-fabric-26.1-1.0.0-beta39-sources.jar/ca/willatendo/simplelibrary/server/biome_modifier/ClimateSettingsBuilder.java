package ca.willatendo.simplelibrary.server.biome_modifier;

import net.minecraft.class_1959;

// Modified from Neoforge
public final class ClimateSettingsBuilder {
    private boolean hasPrecipitation;
    private float temperature;
    private class_1959.class_5484 temperatureModifier;
    private float downfall;

    public static ClimateSettingsBuilder copyOf(class_1959.class_5482 settings) {
        return ClimateSettingsBuilder.create(settings.comp_1187(), settings.comp_844(), settings.comp_845(), settings.comp_846());
    }

    public static ClimateSettingsBuilder create(boolean hasPrecipitation, float temperature, class_1959.class_5484 temperatureModifier, float downfall) {
        return new ClimateSettingsBuilder(hasPrecipitation, temperature, temperatureModifier, downfall);
    }

    private ClimateSettingsBuilder(boolean hasPrecipitation, float temperature, class_1959.class_5484 temperatureModifier, float downfall) {
        this.hasPrecipitation = hasPrecipitation;
        this.temperature = temperature;
        this.temperatureModifier = temperatureModifier;
        this.downfall = downfall;
    }

    public class_1959.class_5482 build() {
        return new class_1959.class_5482(this.hasPrecipitation, this.temperature, this.temperatureModifier, this.downfall);
    }

    public boolean hasPrecipitation() {
        return hasPrecipitation;
    }

    public void setHasPrecipitation(boolean hasPrecipitation) {
        this.hasPrecipitation = hasPrecipitation;
    }

    public float getTemperature() {
        return temperature;
    }

    public void setTemperature(float temperature) {
        this.temperature = temperature;
    }

    public class_1959.class_5484 getTemperatureModifier() {
        return temperatureModifier;
    }

    public void setTemperatureModifier(class_1959.class_5484 temperatureModifier) {
        this.temperatureModifier = temperatureModifier;
    }

    public float getDownfall() {
        return downfall;
    }

    public void setDownfall(float downfall) {
        this.downfall = downfall;
    }
}
