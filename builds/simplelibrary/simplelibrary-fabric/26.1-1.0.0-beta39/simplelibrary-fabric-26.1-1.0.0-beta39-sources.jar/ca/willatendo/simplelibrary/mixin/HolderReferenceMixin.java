package ca.willatendo.simplelibrary.mixin;

import ca.willatendo.simplelibrary.injects.HolderExtension;
import ca.willatendo.simplelibrary.server.data_maps.DataMapType;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7225;
import net.minecraft.class_7876;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_6880.class_6883.class)
public abstract class HolderReferenceMixin<T> implements HolderExtension<T> {
    @Shadow
    @Final
    private class_7876<T> owner;

    @Shadow
    public abstract class_5321<T> key();

    public <A> A getData(DataMapType<T, A> type) {
        class_7876<T> holderOwner = this.owner;
        if (holderOwner instanceof class_7225.class_7226<T> lookup) {
            return (A) lookup.getData(type, this.key());
        } else {
            return null;
        }
    }
}
