package ca.willatendo.simplelibrary.server.recipe;

import net.minecraft.class_1860;
import net.minecraft.class_3956;
import net.minecraft.class_7923;

public final class SimpleRecipeType<T extends class_1860<?>> implements class_3956<T> {
    @Override
    public String toString() {
        return class_7923.field_41188.method_10221(this).method_12832();
    }
}
