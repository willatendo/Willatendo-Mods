package ca.willatendo.simplelibrary.server.event;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_7697;

public interface FeatureFlagRegistryEvent {
    Event<FeatureFlagRegistryEvent> EVENT = EventFactory.createArrayBacked(FeatureFlagRegistryEvent.class, callbacks -> builder -> {
        for (FeatureFlagRegistryEvent callback : callbacks) {
            callback.register(builder);
        }
    });

    void register(class_7697.class_7698 builder);
}
