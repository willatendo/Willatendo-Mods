package ca.willatendo.simplelibrary.server;

import ca.willatendo.simplelibrary.server.data_maps.SimpleLibraryDataMaps;
import ca.willatendo.simplelibrary.server.data_maps.buillt_in.MonsterRoomMob;
import ca.willatendo.simplelibrary.server.event.DataMapEvents;
import java.util.Map;
import java.util.Objects;
import net.minecraft.class_1299;
import net.minecraft.class_5321;
import net.minecraft.class_5819;
import net.minecraft.class_6010;
import net.minecraft.class_6012;
import net.minecraft.class_7924;

public final class MonsterRoomHooks {
    private static class_6012<class_1299> monsterRoomMobs = class_6012.method_34990();

    public static void init() {
        DataMapEvents.UPDATE_DATA_MAPS.register((registryAccess, registry, updateCause) -> {
            if (registry.method_46765() == class_7924.field_41266) {
                monsterRoomMobs = class_6012.method_34988(((Map<class_5321<class_1299<?>>, MonsterRoomMob>) registry.getDataMap(SimpleLibraryDataMaps.MONSTER_ROOM_MOBS)).entrySet().stream().map(entry -> {
                    class_1299 type = (class_1299) Objects.requireNonNull(registry.method_29107((class_5321) entry.getKey()), "Nonexistent entity " + entry.getKey() + " in monster room datamap!");
                    return new class_6010<>(type, entry.getValue().weight());
                }).toList());
            }
        });
    }

    public static class_1299<?> getRandomMonsterRoomMob(class_5819 rand) {
        return monsterRoomMobs.method_66216(rand);
    }
}
