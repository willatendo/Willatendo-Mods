package ca.willatendo.simplelibrary.mixin.client;

import ca.willatendo.simplelibrary.client.CustomRecipeBooks;
import ca.willatendo.simplelibrary.client.RecipeBookManager;
import ca.willatendo.simplelibrary.client.event.SimpleScreenEvents;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_542;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_310.class)
public class MinecraftMixin {
    @Inject(at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/platform/Window;updateVsync(Z)V"), method = "<init>")
    private void init(class_542 gameConfig, CallbackInfo ci) {
        RecipeBookManager.init();
        CustomRecipeBooks.init();
    }

    @Inject(method = "setScreen", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screens/Screen;removed()V"))
    private void frameworkOnScreenClosed(class_437 screen, CallbackInfo ci) {
        class_310 minecraft = (class_310) (Object) this;
        SimpleScreenEvents.CLOSING.invoker().onScreenClose(minecraft.field_1755);
    }
}
