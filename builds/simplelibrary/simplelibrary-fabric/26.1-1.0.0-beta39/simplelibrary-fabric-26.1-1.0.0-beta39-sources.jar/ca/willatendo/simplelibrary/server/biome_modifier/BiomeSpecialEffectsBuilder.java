package ca.willatendo.simplelibrary.server.biome_modifier;

import java.util.Optional;
import net.minecraft.class_4763;

// Modified from Neoforge
public final class BiomeSpecialEffectsBuilder extends class_4763.class_4764 {
    public static BiomeSpecialEffectsBuilder copyOf(class_4763 baseEffects) {
        BiomeSpecialEffectsBuilder builder = BiomeSpecialEffectsBuilder.create(baseEffects.comp_5169());
        builder.field_26425 = baseEffects.comp_5173();
        baseEffects.comp_5170().ifPresent(builder::method_30821);
        baseEffects.comp_5171().ifPresent(builder::method_68149);
        baseEffects.comp_5172().ifPresent(builder::method_30822);
        return builder;
    }

    public static BiomeSpecialEffectsBuilder create(int waterColor) {
        return new BiomeSpecialEffectsBuilder(waterColor);
    }

    private BiomeSpecialEffectsBuilder(int waterColor) {
        super();
        this.method_24395(waterColor);
    }

    public int waterColor() {
        return this.field_22072.getAsInt();
    }

    public class_4763.class_5486 getGrassColorModifier() {
        return this.field_26425;
    }

    public Optional<Integer> getFoliageColorOverride() {
        return this.field_26423;
    }

    public Optional<Integer> getDryFoliageColorOverride() {
        return this.field_57100;
    }

    public Optional<Integer> getGrassColorOverride() {
        return this.field_26424;
    }
}
