package ca.willatendo.simplelibrary.injects;

import ca.willatendo.simplelibrary.server.data_maps.DataMapType;
import net.minecraft.class_5321;
import net.minecraft.class_6880;

public interface HolderExtension<T> {
    default class_5321<T> getKey() {
        return (class_5321) ((class_6880) this).method_40230().orElse((Object) null);
    }

    default <R> R getData(DataMapType<T, R> type) {
        throw new RuntimeException("This has not been registered correctly! " + this.getClass());
    }
}
