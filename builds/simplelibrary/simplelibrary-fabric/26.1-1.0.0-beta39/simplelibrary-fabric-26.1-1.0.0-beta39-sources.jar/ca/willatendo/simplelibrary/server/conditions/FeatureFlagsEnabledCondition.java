package ca.willatendo.simplelibrary.server.conditions;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_7699;
import net.minecraft.class_7701;

// Modified from Neoforge
public record FeatureFlagsEnabledCondition(class_7699 flags) implements ICondition {
    public static final MapCodec<FeatureFlagsEnabledCondition> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(class_7701.field_40181.fieldOf("flags").forGetter(FeatureFlagsEnabledCondition::flags)).apply(instance, FeatureFlagsEnabledCondition::new));

    public FeatureFlagsEnabledCondition {
        if (flags.method_58398()) {
            throw new IllegalArgumentException("FeatureFlagsEnabledCondition requires a non-empty feature flag set");
        }
    }

    @Override
    public boolean test(IContext context) {
        return this.flags.method_45400(context.enabledFeatures());
    }

    @Override
    public MapCodec<? extends ICondition> codec() {
        return CODEC;
    }
}
