package ca.willatendo.simplelibrary.core.registry.sub;

import ca.willatendo.simplelibrary.core.holder.SimpleHolder;
import ca.willatendo.simplelibrary.core.registry.SimpleRegistry;
import ca.willatendo.simplelibrary.core.utils.CoreUtils;
import ca.willatendo.simplelibrary.server.utils.ServerUtils;
import java.util.function.Supplier;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1690;
import net.minecraft.class_1792;
import net.minecraft.class_5321;
import net.minecraft.class_7264;
import net.minecraft.class_7924;

public class EntityTypeSubRegistry extends SimpleRegistry<class_1299<?>> {
    public EntityTypeSubRegistry(String modId) {
        super(class_7924.field_41266, modId);
    }

    public SimpleHolder<class_1299<class_1690>> registerBoat(String name, Supplier<class_1792> boatItem) {
        SimpleHolder<class_1299<class_1690>> boat = this.register(name, ServerUtils.<class_1690>simpleEntityType((entityType, level) -> new class_1690(entityType, level, boatItem), class_1311.field_17715, 1.375F, 0.5625F).method_63006().method_55687(0.5625F).method_27299(10));
        return boat;
    }

    public SimpleHolder<class_1299<class_7264>> registerChestBoat(String name, Supplier<class_1792> boatItem) {
        return this.register(name, ServerUtils.<class_7264>simpleEntityType((entityType, level) -> new class_7264(entityType, level, boatItem), class_1311.field_17715, 1.375F, 0.5625F).method_63006().method_55687(0.5625F).method_27299(10));
    }


    public <T extends class_1297> SimpleHolder<class_1299<T>> register(String name, class_1299.class_1300<T> builder) {
        return this.register(name, () -> builder.method_5905(class_5321.method_29179(this.registryKey, CoreUtils.resource(this.modId, name))));
    }
}
