package ca.willatendo.simplelibrary.mixin;

import ca.willatendo.simplelibrary.server.data_maps.SimpleLibraryDataMaps;
import ca.willatendo.simplelibrary.server.data_maps.buillt_in.ParrotImitation;
import net.minecraft.class_1299;
import net.minecraft.class_1453;
import net.minecraft.class_3414;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1453.class)
public class ParrotMixin {
    @Inject(at = @At("HEAD"), method = "getImitatedSound", cancellable = true)
    private static void getImitatedSound(class_1299<?> entityType, CallbackInfoReturnable<class_3414> cir) {
        ParrotImitation parrotImitation = (ParrotImitation) entityType.method_40124().getData(SimpleLibraryDataMaps.PARROT_IMITATIONS);
        if (parrotImitation != null) {
            cir.setReturnValue(parrotImitation.sound());
        }
    }
}
