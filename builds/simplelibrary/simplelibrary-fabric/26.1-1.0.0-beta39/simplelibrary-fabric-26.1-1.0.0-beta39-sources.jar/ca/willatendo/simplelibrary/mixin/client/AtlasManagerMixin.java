package ca.willatendo.simplelibrary.mixin.client;

import ca.willatendo.simplelibrary.server.event.RegisterTextureAtlasesEvent;
import org.apache.commons.compress.utils.Lists;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1059;
import net.minecraft.class_1060;
import net.minecraft.class_11697;
import net.minecraft.class_2960;

@Mixin(class_11697.class)
public class AtlasManagerMixin {
    @Shadow
    @Final
    private Map<class_2960, class_11697.class_7772> atlasByTexture;
    @Shadow
    @Final
    private Map<class_2960, class_11697.class_7772> atlasById;

    @Inject(at = @At("TAIL"), method = "<init>")
    private void init(class_1060 textureManager, int maxMipmapLevels, CallbackInfo ci) {
        List<class_11697.class_11698> moddedAtlases = Lists.newArrayList();
        RegisterTextureAtlasesEvent.EVENT.invoker().register(moddedAtlases::add);
        for (class_11697.class_11698 atlasConfig : moddedAtlases) {
            class_1059 textureAtlas = new class_1059(atlasConfig.comp_4553());
            textureManager.method_4616(atlasConfig.comp_4553(), textureAtlas);
            class_11697.class_7772 atlasEntry = new class_11697.class_7772(textureAtlas, atlasConfig);
            this.atlasByTexture.put(atlasConfig.comp_4553(), atlasEntry);
            this.atlasById.put(atlasConfig.comp_4554(), atlasEntry);
        }
    }
}
