package ca.willatendo.simplelibrary.server.data_maps.buillt_in;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_3414;
import net.minecraft.class_7923;

public record ParrotImitation(class_3414 sound) {
    public static final Codec<ParrotImitation> SOUND_CODEC = class_7923.field_41172.method_39673().xmap(ParrotImitation::new, ParrotImitation::sound);
    public static final Codec<ParrotImitation> CODEC = Codec.withAlternative(RecordCodecBuilder.create(instance -> instance.group(class_7923.field_41172.method_39673().fieldOf("sound").forGetter(ParrotImitation::sound)).apply(instance, ParrotImitation::new)), SOUND_CODEC);
}
