package ca.willatendo.simplelibrary.mixin;

import ca.willatendo.simplelibrary.injects.ReloadableServerResourcesExtension;
import ca.willatendo.simplelibrary.server.conditions.ConditionContext;
import ca.willatendo.simplelibrary.server.conditions.ICondition;
import ca.willatendo.simplelibrary.server.event.AddReloadListenersEvent;
import ca.willatendo.simplelibrary.server.event.TagEvents;
import com.llamalad7.mixinextras.sugar.Local;
import org.slf4j.Logger;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_12096;
import net.minecraft.class_2170;
import net.minecraft.class_2378;
import net.minecraft.class_3302;
import net.minecraft.class_3902;
import net.minecraft.class_5350;
import net.minecraft.class_7225;
import net.minecraft.class_7659;
import net.minecraft.class_7699;
import net.minecraft.class_7780;
import net.minecraft.class_9383;

@Mixin(class_5350.class)
public class ReloadableServerResourcesMixin implements ReloadableServerResourcesExtension {
    @Shadow
    @Final
    private static Logger LOGGER;
    @Shadow
    @Final
    private static CompletableFuture<class_3902> DATA_RELOAD_INITIAL_TASK;
    @Final
    private class_7225.class_7874 registryLookup;
    @Final
    private ICondition.IContext context;

    @Inject(at = @At("TAIL"), method = "<init>")
    private void init(class_7780<class_7659> layeredRegistryAccess, class_7225.class_7874 provider, class_7699 enabledFeatures, class_2170.class_5364 commandSelection, List<class_2378.class_10106<?>> pendingTags, class_12096 permissionSet, CallbackInfo ci) {
        this.registryLookup = provider;
        this.context = new ConditionContext(pendingTags, layeredRegistryAccess.method_45926(), enabledFeatures);
    }

    @Override
    public ICondition.IContext getConditionContext() {
        return this.context;
    }


    @ModifyArg(method = {"method_58296(Lnet/minecraft/world/flag/FeatureFlagSet;Lnet/minecraft/commands/Commands$CommandSelection;Ljava/util/List;Lnet/minecraft/server/permissions/PermissionSet;Lnet/minecraft/server/packs/resources/ResourceManager;Ljava/util/concurrent/Executor;Ljava/util/concurrent/Executor;Lnet/minecraft/server/ReloadableServerRegistries$LoadResult;)Ljava/util/concurrent/CompletionStage;"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/server/packs/resources/SimpleReloadInstance;create(Lnet/minecraft/server/packs/resources/ResourceManager;Ljava/util/List;Ljava/util/concurrent/Executor;Ljava/util/concurrent/Executor;Ljava/util/concurrent/CompletableFuture;Z)Lnet/minecraft/server/packs/resources/ReloadInstance;"))
    private static List<class_3302> onSetupDataReloaders(List<class_3302> reloaders, @Local(argsOnly = true) class_9383.class_9842 loadResult, @Local(argsOnly = true) class_7699 featureSet, @Local class_5350 dataPackContents) {
        ArrayList<class_3302> list = new ArrayList(reloaders);
        AddReloadListenersEvent.EVENT.invoker().onAddReloadListeners(list, dataPackContents.getConditionContext(), dataPackContents);
        return Collections.unmodifiableList(list);
    }


    @Inject(at = @At("TAIL"), method = "updateStaticRegistryTags")
    private void updateStaticRegistryTags(CallbackInfo ci) {
        TagEvents.UPDATE_TAGS.invoker().update(this.registryLookup, false, false);
    }
}
