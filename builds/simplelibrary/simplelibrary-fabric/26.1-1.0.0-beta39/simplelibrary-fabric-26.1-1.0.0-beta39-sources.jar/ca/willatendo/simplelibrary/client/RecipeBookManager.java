package ca.willatendo.simplelibrary.client;

import ca.willatendo.simplelibrary.server.event.RegisterRecipeBookSearchCategoriesEvent;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_10287;
import net.minecraft.class_10355;

public final class RecipeBookManager {
    private static Map<class_10287, List<class_10355>> searchCategories = Map.of();

    public static boolean hasSearchCategories(class_10287 extendedRecipeBookCategory) {
        return RecipeBookManager.searchCategories.containsKey(extendedRecipeBookCategory);
    }

    public static Map<class_10287, List<class_10355>> getSearchCategories() {
        return RecipeBookManager.searchCategories;
    }

    public static void init() {
        IdentityHashMap<class_10287, List<class_10355>> searchCategories = new IdentityHashMap<>();
        RegisterRecipeBookSearchCategoriesEvent.EVENT.invoker().register(searchCategories::put);
        RecipeBookManager.searchCategories = Collections.unmodifiableMap(searchCategories);
    }
}
