package ca.willatendo.simplelibrary.mixin;

import ca.willatendo.simplelibrary.injects.RecipeBookExtension;
import ca.willatendo.simplelibrary.server.stats.CustomRecipeBookSettings;
import ca.willatendo.simplelibrary.server.stats.utils.RecipeBookUtils;
import net.minecraft.class_3439;
import net.minecraft.class_5421;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_3439.class)
public class RecipeBookMixin implements RecipeBookExtension {
    protected final CustomRecipeBookSettings customRecipeBookSettings = new CustomRecipeBookSettings();

    @Override
    public CustomRecipeBookSettings getCustomRecipeBookSettings() {
        return this.customRecipeBookSettings;
    }

    @Inject(at = @At("HEAD"), method = "isOpen", cancellable = true)
    private void isOpen(class_5421 recipeBookType, CallbackInfoReturnable<Boolean> cir) {
        if (RecipeBookUtils.isModded(recipeBookType)) {
            cir.setReturnValue(this.customRecipeBookSettings.isOpen(recipeBookType));
        }
    }

    @Inject(at = @At("HEAD"), method = "setOpen", cancellable = true)
    private void setOpen(class_5421 recipeBookType, boolean open, CallbackInfo ci) {
        if (RecipeBookUtils.isModded(recipeBookType)) {
            this.customRecipeBookSettings.setOpen(recipeBookType, open);
            ci.cancel();
        }
    }

    @Inject(at = @At("HEAD"), method = "isFiltering", cancellable = true)
    private void isFiltering(class_5421 recipeBookType, CallbackInfoReturnable<Boolean> cir) {
        if (RecipeBookUtils.isModded(recipeBookType)) {
            cir.setReturnValue(this.customRecipeBookSettings.isFiltering(recipeBookType));
        }
    }

    @Inject(at = @At("HEAD"), method = "setFiltering", cancellable = true)
    private void setFiltering(class_5421 recipeBookType, boolean filtering, CallbackInfo ci) {
        if (RecipeBookUtils.isModded(recipeBookType)) {
            this.customRecipeBookSettings.setFiltering(recipeBookType, filtering);
            ci.cancel();
        }
    }

    @Inject(at = @At("HEAD"), method = "setBookSetting", cancellable = true)
    private void setBookSetting(class_5421 recipeBookType, boolean open, boolean filtering, CallbackInfo ci) {
        if (RecipeBookUtils.isModded(recipeBookType)) {
            this.customRecipeBookSettings.setOpen(recipeBookType, open);
            this.customRecipeBookSettings.setFiltering(recipeBookType, filtering);
            ci.cancel();
        }
    }
}
