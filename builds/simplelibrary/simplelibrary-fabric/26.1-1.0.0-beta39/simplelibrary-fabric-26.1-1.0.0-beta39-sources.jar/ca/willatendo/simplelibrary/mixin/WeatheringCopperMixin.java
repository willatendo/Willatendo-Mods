package ca.willatendo.simplelibrary.mixin;

import ca.willatendo.simplelibrary.server.data_maps.DataMapHooks;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Optional;
import net.minecraft.class_2248;
import net.minecraft.class_5955;

@Mixin(class_5955.class)
public interface WeatheringCopperMixin {
    @Inject(at = @At("HEAD"), method = "getPrevious", cancellable = true)
    private static void getPrevious(class_2248 block, CallbackInfoReturnable<Optional<class_2248>> cir) {
        cir.setReturnValue(Optional.ofNullable(DataMapHooks.getPreviousOxidizedStage(block)));
    }

    @Inject(at = @At("HEAD"), method = "getFirst", cancellable = true)
    private static void getFirst(class_2248 blockIn, CallbackInfoReturnable<class_2248> cir) {
        class_2248 blockOut = blockIn;

        for (class_2248 block = DataMapHooks.getPreviousOxidizedStage(blockIn); block != null; block = DataMapHooks.getPreviousOxidizedStage(block)) {
            blockOut = block;
        }

        cir.setReturnValue(blockOut);
    }

    @Inject(at = @At("HEAD"), method = "getNext", cancellable = true)
    private static void getNext(class_2248 block, CallbackInfoReturnable<Optional<class_2248>> cir) {
        cir.setReturnValue(Optional.ofNullable(DataMapHooks.getNextOxidizedStage(block)));
    }
}
