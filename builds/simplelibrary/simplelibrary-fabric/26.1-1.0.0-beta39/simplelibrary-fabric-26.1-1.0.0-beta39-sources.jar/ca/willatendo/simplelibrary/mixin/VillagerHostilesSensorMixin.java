package ca.willatendo.simplelibrary.mixin;

import ca.willatendo.simplelibrary.server.data_maps.SimpleLibraryDataMaps;
import ca.willatendo.simplelibrary.server.data_maps.buillt_in.AcceptableVillagerDistance;
import com.google.common.collect.ImmutableMap;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_4150;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_4150.class)
public class VillagerHostilesSensorMixin {
    @Shadow
    @Final
    private static ImmutableMap<class_1299<?>, Float> ACCEPTABLE_DISTANCE_FROM_HOSTILES;

    @Inject(at = @At("HEAD"), method = "isClose", cancellable = true)
    private void isClose(class_1309 attacker, class_1309 target, CallbackInfoReturnable<Boolean> cir) {
        AcceptableVillagerDistance acceptableDistanceFromHostile = (AcceptableVillagerDistance) target.method_5864().method_40124().getData(SimpleLibraryDataMaps.ACCEPTABLE_VILLAGER_DISTANCES);
        float f = acceptableDistanceFromHostile != null ? acceptableDistanceFromHostile.distance() : ACCEPTABLE_DISTANCE_FROM_HOSTILES.get(target.method_5864());
        cir.setReturnValue(target.method_5858(attacker) <= f * f);
    }

    @Inject(at = @At("HEAD"), method = "isHostile", cancellable = true)
    private void isHostile(class_1309 entity, CallbackInfoReturnable<Boolean> cir) {
        var acceptableDistanceFromHostile = (AcceptableVillagerDistance) entity.method_5864().method_40124().getData(SimpleLibraryDataMaps.ACCEPTABLE_VILLAGER_DISTANCES);
        cir.setReturnValue(acceptableDistanceFromHostile != null || ACCEPTABLE_DISTANCE_FROM_HOSTILES.containsKey(entity.method_5864()));
    }
}
