package ca.willatendo.simplelibrary.server.data_maps;

import com.mojang.datafixers.util.Either;
import java.util.*;
import net.minecraft.class_2378;
import net.minecraft.class_5321;
import net.minecraft.class_6862;

// Modified from Neoforge
@FunctionalInterface
public interface DataMapValueMerger<R, T> {
    T merge(class_2378<R> registry, Either<class_6862<R>, class_5321<R>> first, T firstValue, Either<class_6862<R>, class_5321<R>> second, T secondValue);

    static <T, R> DataMapValueMerger<R, T> defaultMerger() {
        return (registry, first, firstValue, second, secondValue) -> secondValue;
    }

    static <T, R> DataMapValueMerger<R, List<T>> listMerger() {
        return (registry, first, firstValue, second, secondValue) -> {
            final List<T> list = new ArrayList<>(firstValue);
            list.addAll(secondValue);
            return list;
        };
    }

    static <T, R> DataMapValueMerger<R, Set<T>> setMerger() {
        return (registry, first, firstValue, second, secondValue) -> {
            final Set<T> set = new HashSet<>(firstValue);
            set.addAll(secondValue);
            return set;
        };
    }

    static <K, V, R> DataMapValueMerger<R, Map<K, V>> mapMerger() {
        return (registry, first, firstValue, second, secondValue) -> {
            final Map<K, V> map = new HashMap<>(firstValue);
            map.putAll(secondValue);
            return map;
        };
    }
}
