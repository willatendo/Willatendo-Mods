package ca.willatendo.simplelibrary.mixin;

import ca.willatendo.simplelibrary.injects.RegistryLookupExtension;
import ca.willatendo.simplelibrary.server.data_maps.DataMapType;
import org.spongepowered.asm.mixin.Mixin;

import java.util.IdentityHashMap;
import java.util.Map;
import net.minecraft.class_2370;
import net.minecraft.class_5321;

@Mixin(class_2370.class)
public abstract class MappedRegistryMixin<T> implements RegistryLookupExtension<T> {
    private final Map<DataMapType<T, ?>, Map<class_5321<T>, ?>> dataMaps = new IdentityHashMap<>();

    @Override
    public void clearData() {
        this.dataMaps.clear();
    }

    @Override
    public <A> A getData(DataMapType<T, A> type, class_5321<T> key) {
        Map<class_5321<T>, ?> innerMap = this.dataMaps.get(type);
        return innerMap == null ? null : (A) innerMap.get(key);
    }

    @Override
    public <A> Map<class_5321<T>, A> getDataMap(DataMapType<T, A> dataMapType) {
        return (Map) this.dataMaps.getOrDefault(dataMapType, Map.of());
    }

    @Override
    public <A> void putData(DataMapType<T, A> type, Map<class_5321<T>, A> map) {
        this.dataMaps.put(type, map);
    }

    public Map<DataMapType<T, ?>, Map<class_5321<T>, ?>> getDataMaps() {
        return this.dataMaps;
    }
}
