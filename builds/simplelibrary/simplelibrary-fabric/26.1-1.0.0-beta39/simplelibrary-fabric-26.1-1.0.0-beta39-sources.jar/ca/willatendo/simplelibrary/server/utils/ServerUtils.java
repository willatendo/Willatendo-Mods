package ca.willatendo.simplelibrary.server.utils;

import ca.willatendo.simplelibrary.core.registry.SimpleRegistryBuilder;
import ca.willatendo.simplelibrary.platform.SimpleLibraryPlatformHelper;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_3222;
import net.minecraft.class_3908;
import net.minecraft.class_5321;
import net.minecraft.class_5421;

public final class ServerUtils {
    private ServerUtils() {
    }

    public static class_5421 getRecipeBookType(String modId, String name) {
        return SimpleLibraryPlatformHelper.INSTANCE.getRecipeBookType(modId, name);
    }

    public static <T extends class_1297> class_1299.class_1300<T> simpleEntityType(class_1299.class_4049<T> entityFactory, class_1311 mobCategory, float width, float height) {
        return class_1299.class_1300.method_5903(entityFactory, mobCategory).method_17687(width, height);
    }

    public static <T> class_2378<T> createRegistry(class_5321<class_2378<T>> resourceKey, SimpleRegistryBuilder simpleRegistryBuilder) {
        return SimpleLibraryPlatformHelper.INSTANCE.createRegistry(resourceKey, simpleRegistryBuilder);
    }

    public static void openContainer(class_3908 menuProvider, class_2338 blockPos, class_3222 serverPlayer) {
        SimpleLibraryPlatformHelper.INSTANCE.openContainer(menuProvider, blockPos, serverPlayer);
    }

    public static class_1799 quickMoveItemStack(class_1703 abstractContainerMenu, class_1657 player, int slotIndex, int containerSize) {
        class_1799 itemstack = class_1799.field_8037;
        class_1735 slot = abstractContainerMenu.field_7761.get(slotIndex);
        if (slot != null && slot.method_7681()) {
            class_1799 slotStack = slot.method_7677();
            itemstack = slotStack.method_7972();
            if (slotIndex < containerSize) {
                if (!abstractContainerMenu.method_7616(slotStack, containerSize, containerSize + 36, true)) {
                    return class_1799.field_8037;
                }
            } else if (!abstractContainerMenu.method_7616(slotStack, 0, containerSize, false)) {
                return class_1799.field_8037;
            }

            if (slotStack.method_7960()) {
                slot.method_53512(class_1799.field_8037);
            } else {
                slot.method_7668();
            }

            if (slotStack.method_7947() == itemstack.method_7947()) {
                return class_1799.field_8037;
            }

            slot.method_7667(player, slotStack);
        }

        return itemstack;
    }
}
