package ca.willatendo.simplelibrary.server.data_maps;

import ca.willatendo.simplelibrary.server.data_maps.buillt_in.FurnaceFuel;
import ca.willatendo.simplelibrary.server.data_maps.buillt_in.Oxidizable;
import ca.willatendo.simplelibrary.server.data_maps.buillt_in.Waxable;
import ca.willatendo.simplelibrary.server.event.DataMapEvents;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2680;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_5953;
import net.minecraft.class_5955;
import net.minecraft.class_7699;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_9895;

public final class DataMapHooks {
    public static boolean didHaveToFallbackToVanillaMaps = false;
    private static final Map<class_2248, class_2248> INVERSE_OXIDIZABLES_DATAMAP_INTERNAL = new HashMap<>();
    private static final Map<class_2248, class_2248> INVERSE_WAXABLES_DATAMAP_INTERNAL = new HashMap<>();
    public static final Map<class_2248, class_2248> INVERSE_OXIDIZABLES_DATAMAP = Collections.unmodifiableMap(INVERSE_OXIDIZABLES_DATAMAP_INTERNAL);
    public static final Map<class_2248, class_2248> INVERSE_WAXABLES_DATAMAP = Collections.unmodifiableMap(INVERSE_WAXABLES_DATAMAP_INTERNAL);

    public static class_2248 getNextOxidizedStage(class_2248 block) {
        Oxidizable oxidizable = (Oxidizable) block.method_40142().getData(SimpleLibraryDataMaps.OXIDIZABLES);
        return oxidizable != null ? oxidizable.nextOxidationStage() : class_5955.field_29564.get().get(block);
    }

    public static class_2248 getPreviousOxidizedStage(class_2248 block) {
        return INVERSE_OXIDIZABLES_DATAMAP.containsKey(block) ? INVERSE_OXIDIZABLES_DATAMAP.get(block) : class_5955.field_29565.get().get(block);
    }

    public static class_2248 getBlockWaxed(class_2248 block) {
        Waxable waxable = (Waxable) block.method_40142().getData(SimpleLibraryDataMaps.WAXABLES);
        return waxable != null ? waxable.waxed() : class_5953.field_29560.get().get(block);
    }

    public static class_2248 getBlockUnwaxed(class_2248 block) {
        return INVERSE_WAXABLES_DATAMAP.containsKey(block) ? INVERSE_WAXABLES_DATAMAP.get(block) : class_5953.field_29561.get().get(block);
    }

    public static class_9895 populateFuelValues(class_5455 lookupProvider, class_7699 features) {
        class_9895.class_9896 builder = new class_9895.class_9896(lookupProvider, features);
        class_2378<class_1792> registry = lookupProvider.method_30530(class_7924.field_41197);
        registry.getDataMap(SimpleLibraryDataMaps.FURNACE_FUELS).forEach((key, fuel) -> builder.method_61762(registry.method_29107((class_5321<class_1792>) key), ((FurnaceFuel) fuel).burnTime()));
        return builder.method_61756();
    }

    public static void init() {
        DataMapEvents.UPDATE_DATA_MAPS.register((registryAccess, registry, updateCause) -> {
            if (registry.method_46765() == class_7924.field_41254) {
                INVERSE_OXIDIZABLES_DATAMAP_INTERNAL.clear();
                INVERSE_WAXABLES_DATAMAP_INTERNAL.clear();

                registry.getDataMap(SimpleLibraryDataMaps.OXIDIZABLES).forEach((resourceKey, oxidizable) -> {
                    var block = class_7923.field_41175.method_29107((class_5321<class_2248>) resourceKey);

                    INVERSE_OXIDIZABLES_DATAMAP_INTERNAL.put(((Oxidizable) oxidizable).nextOxidationStage(), block);

                    for (class_2680 state : block.method_9595().method_11662()) {
                        state.method_26200();
                    }
                });

                class_5955.field_29565.get().forEach((after, before) -> {
                    if (!INVERSE_OXIDIZABLES_DATAMAP_INTERNAL.containsKey(after)) {
                        INVERSE_OXIDIZABLES_DATAMAP_INTERNAL.put(after, before);
                        didHaveToFallbackToVanillaMaps = true;
                    }
                });

                registry.getDataMap(SimpleLibraryDataMaps.WAXABLES).forEach((resourceKey, waxable) -> INVERSE_WAXABLES_DATAMAP_INTERNAL.put(((Waxable) waxable).waxed(), class_7923.field_41175.method_29107((class_5321<class_2248>) resourceKey)));

                class_5953.field_29561.get().forEach((after, before) -> {
                    if (!INVERSE_WAXABLES_DATAMAP_INTERNAL.containsKey(after)) {
                        INVERSE_OXIDIZABLES_DATAMAP_INTERNAL.put(after, before);
                        didHaveToFallbackToVanillaMaps = true;
                    }
                });
            }
        });
    }
}
