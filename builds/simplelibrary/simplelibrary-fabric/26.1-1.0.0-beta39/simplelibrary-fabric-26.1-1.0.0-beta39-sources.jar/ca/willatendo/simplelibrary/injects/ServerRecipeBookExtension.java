package ca.willatendo.simplelibrary.injects;

import ca.willatendo.simplelibrary.server.stats.CustomRecipeBookSettings;
import java.util.function.Predicate;
import net.minecraft.class_1860;
import net.minecraft.class_5321;

public interface ServerRecipeBookExtension {
    default void loadCustomUntrusted(CustomRecipeBookSettings customRecipeBookSettings, Predicate<class_5321<class_1860<?>>> predicate) {
        throw new RuntimeException("This has not been registered correctly! " + this.getClass());
    }
}
