package ca.willatendo.simplelibrary.server.event;

import ca.willatendo.simplelibrary.server.data_maps.DataMapType;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.fabricmc.fabric.impl.registry.sync.DynamicRegistriesImpl;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_7655;
import java.util.HashMap;
import java.util.Map;

public final class DataMapEvents {
    public static final Event<DataMapEvents.RegisterDataMap> REGISTER_DATA_MAPS = EventFactory.createArrayBacked(DataMapEvents.RegisterDataMap.class, callbacks -> dataMapTypes -> {
        for (DataMapEvents.RegisterDataMap callback : callbacks) {
            callback.register(dataMapTypes);
        }
    });
    public static final Event<DataMapEvents.DataMapsUpdate> UPDATE_DATA_MAPS = EventFactory.createArrayBacked(DataMapEvents.DataMapsUpdate.class, callbacks -> (registryAccess, registry, updateCause) -> {
        for (DataMapEvents.DataMapsUpdate callback : callbacks) {
            callback.update(registryAccess, registry, updateCause);
        }
    });

    private DataMapEvents() {
    }

    public static <T, R> void register(Map<class_5321<class_2378<?>>, Map<class_2960, DataMapType<?, ?>>> attachments, DataMapType<R, T> type) {
        class_5321<class_2378<R>> registry = type.registryKey();
        if (!registry.method_41185().method_12836().equals("minecraft") && DynamicRegistriesImpl.DYNAMIC_REGISTRY_KEYS.stream().anyMatch(data -> data.equals(registry)) && type.networkCodec() != null && class_7655.field_48709.stream().map(class_7655.class_7657::comp_985).anyMatch(resourceKey -> resourceKey.equals(registry))) {
            throw new UnsupportedOperationException("Cannot register synced data map " + type.id() + " for datapack registry " + registry.method_29177() + " that is not synced!");
        } else {
            Map<class_2960, DataMapType<?, ?>> map = attachments.computeIfAbsent((class_5321) registry, resourceKey -> new HashMap<>());
            if (map.containsKey(type.id())) {
                throw new IllegalArgumentException("Tried to register data map type with ID " + type.id() + " to registry " + registry.method_29177() + " twice");
            } else {
                map.put(type.id(), type);
            }
        }
    }

    @FunctionalInterface
    public interface RegisterDataMap {
        void register(Map<class_5321<class_2378<?>>, Map<class_2960, DataMapType<?, ?>>> dataMapTypes);
    }

    @FunctionalInterface
    public interface DataMapsUpdate {
        void update(class_5455 registryAccess, class_2378<?> registry, DataMapEvents.UpdateCause updateCause);
    }

    public enum UpdateCause {
        CLIENT_SYNC,
        SERVER_RELOAD
    }
}
