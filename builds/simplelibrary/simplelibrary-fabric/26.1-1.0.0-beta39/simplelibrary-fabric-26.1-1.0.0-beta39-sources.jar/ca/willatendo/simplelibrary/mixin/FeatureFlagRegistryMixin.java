package ca.willatendo.simplelibrary.mixin;

import ca.willatendo.simplelibrary.injects.FeatureFlagRegistryExtension;
import com.google.common.base.Preconditions;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import java.util.Map;
import net.minecraft.class_2960;
import net.minecraft.class_7696;
import net.minecraft.class_7697;

@Mixin(class_7697.class)
public class FeatureFlagRegistryMixin implements FeatureFlagRegistryExtension {
    @Shadow
    @Final
    private Map<class_2960, class_7696> names;

    @Override
    public class_7696 getFlag(class_2960 identifier) {
        return Preconditions.checkNotNull(this.names.get(identifier), "Flag %s was not registered", identifier);
    }
}
