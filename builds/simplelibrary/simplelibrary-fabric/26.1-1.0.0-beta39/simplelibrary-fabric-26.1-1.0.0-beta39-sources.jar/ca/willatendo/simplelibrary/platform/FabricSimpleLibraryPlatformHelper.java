package ca.willatendo.simplelibrary.platform;

import ca.willatendo.simplelibrary.client.event.RegisterRecipeBookOverlayEvent;
import ca.willatendo.simplelibrary.core.FabricPlatform;
import ca.willatendo.simplelibrary.core.registry.SimpleRegistryBuilder;
import ca.willatendo.simplelibrary.core.registry.sub.AttachmentTypesSubRegistry;
import ca.willatendo.simplelibrary.core.registry.sub.EntityDataSerializerSubRegistry;
import ca.willatendo.simplelibrary.core.registry.sub.FabricAttachmentTypesSubRegistry;
import ca.willatendo.simplelibrary.core.registry.sub.FabricEntityDataSerializerSubRegistry;
import ca.willatendo.simplelibrary.server.menu.ExtendedMenuSupplier;
import com.chocohead.mm.api.ClassTinkerers;
import com.mojang.datafixers.util.Pair;
import net.fabricmc.fabric.api.attachment.v1.AttachmentTarget;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.event.registry.FabricRegistryBuilder;
import net.fabricmc.fabric.api.event.registry.RegistryAttribute;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.particle.v1.FabricParticleTypes;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.fabricmc.fabric.impl.attachment.AttachmentRegistryImpl;
import net.minecraft.class_10295;
import net.minecraft.class_10352;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1761;
import net.minecraft.class_2338;
import net.minecraft.class_2370;
import net.minecraft.class_2378;
import net.minecraft.class_2400;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3908;
import net.minecraft.class_3917;
import net.minecraft.class_508;
import net.minecraft.class_5321;
import net.minecraft.class_5421;
import net.minecraft.class_7696;
import net.minecraft.class_7701;
import net.minecraft.class_8710;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.BiFunction;

public final class FabricSimpleLibraryPlatformHelper implements SimpleLibraryPlatformHelper {
    @Override
    public Platform getPlatform() {
        return new FabricPlatform();
    }

    @Override
    public void sendToServer(class_8710 customPacketPayload, class_8710... customPacketPayloads) {
        ClientPlayNetworking.send(customPacketPayload);
        Arrays.asList(customPacketPayloads).forEach(ClientPlayNetworking::send);
    }

    @Override
    public void sendToClient(class_3222 serverPlayer, class_8710 customPacketPayload) {
        ServerPlayNetworking.send(serverPlayer, customPacketPayload);
    }

    @Override
    public class_7696 getFeatureFlag(class_2960 identifier) {
        return class_7701.field_40180.getFlag(identifier);
    }

    @Override
    public class_5421 getRecipeBookType(String modId, String name) {
        return ClassTinkerers.getEnum(class_5421.class, name.toUpperCase());
    }

    @Override
    public <T> class_2378<T> createRegistry(class_5321<class_2378<T>> resourceKey, SimpleRegistryBuilder simpleRegistryBuilder) {
        FabricRegistryBuilder<T, class_2370<T>> fabricRegistryBuilder = FabricRegistryBuilder.createSimple(resourceKey);
        if (simpleRegistryBuilder.isSynced()) {
            fabricRegistryBuilder.attribute(RegistryAttribute.SYNCED);
        }
        return fabricRegistryBuilder.buildAndRegister();
    }

    @Override
    public AttachmentTypesSubRegistry createAttachmentTypesSubRegistry(String modId) {
        return new FabricAttachmentTypesSubRegistry(modId);
    }

    @Override
    public EntityDataSerializerSubRegistry createEntityDataSerializerSubRegistry(String modId) {
        return new FabricEntityDataSerializerSubRegistry(modId);
    }

    @Override
    public class_2400 createSimpleParticleType(boolean overrideLimiter) {
        return FabricParticleTypes.simple(overrideLimiter);
    }

    @Override
    public <T extends class_1703> class_3917<T> createMenuType(ExtendedMenuSupplier<T> extendedMenuSupplier) {
        return new ExtendedScreenHandlerType<>(extendedMenuSupplier::create, class_2338.field_48404.method_56430());
    }

    @Override
    public class_1761.class_7913 createCreativeModeTab() {
        return FabricItemGroup.builder();
    }

    @Override
    public <T> boolean hasData(T value, class_2960 attachmentType) {
        if (value instanceof AttachmentTarget attachmentTarget) {
            return attachmentTarget.hasAttached(Objects.requireNonNull(AttachmentRegistryImpl.get(attachmentType)));
        }
        return false;
    }

    @Override
    public <T, V> V getData(T value, class_2960 attachmentType) {
        if (value instanceof AttachmentTarget attachmentTarget) {
            return (V) attachmentTarget.getAttachedOrCreate(Objects.requireNonNull(AttachmentRegistryImpl.get(attachmentType)));
        }
        return null;
    }

    @Override
    public <T, V> void setData(T value, class_2960 attachmentType, V data) {
        if (value instanceof AttachmentTarget attachmentTarget) {
            attachmentTarget.setAttached((AttachmentType<V>) Objects.requireNonNull(AttachmentRegistryImpl.get(attachmentType)), data);
        }
    }

    @Override
    public <T> void removeData(T value, class_2960 attachmentType) {
        if (value instanceof AttachmentTarget attachmentTarget) {
            attachmentTarget.removeAttached(Objects.requireNonNull(AttachmentRegistryImpl.get(attachmentType)));
        }
    }

    @Override
    public void openContainer(class_3908 menuProvider, class_2338 blockPos, class_3222 serverPlayer) {
        serverPlayer.method_17355(new ExtendedScreenHandlerFactory<class_2338>() {
            @Override
            public class_2338 getScreenOpeningData(class_3222 serverPlayer1) {
                if (menuProvider instanceof class_2586 blockEntity) {
                    return blockEntity.method_11016();
                } else {
                    return blockPos;
                }
            }

            @Override
            public class_2561 method_5476() {
                return menuProvider.method_5476();
            }

            @Override
            public class_1703 createMenu(int windowId, class_1661 inventory, class_1657 player) {
                return menuProvider.createMenu(windowId, inventory, player);
            }
        });
    }

    @Override
    public void registerRecipeBookOverlayEvent(Map<class_2960, Pair<BiFunction<class_10295, class_10352, List<class_508.class_509.class_510>>, BiFunction<Boolean, Boolean, class_2960>>> map) {
        RegisterRecipeBookOverlayEvent.EVENT.invoker().register(map::put);
    }
}
