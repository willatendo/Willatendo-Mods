package ca.willatendo.simplelibrary.core.registry.sub;

import ca.willatendo.simplelibrary.core.holder.SimpleHolder;
import ca.willatendo.simplelibrary.core.registry.SimpleRegistry;
import net.minecraft.class_10355;
import net.minecraft.class_7924;

public class RecipeBookCategorySubRegistry extends SimpleRegistry<class_10355> {
    public RecipeBookCategorySubRegistry(String modId) {
        super(class_7924.field_54928, modId);
    }

    public SimpleHolder<class_10355> registerSimple(String name) {
        return this.register(name, class_10355::new);
    }
}
