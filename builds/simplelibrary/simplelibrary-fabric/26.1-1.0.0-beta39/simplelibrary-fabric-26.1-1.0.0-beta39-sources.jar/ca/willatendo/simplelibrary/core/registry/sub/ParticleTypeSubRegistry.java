package ca.willatendo.simplelibrary.core.registry.sub;

import ca.willatendo.simplelibrary.core.holder.SimpleHolder;
import ca.willatendo.simplelibrary.core.registry.SimpleRegistry;
import ca.willatendo.simplelibrary.platform.SimpleLibraryPlatformHelper;
import net.minecraft.class_2396;
import net.minecraft.class_2400;
import net.minecraft.class_7924;

public class ParticleTypeSubRegistry extends SimpleRegistry<class_2396<?>> {
    private ParticleTypeSubRegistry(String modId) {
        super(class_7924.field_41210, modId);
    }

    public SimpleHolder<class_2400> registerSimple(String name) {
        return this.registerSimple(name, false);
    }

    public SimpleHolder<class_2400> registerSimple(String name, boolean overrideLimiter) {
        return this.register(name, () -> SimpleLibraryPlatformHelper.INSTANCE.createSimpleParticleType(overrideLimiter));
    }
}
