package ca.willatendo.simplelibrary.server.data_maps.buillt_in;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_5699;

public record MonsterRoomMob(int weight) {
    public static final Codec<MonsterRoomMob> WEIGHT_CODEC = class_5699.field_33441.xmap(MonsterRoomMob::new, MonsterRoomMob::weight);
    public static final Codec<MonsterRoomMob> CODEC = Codec.withAlternative(RecordCodecBuilder.create(instance -> instance.group(class_5699.field_33441.fieldOf("weight").forGetter(MonsterRoomMob::weight)).apply(instance, MonsterRoomMob::new)), WEIGHT_CODEC);
}
