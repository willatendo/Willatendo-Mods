package ca.willatendo.simplelibrary.server.command;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_7157;

@FunctionalInterface
public interface CommandRegisterInformation {
    void register(CommandDispatcher<class_2168> commandDispatcher, class_7157 commandBuildContext, class_2170.class_5364 commandSelection);
}
