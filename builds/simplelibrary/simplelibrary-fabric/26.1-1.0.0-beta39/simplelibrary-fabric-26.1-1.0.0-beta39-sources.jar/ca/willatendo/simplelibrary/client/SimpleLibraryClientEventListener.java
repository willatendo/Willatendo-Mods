package ca.willatendo.simplelibrary.client;

import ca.willatendo.simplelibrary.client.filter.CreativeModeTabFilter;
import java.util.function.Consumer;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_437;

public record SimpleLibraryClientEventListener() implements ClientEventListener {
    @Override
    public void screenInitPostEvent(class_437 screen, Consumer<class_339> widgets) {
        CreativeModeTabFilter.CREATIVE_MODE_TAB_FILTERS.forEach(creativeModeTabFilter -> creativeModeTabFilter.modifyWidgetsEvent(screen, widgets));
    }

    @Override
    public void screenRenderPreEvent(class_437 screen, class_332 guiGraphics, int mouseX, int mouseY) {
        CreativeModeTabFilter.CREATIVE_MODE_TAB_FILTERS.forEach(creativeModeTabFilter -> creativeModeTabFilter.beforeDrawEvent(screen, guiGraphics, mouseX, mouseY));
    }

    @Override
    public void screenCloseEvent(class_437 screen) {
        CreativeModeTabFilter.CREATIVE_MODE_TAB_FILTERS.forEach(creativeModeTabFilter -> creativeModeTabFilter.closedEvent(screen));
    }

    @Override
    public void clientPlayerLoggingOut() {
        CreativeModeTabFilter.CREATIVE_MODE_TAB_FILTERS.forEach(CreativeModeTabFilter::loggingOutEvent);
    }
}
