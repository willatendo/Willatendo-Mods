package ca.willatendo.simplelibrary.server.biome_modifier;

import com.mojang.serialization.MapCodec;
import java.util.EnumSet;
import java.util.Set;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1959;
import net.minecraft.class_2893;
import net.minecraft.class_2922;
import net.minecraft.class_5483;
import net.minecraft.class_6010;
import net.minecraft.class_6012;
import net.minecraft.class_6796;
import net.minecraft.class_6880;
import net.minecraft.class_6885;
import net.minecraft.class_7923;

public final class BiomeModifiers {
    private BiomeModifiers() {
    }

    public record AddFeaturesBiomeModifier(class_6885<class_1959> biomes, class_6885<class_6796> features, class_2893.class_2895 step) implements BiomeModifier {
        @Override
        public void modify(class_6880<class_1959> biome, Phase phase, ModifiableBiomeInfo.BiomeInfo.Builder builder) {
            if (phase == Phase.ADD && this.biomes.method_40241(biome)) {
                BiomeGenerationSettingsBuilder generationSettings = builder.getGenerationSettings();
                this.features.forEach(holder -> generationSettings.method_46676(this.step, holder));
            }
        }

        @Override
        public MapCodec<? extends BiomeModifier> codec() {
            return SimpleLibraryBiomeModifierSerializers.ADD_FEATURES_BIOME_MODIFIER_TYPE.get();
        }
    }

    public record RemoveFeaturesBiomeModifier(class_6885<class_1959> biomes, class_6885<class_6796> features, Set<class_2893.class_2895> steps) implements BiomeModifier {
        public static RemoveFeaturesBiomeModifier allSteps(class_6885<class_1959> biomes, class_6885<class_6796> features) {
            return new RemoveFeaturesBiomeModifier(biomes, features, EnumSet.allOf(class_2893.class_2895.class));
        }

        @Override
        public void modify(class_6880<class_1959> biome, Phase phase, ModifiableBiomeInfo.BiomeInfo.Builder builder) {
            if (phase == Phase.REMOVE && this.biomes.method_40241(biome)) {
                BiomeGenerationSettingsBuilder generationSettings = builder.getGenerationSettings();
                for (class_2893.class_2895 step : this.steps) {
                    generationSettings.getFeatures(step).removeIf(this.features::method_40241);
                }
            }
        }

        @Override
        public MapCodec<? extends BiomeModifier> codec() {
            return SimpleLibraryBiomeModifierSerializers.REMOVE_FEATURES_BIOME_MODIFIER_TYPE.get();
        }
    }

    public record AddSpawnsBiomeModifier(class_6885<class_1959> biomes, class_6012<class_5483.class_1964> spawners) implements BiomeModifier {
        public static AddSpawnsBiomeModifier singleSpawn(class_6885<class_1959> biomes, class_6010<class_5483.class_1964> spawner) {
            return new AddSpawnsBiomeModifier(biomes, class_6012.<class_5483.class_1964>method_34989(spawner));
        }

        @Override
        public void modify(class_6880<class_1959> biome, Phase phase, ModifiableBiomeInfo.BiomeInfo.Builder builder) {
            if (phase == Phase.ADD && this.biomes.method_40241(biome)) {
                MobSpawnSettingsBuilder spawns = builder.getMobSpawnSettings();
                for (class_6010<class_5483.class_1964> spawner : this.spawners.method_34994()) {
                    class_1299<?> type = spawner.comp_2542().comp_3488();
                    spawns.method_31011(type.method_5891(), spawner.comp_2543(), spawner.comp_2542());
                }
            }
        }

        @Override
        public MapCodec<? extends BiomeModifier> codec() {
            return SimpleLibraryBiomeModifierSerializers.ADD_SPAWNS_BIOME_MODIFIER_TYPE.get();
        }
    }

    public record RemoveSpawnsBiomeModifier(class_6885<class_1959> biomes, class_6885<class_1299<?>> entityTypes) implements BiomeModifier {
        @Override
        public void modify(class_6880<class_1959> biome, Phase phase, ModifiableBiomeInfo.BiomeInfo.Builder builder) {
            if (phase == Phase.REMOVE && this.biomes.method_40241(biome)) {
                MobSpawnSettingsBuilder spawnBuilder = builder.getMobSpawnSettings();
                for (class_1311 category : class_1311.values()) {
                    class_6012.class_6006<class_5483.class_1964> spawns = spawnBuilder.getSpawner(category);
                    spawns.removeIf(spawnerData -> this.entityTypes.method_40241(class_7923.field_41177.method_47983(((class_6010<class_5483.class_1964>) spawnerData).comp_2542().comp_3488())));
                }
            }
        }

        @Override
        public MapCodec<? extends BiomeModifier> codec() {
            return SimpleLibraryBiomeModifierSerializers.REMOVE_SPAWNS_BIOME_MODIFIER_TYPE.get();
        }
    }

    public record AddCarversBiomeModifier(class_6885<class_1959> biomes, class_6885<class_2922<?>> carvers) implements BiomeModifier {
        @Override
        public void modify(class_6880<class_1959> biome, Phase phase, ModifiableBiomeInfo.BiomeInfo.Builder builder) {
            if (phase == Phase.ADD && this.biomes.method_40241(biome)) {
                BiomeGenerationSettingsBuilder generationSettings = builder.getGenerationSettings();
                this.carvers.forEach(generationSettings::method_46675);
            }
        }

        @Override
        public MapCodec<? extends BiomeModifier> codec() {
            return SimpleLibraryBiomeModifierSerializers.ADD_CARVERS_BIOME_MODIFIER_TYPE.get();
        }
    }

    public record RemoveCarversBiomeModifier(class_6885<class_1959> biomes, class_6885<class_2922<?>> carvers) implements BiomeModifier {
        @Override
        public void modify(class_6880<class_1959> biome, Phase phase, ModifiableBiomeInfo.BiomeInfo.Builder builder) {
            if (phase == Phase.REMOVE && this.biomes.method_40241(biome)) {
                BiomeGenerationSettingsBuilder generationSettings = builder.getGenerationSettings();
                generationSettings.getCarvers().removeIf(this.carvers::method_40241);
            }
        }

        @Override
        public MapCodec<? extends BiomeModifier> codec() {
            return SimpleLibraryBiomeModifierSerializers.REMOVE_CARVERS_BIOME_MODIFIER_TYPE.get();
        }
    }

    public record AddSpawnCostsBiomeModifier(class_6885<class_1959> biomes, class_6885<class_1299<?>> entityTypes, class_5483.class_5265 spawnCost) implements BiomeModifier {
        @Override
        public void modify(class_6880<class_1959> biome, Phase phase, ModifiableBiomeInfo.BiomeInfo.Builder builder) {
            if (phase == Phase.ADD) {
                MobSpawnSettingsBuilder spawnBuilder = builder.getMobSpawnSettings();
                for (var entityType : entityTypes) {
                    spawnBuilder.method_31009(entityType.comp_349(), spawnCost.comp_1308(), spawnCost.comp_1307());
                }
            }
        }

        @Override
        public MapCodec<? extends BiomeModifier> codec() {
            return SimpleLibraryBiomeModifierSerializers.ADD_SPAWN_COSTS_BIOME_MODIFIER_TYPE.get();
        }
    }

    public record RemoveSpawnCostsBiomeModifier(class_6885<class_1959> biomes, class_6885<class_1299<?>> entityTypes) implements BiomeModifier {
        @Override
        public void modify(class_6880<class_1959> biome, Phase phase, ModifiableBiomeInfo.BiomeInfo.Builder builder) {
            if (phase == Phase.REMOVE) {
                MobSpawnSettingsBuilder spawnBuilder = builder.getMobSpawnSettings();
                for (var entityType : entityTypes) {
                    spawnBuilder.removeSpawnCost(entityType.comp_349());
                }
            }
        }

        @Override
        public MapCodec<? extends BiomeModifier> codec() {
            return SimpleLibraryBiomeModifierSerializers.REMOVE_SPAWN_COSTS_BIOME_MODIFIER_TYPE.get();
        }
    }
}
