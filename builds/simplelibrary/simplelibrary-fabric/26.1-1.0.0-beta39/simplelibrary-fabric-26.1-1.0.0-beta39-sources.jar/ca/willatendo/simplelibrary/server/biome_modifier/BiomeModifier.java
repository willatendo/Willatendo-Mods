package ca.willatendo.simplelibrary.server.biome_modifier;

import ca.willatendo.simplelibrary.core.registry.SimpleLibraryBuiltInRegistries;
import ca.willatendo.simplelibrary.core.registry.SimpleLibraryRegistries;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import java.util.function.Function;
import net.minecraft.class_1959;
import net.minecraft.class_5381;
import net.minecraft.class_6880;
import net.minecraft.class_6885;
import net.minecraft.class_6895;

// Modified from Neoforge
public interface BiomeModifier {
    Codec<BiomeModifier> DIRECT_CODEC = SimpleLibraryBuiltInRegistries.BIOME_MODIFIER_SERIALIZERS.method_39673().dispatch(BiomeModifier::codec, Function.identity());
    Codec<class_6880<BiomeModifier>> REFERENCE_CODEC = class_5381.method_29749(SimpleLibraryRegistries.BIOME_MODIFIERS, DIRECT_CODEC);
    Codec<class_6885<BiomeModifier>> LIST_CODEC = class_6895.method_40341(SimpleLibraryRegistries.BIOME_MODIFIERS, DIRECT_CODEC);

    void modify(class_6880<class_1959> biome, Phase phase, ModifiableBiomeInfo.BiomeInfo.Builder builder);

    MapCodec<? extends BiomeModifier> codec();

    enum Phase {
        BEFORE_EVERYTHING,
        ADD,
        REMOVE,
        MODIFY,
        AFTER_EVERYTHING
    }
}
