package ca.willatendo.simplelibrary.server.biome_modifier;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_1959;
import net.minecraft.class_6880;

public final class NoneBiomeModifier implements BiomeModifier {
    public static final NoneBiomeModifier INSTANCE = new NoneBiomeModifier();

    private NoneBiomeModifier() {
    }

    @Override
    public void modify(class_6880<class_1959> biome, BiomeModifier.Phase phase, ModifiableBiomeInfo.BiomeInfo.Builder builder) {
    }

    @Override
    public MapCodec<? extends BiomeModifier> codec() {
        return SimpleLibraryBiomeModifierSerializers.NONE_BIOME_MODIFIER_TYPE.get();
    }
}
