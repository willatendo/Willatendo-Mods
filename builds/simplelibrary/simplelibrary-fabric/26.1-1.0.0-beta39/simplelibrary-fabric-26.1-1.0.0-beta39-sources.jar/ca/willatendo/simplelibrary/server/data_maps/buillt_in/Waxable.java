package ca.willatendo.simplelibrary.server.data_maps.buillt_in;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_2248;
import net.minecraft.class_7923;

public record Waxable(class_2248 waxed) {
    public static final Codec<Waxable> WAXABLE_CODEC = class_7923.field_41175.method_39673().xmap(Waxable::new, Waxable::waxed);
    public static final Codec<Waxable> CODEC = Codec.withAlternative(RecordCodecBuilder.create(instance -> instance.group(class_7923.field_41175.method_39673().fieldOf("waxed").forGetter(Waxable::waxed)).apply(instance, Waxable::new)), WAXABLE_CODEC);
}
