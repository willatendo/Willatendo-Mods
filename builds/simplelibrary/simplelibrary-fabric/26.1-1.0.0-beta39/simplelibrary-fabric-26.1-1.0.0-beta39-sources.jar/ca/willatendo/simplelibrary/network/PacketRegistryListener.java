package ca.willatendo.simplelibrary.network;

import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public interface PacketRegistryListener {
    default void registerClientboundPackets(PacketRegistryListener.ClientboundPacketRegister clientboundPacketRegister) {
    }

    default void registerServerboundPackets(PacketRegistryListener.ServerboundPacketRegister serverboundPacketRegister) {
    }

    @FunctionalInterface
    interface ClientboundPacketRegister {
        <T extends class_8710> void apply(class_8710.class_9154<T> type, class_9139<? super class_9129, T> codec, PacketSupplier<T> packetSupplier);
    }

    @FunctionalInterface
    interface ServerboundPacketRegister {
        <T extends class_8710> void apply(class_8710.class_9154<T> type, class_9139<? super class_9129, T> codec, PacketSupplier<T> packetSupplier);
    }
}
