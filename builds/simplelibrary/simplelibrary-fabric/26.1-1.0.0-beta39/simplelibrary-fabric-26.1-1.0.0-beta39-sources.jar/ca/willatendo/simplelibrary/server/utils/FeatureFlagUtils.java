package ca.willatendo.simplelibrary.server.utils;

import ca.willatendo.simplelibrary.platform.SimpleLibraryPlatformHelper;
import net.minecraft.class_2960;
import net.minecraft.class_7696;

public final class FeatureFlagUtils {
    public static class_7696 getFeatureFlag(class_2960 identifier) {
        return SimpleLibraryPlatformHelper.INSTANCE.getFeatureFlag(identifier);
    }
}
