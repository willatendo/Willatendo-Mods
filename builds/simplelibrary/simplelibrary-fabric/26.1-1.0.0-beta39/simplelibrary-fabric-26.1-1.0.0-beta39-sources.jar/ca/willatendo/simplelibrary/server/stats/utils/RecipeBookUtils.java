package ca.willatendo.simplelibrary.server.stats.utils;

import java.util.Arrays;
import java.util.stream.Stream;
import net.minecraft.class_5421;

public final class RecipeBookUtils {
    private RecipeBookUtils() {
    }

    public static boolean isModded(class_5421 recipeBookType) {
        return recipeBookType != class_5421.field_25763 && recipeBookType != class_5421.field_25764 && recipeBookType != class_5421.field_25765 && recipeBookType != class_5421.field_25766;
    }

    public static Stream<class_5421> getModdedRecipeBookTypes() {
        return Arrays.stream(class_5421.values()).filter(RecipeBookUtils::isModded);
    }
}
