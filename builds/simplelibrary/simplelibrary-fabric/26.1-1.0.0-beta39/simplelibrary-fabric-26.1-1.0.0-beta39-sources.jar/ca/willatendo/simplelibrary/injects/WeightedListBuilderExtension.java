package ca.willatendo.simplelibrary.injects;

import java.util.Collection;
import java.util.function.Predicate;
import net.minecraft.class_6010;
import net.minecraft.class_6012;

public interface WeightedListBuilderExtension<E> {
    default class_6012.class_6006<E> addAll(class_6012<E> values) {
        return this.addAll(values.method_34994());
    }

    default class_6012.class_6006<E> addAll(Collection<class_6010<E>> values) {
        return (class_6012.class_6006<E>) this;
    }

    default class_6012.class_6006<E> removeIf(Predicate<class_6010<E>> filter) {
        return (class_6012.class_6006<E>) this;
    }
}
