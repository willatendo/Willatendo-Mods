package ca.willatendo.simplelibrary.mixin;

import ca.willatendo.simplelibrary.server.event.TagEvents;
import net.minecraft.class_2535;
import net.minecraft.class_310;
import net.minecraft.class_5455;
import net.minecraft.class_8673;
import net.minecraft.class_8674;
import net.minecraft.class_8675;
import net.minecraft.class_8733;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

@Mixin(class_8674.class)
public abstract class ClientConfigurationPacketListenerImplMixin extends class_8673 {
    protected ClientConfigurationPacketListenerImplMixin(class_310 minecraft, class_2535 connection, class_8675 commonListenerCookie) {
        super(minecraft, connection, commonListenerCookie);
    }

    @Inject(at = @At(value = "TAIL", target = "Lnet/minecraft/network/Connection;setupInboundProtocol(Lnet/minecraft/network/ProtocolInfo;Lnet/minecraft/network/PacketListener;)V", shift = At.Shift.AFTER), method = "handleConfigurationFinished", locals = LocalCapture.CAPTURE_FAILHARD)
    private void handleConfigurationFinished(class_8733 clientboundFinishConfigurationPacket, CallbackInfo ci, class_5455.class_6890 frozen) {
        TagEvents.UPDATE_TAGS.invoker().update(frozen, true, this.field_45589.method_10756());
    }
}
