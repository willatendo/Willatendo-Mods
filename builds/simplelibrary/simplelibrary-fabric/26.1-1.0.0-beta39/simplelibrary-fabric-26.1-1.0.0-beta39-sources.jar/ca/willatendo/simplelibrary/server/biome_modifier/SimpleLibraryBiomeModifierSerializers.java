package ca.willatendo.simplelibrary.server.biome_modifier;

import ca.willatendo.simplelibrary.core.holder.SimpleHolder;
import ca.willatendo.simplelibrary.core.registry.SimpleLibraryRegistries;
import ca.willatendo.simplelibrary.core.registry.SimpleRegistry;
import com.mojang.datafixers.util.Either;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;
import java.util.function.Function;
import net.minecraft.class_1959;
import net.minecraft.class_2893;
import net.minecraft.class_2922;
import net.minecraft.class_5483;
import net.minecraft.class_6010;
import net.minecraft.class_6012;
import net.minecraft.class_6796;
import net.minecraft.class_6895;
import net.minecraft.class_7924;

public final class SimpleLibraryBiomeModifierSerializers {
    public static final SimpleRegistry<MapCodec<? extends BiomeModifier>> BIOME_MODIFIER_SERIALIZERS = new SimpleRegistry<>(SimpleLibraryRegistries.BIOME_MODIFIER_SERIALIZERS, "neoforge");

    public static final SimpleHolder<MapCodec<NoneBiomeModifier>> NONE_BIOME_MODIFIER_TYPE = BIOME_MODIFIER_SERIALIZERS.register("none", () -> MapCodec.unit(NoneBiomeModifier.INSTANCE));
    public static final SimpleHolder<MapCodec<BiomeModifiers.AddFeaturesBiomeModifier>> ADD_FEATURES_BIOME_MODIFIER_TYPE = BIOME_MODIFIER_SERIALIZERS.register("add_features", () -> RecordCodecBuilder.mapCodec(builder -> builder.group(class_1959.field_26750.fieldOf("biomes").forGetter(BiomeModifiers.AddFeaturesBiomeModifier::biomes), class_6796.field_35731.fieldOf("features").forGetter(BiomeModifiers.AddFeaturesBiomeModifier::features), class_2893.class_2895.field_37680.fieldOf("step").forGetter(BiomeModifiers.AddFeaturesBiomeModifier::step)).apply(builder, BiomeModifiers.AddFeaturesBiomeModifier::new)));
    public static final SimpleHolder<MapCodec<BiomeModifiers.RemoveFeaturesBiomeModifier>> REMOVE_FEATURES_BIOME_MODIFIER_TYPE = BIOME_MODIFIER_SERIALIZERS.register("remove_features", () -> RecordCodecBuilder.mapCodec(builder -> builder.group(class_1959.field_26750.fieldOf("biomes").forGetter(BiomeModifiers.RemoveFeaturesBiomeModifier::biomes), class_6796.field_35731.fieldOf("features").forGetter(BiomeModifiers.RemoveFeaturesBiomeModifier::features), Codec.either(class_2893.class_2895.field_37680.listOf(), class_2893.class_2895.field_37680).xmap((either) -> either.map(Set::copyOf, Set::of), set -> set.size() == 1 ? Either.right(((class_2893.class_2895[]) set.toArray(class_2893.class_2895[]::new))[0]) : Either.left(List.copyOf(set))).optionalFieldOf("steps", EnumSet.allOf(class_2893.class_2895.class)).forGetter(BiomeModifiers.RemoveFeaturesBiomeModifier::steps)).apply(builder, BiomeModifiers.RemoveFeaturesBiomeModifier::new)));
    public static final SimpleHolder<MapCodec<BiomeModifiers.AddSpawnsBiomeModifier>> ADD_SPAWNS_BIOME_MODIFIER_TYPE = BIOME_MODIFIER_SERIALIZERS.register("add_spawns", () -> RecordCodecBuilder.mapCodec(instance -> instance.group(class_1959.field_26750.fieldOf("biomes").forGetter(BiomeModifiers.AddSpawnsBiomeModifier::biomes), Codec.either(class_6012.method_66213(class_5483.class_1964.field_24681), class_6010.method_66211(class_5483.class_1964.field_24681)).xmap(either -> either.map(Function.identity(), class_6012::<class_5483.class_1964>method_34989), list -> list.method_34994().size() == 1 ? Either.right(list.method_34994().getFirst()) : Either.left(list)).fieldOf("spawners").forGetter(BiomeModifiers.AddSpawnsBiomeModifier::spawners)).apply(instance, BiomeModifiers.AddSpawnsBiomeModifier::new)));
    public static final SimpleHolder<MapCodec<BiomeModifiers.RemoveSpawnsBiomeModifier>> REMOVE_SPAWNS_BIOME_MODIFIER_TYPE = BIOME_MODIFIER_SERIALIZERS.register("remove_spawns", () -> RecordCodecBuilder.mapCodec(builder -> builder.group(class_1959.field_26750.fieldOf("biomes").forGetter(BiomeModifiers.RemoveSpawnsBiomeModifier::biomes), class_6895.method_40340(class_7924.field_41266).fieldOf("entity_types").forGetter(BiomeModifiers.RemoveSpawnsBiomeModifier::entityTypes)).apply(builder, BiomeModifiers.RemoveSpawnsBiomeModifier::new)));
    public static final SimpleHolder<MapCodec<BiomeModifiers.AddCarversBiomeModifier>> ADD_CARVERS_BIOME_MODIFIER_TYPE = BIOME_MODIFIER_SERIALIZERS.register("add_carvers", () -> RecordCodecBuilder.mapCodec(builder -> builder.group(class_1959.field_26750.fieldOf("biomes").forGetter(BiomeModifiers.AddCarversBiomeModifier::biomes), class_2922.field_26755.fieldOf("carvers").forGetter(BiomeModifiers.AddCarversBiomeModifier::carvers)).apply(builder, BiomeModifiers.AddCarversBiomeModifier::new)));
    public static final SimpleHolder<MapCodec<BiomeModifiers.RemoveCarversBiomeModifier>> REMOVE_CARVERS_BIOME_MODIFIER_TYPE = BIOME_MODIFIER_SERIALIZERS.register("remove_carvers", () -> RecordCodecBuilder.mapCodec(builder -> builder.group(class_1959.field_26750.fieldOf("biomes").forGetter(BiomeModifiers.RemoveCarversBiomeModifier::biomes), class_2922.field_26755.fieldOf("carvers").forGetter(BiomeModifiers.RemoveCarversBiomeModifier::carvers)).apply(builder, BiomeModifiers.RemoveCarversBiomeModifier::new)));
    public static final SimpleHolder<MapCodec<BiomeModifiers.AddSpawnCostsBiomeModifier>> ADD_SPAWN_COSTS_BIOME_MODIFIER_TYPE = BIOME_MODIFIER_SERIALIZERS.register("add_spawn_costs", () -> RecordCodecBuilder.mapCodec(builder -> builder.group(class_1959.field_26750.fieldOf("biomes").forGetter(BiomeModifiers.AddSpawnCostsBiomeModifier::biomes), class_6895.method_40340(class_7924.field_41266).fieldOf("entity_types").forGetter(BiomeModifiers.AddSpawnCostsBiomeModifier::entityTypes), class_5483.class_5265.field_25820.fieldOf("spawn_cost").forGetter(BiomeModifiers.AddSpawnCostsBiomeModifier::spawnCost)).apply(builder, BiomeModifiers.AddSpawnCostsBiomeModifier::new)));
    public static final SimpleHolder<MapCodec<BiomeModifiers.RemoveSpawnCostsBiomeModifier>> REMOVE_SPAWN_COSTS_BIOME_MODIFIER_TYPE = BIOME_MODIFIER_SERIALIZERS.register("remove_spawn_costs", () -> RecordCodecBuilder.mapCodec(builder -> builder.group(class_1959.field_26750.fieldOf("biomes").forGetter(BiomeModifiers.RemoveSpawnCostsBiomeModifier::biomes), class_6895.method_40340(class_7924.field_41266).fieldOf("entity_types").forGetter(BiomeModifiers.RemoveSpawnCostsBiomeModifier::entityTypes)).apply(builder, BiomeModifiers.RemoveSpawnCostsBiomeModifier::new)));

    private SimpleLibraryBiomeModifierSerializers() {
    }
}
