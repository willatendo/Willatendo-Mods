package ca.willatendo.simplelibrary.server.utils;

import net.fabricmc.fabric.impl.resource.FabricResourceReloader;
import net.minecraft.class_2960;
import net.minecraft.class_3302;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

public class WrappedStateAwareListener implements class_3302, FabricResourceReloader {
    private final class_2960 identifier;
    private final class_3302 wrapped;

    public WrappedStateAwareListener(class_2960 identifier, class_3302 wrapped) {
        this.identifier = identifier;
        this.wrapped = wrapped;
    }

    @Override
    public class_2960 fabric$getId() {
        return this.identifier;
    }

    @Override
    public CompletableFuture<Void> method_25931(class_11558 sharedState, Executor exectutor, class_4045 barrier, Executor applyExectutor) {
        return this.wrapped.method_25931(sharedState, exectutor, barrier, applyExectutor);
    }
}
