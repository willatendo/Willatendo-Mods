package ca.willatendo.simplelibrary.network.clientbound;

import ca.willatendo.simplelibrary.core.utils.SimpleCoreUtils;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_10289;
import net.minecraft.class_3956;
import net.minecraft.class_7924;
import net.minecraft.class_8710;
import net.minecraft.class_8786;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record ClientboundRecipeContentPacket(Set<class_3956<?>> recipeTypes, List<class_8786<?>> recipes) implements class_8710 {
    public static final class_8710.class_9154<ClientboundRecipeContentPacket> TYPE = new class_8710.class_9154<>(SimpleCoreUtils.resource("recipe_content"));
    public static final class_9139<class_9129, ClientboundRecipeContentPacket> STREAM_CODEC = class_9139.method_56435(class_9135.method_56365(class_7924.field_41217).method_56433(class_9135.method_56374(HashSet::new)), ClientboundRecipeContentPacket::recipeTypes, class_8786.field_48357.method_56433(class_9135.method_56363()), ClientboundRecipeContentPacket::recipes, ClientboundRecipeContentPacket::new);

    public static ClientboundRecipeContentPacket create(Collection<class_3956<?>> recipeTypes, class_10289 recipeMap) {
        Set<class_3956<?>> recipeTypesSet = Set.copyOf(recipeTypes);
        if (recipeTypesSet.isEmpty()) {
            return new ClientboundRecipeContentPacket(recipeTypesSet, List.of());
        } else {
            List<class_8786<?>> recipeSubset = recipeMap.method_64695().stream().filter(recipeHolder -> recipeTypesSet.contains(recipeHolder.comp_1933().method_17716())).toList();
            return new ClientboundRecipeContentPacket(recipeTypesSet, recipeSubset);
        }
    }

    @Override
    public class_8710.class_9154<ClientboundRecipeContentPacket> method_56479() {
        return TYPE;
    }
}