package ca.willatendo.simplelibrary.mixin;

import ca.willatendo.simplelibrary.server.event.EntityTickEvent;
import net.minecraft.class_1297;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1297.class)
public class EntityMixin {
    @Inject(at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Entity;tick()V"), method = "rideTick")
    private void rideTickPre(CallbackInfo ci) {
        EntityTickEvent.PRE.invoker().register((class_1297) (Object) this);
    }

    @Inject(at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Entity;tick()V", shift = At.Shift.AFTER), method = "rideTick")
    private void rideTickPost(CallbackInfo ci) {
        EntityTickEvent.POST.invoker().register((class_1297) (Object) this);
    }
}
