package ca.willatendo.simplelibrary.injects;

import java.util.Optional;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7225;

public interface HolderLookupProviderExtension {
    default <T> Optional<class_6880.class_6883<T>> holder(class_5321<T> key) {
        Optional<? extends class_7225.class_7226<T>> registry = ((class_7225.class_7874) (Object) this).method_46759(key.method_58273());
        return registry.flatMap(registryLookup -> registryLookup.method_46746(key));
    }
}
