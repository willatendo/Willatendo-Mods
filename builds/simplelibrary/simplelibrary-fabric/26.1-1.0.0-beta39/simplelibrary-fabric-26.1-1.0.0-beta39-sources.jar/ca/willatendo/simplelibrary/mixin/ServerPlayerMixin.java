package ca.willatendo.simplelibrary.mixin;

import ca.willatendo.simplelibrary.server.stats.CustomRecipeBookSettings;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_3222;
import net.minecraft.class_3441;
import net.minecraft.server.MinecraftServer;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3222.class)
public class ServerPlayerMixin {
    @Shadow
    @Final
    private class_3441 recipeBook;
    @Shadow
    @Final
    private MinecraftServer server;

    @Inject(at = @At("TAIL"), method = "readAdditionalSaveData")
    private void readAdditionalSaveData(class_11368 valueInput, CallbackInfo ci) {
        valueInput.method_71426("recipe_book_extras", CustomRecipeBookSettings.MAP_CODEC.codec()).ifPresent(customRecipeBookSettings -> this.recipeBook.loadCustomUntrusted(customRecipeBookSettings, recipeResourceKey -> this.server.method_3772().method_8130(recipeResourceKey).isPresent()));
    }

    @Inject(at = @At("TAIL"), method = "addAdditionalSaveData")
    private void addAdditionalSaveData(class_11372 valueOutput, CallbackInfo ci) {
        valueOutput.method_71468("recipe_book_extras", CustomRecipeBookSettings.MAP_CODEC.codec(), this.recipeBook.getCustomRecipeBookSettings());
    }
}
