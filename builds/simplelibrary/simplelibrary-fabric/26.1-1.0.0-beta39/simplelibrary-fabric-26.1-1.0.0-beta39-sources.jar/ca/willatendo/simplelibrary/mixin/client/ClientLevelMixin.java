package ca.willatendo.simplelibrary.mixin.client;

import ca.willatendo.simplelibrary.server.event.EntityTickEvent;
import net.minecraft.class_1297;
import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_638.class)
public class ClientLevelMixin {
    @Inject(at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Entity;tick()V"), method = "tickNonPassenger")
    private void tickNonPassengerPre(class_1297 entity, CallbackInfo ci) {
        EntityTickEvent.PRE.invoker().register(entity);
    }

    @Inject(at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Entity;tick()V", shift = At.Shift.AFTER), method = "tickNonPassenger")
    private void tickNonPassengerPost(class_1297 entity, CallbackInfo ci) {
        EntityTickEvent.POST.invoker().register(entity);
    }
}
