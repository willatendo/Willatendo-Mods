package ca.willatendo.simplelibrary.mixin;

import ca.willatendo.simplelibrary.server.data_maps.DataMapHooks;
import com.mojang.datafixers.DataFixer;
import net.minecraft.class_11545;
import net.minecraft.class_32;
import net.minecraft.class_3283;
import net.minecraft.class_5219;
import net.minecraft.class_6904;
import net.minecraft.class_7497;
import net.minecraft.class_7659;
import net.minecraft.class_7780;
import net.minecraft.class_9895;
import net.minecraft.server.MinecraftServer;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.net.Proxy;

@Mixin(MinecraftServer.class)
public class MinecraftServerMixin {
    @Shadow
    @Final
    private class_7780<class_7659> registries;
    @Shadow
    @Final
    protected class_5219 worldData;
    @Shadow
    private class_9895 fuelValues;

    @Inject(at = @At("TAIL"), method = "<init>")
    private void MinecraftServer(Thread serverThread, class_32.class_5143 storageSource, class_3283 packRepository, class_6904 worldStem, Proxy proxy, DataFixer fixerUpper, class_7497 services, class_11545 levelLoadListener, CallbackInfo ci) {
        this.fuelValues = DataMapHooks.populateFuelValues(this.registries.method_45926(), this.worldData.method_45560());
    }
}
