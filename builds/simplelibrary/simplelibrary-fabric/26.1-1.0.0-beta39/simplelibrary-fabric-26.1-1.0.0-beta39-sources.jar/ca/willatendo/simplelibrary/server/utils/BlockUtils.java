package ca.willatendo.simplelibrary.server.utils;

import java.util.function.Function;
import java.util.function.ToIntFunction;
import net.minecraft.class_1299;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2465;
import net.minecraft.class_2498;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2627;
import net.minecraft.class_2665;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2766;
import net.minecraft.class_3619;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_5544;
import net.minecraft.class_5558;

public final class BlockUtils {
    public static final class_4970.class_4973 NOT_CLOSED_SHULKER = (blockState, blockGetter, blockPos) -> {
        class_2586 blockEntity = blockGetter.method_8321(blockPos);
        if (blockEntity instanceof class_2627 shulkerBoxBlockEntity) {
            return shulkerBoxBlockEntity.method_27093();
        } else {
            return true;
        }
    };
    public static final class_4970.class_4973 NOT_EXTENDED_PISTON = (blockState, blockGetter, blockPos) -> blockState.method_11654(class_2665.field_12191);

    private BlockUtils() {
    }

    public static ToIntFunction<class_2680> litBlockEmission(int lightValue) {
        return blockState -> blockState.method_11654(class_2741.field_12548) ? lightValue : 0;
    }

    public static Function<class_2680, class_3620> waterloggedMapColor(class_3620 unwaterloggedMapColor) {
        return blockState -> blockState.method_11654(class_2741.field_12508) ? class_3620.field_16019 : unwaterloggedMapColor;
    }

    public static Boolean never(class_2680 blockState, class_1922 blockGetter, class_2338 blockPos, class_1299<?> entityType) {
        return false;
    }

    public static Boolean always(class_2680 blockState, class_1922 blockGetter, class_2338 blockPos, class_1299<?> entityType) {
        return true;
    }

    public static Boolean ocelotOrParrot(class_2680 blockState, class_1922 blockGetter, class_2338 blockPos, class_1299<?> entityType) {
        return entityType == class_1299.field_6081 || entityType == class_1299.field_6104;
    }

    public static class_4970.class_2251 logProperties(class_3620 sideMapColor, class_3620 topMapColor, class_2498 soundType) {
        return class_4970.class_2251.method_9637().method_51520(blockState -> blockState.method_11654(class_2465.field_11459) == class_2350.class_2351.field_11052 ? sideMapColor : topMapColor).method_51368(class_2766.field_12651).method_9632(2.0F).method_9626(soundType).method_50013();
    }

    public static class_4970.class_2251 netherStemProperties(class_3620 mapColor) {
        return class_4970.class_2251.method_9637().method_51520(blockState -> mapColor).method_51368(class_2766.field_12651).method_9632(2.0F).method_9626(class_2498.field_22152);
    }

    public static boolean always(class_2680 blockState, class_1922 blockGetter, class_2338 blockPos) {
        return true;
    }

    public static boolean never(class_2680 blockState, class_1922 blockGetter, class_2338 blockPos) {
        return false;
    }

    public static class_4970.class_2251 leavesProperties(class_2498 soundType) {
        return class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9632(0.2F).method_9640().method_9626(soundType).method_22488().method_26235(BlockUtils::ocelotOrParrot).method_26243(BlockUtils::never).method_26245(BlockUtils::never).method_50013().method_50012(class_3619.field_15971).method_26236(BlockUtils::never);
    }

    public static class_4970.class_2251 shulkerBoxProperties(class_3620 mapColor) {
        return class_4970.class_2251.method_9637().method_31710(mapColor).method_51369().method_9632(2.0F).method_9624().method_22488().method_26243(NOT_CLOSED_SHULKER).method_26245(NOT_CLOSED_SHULKER).method_50012(class_3619.field_15971);
    }

    public static class_4970.class_2251 pistonProperties() {
        return class_4970.class_2251.method_9637().method_31710(class_3620.field_16023).method_9632(1.5F).method_26236(BlockUtils::never).method_26243(NOT_EXTENDED_PISTON).method_26245(NOT_EXTENDED_PISTON).method_50012(class_3619.field_15972);
    }

    public static class_4970.class_2251 buttonProperties() {
        return class_4970.class_2251.method_9637().method_9634().method_9632(0.5F).method_50012(class_3619.field_15971);
    }

    public static class_4970.class_2251 flowerPotProperties() {
        return class_4970.class_2251.method_9637().method_9618().method_22488().method_50012(class_3619.field_15971);
    }

    public static class_4970.class_2251 candleProperties(class_3620 mapColor) {
        return class_4970.class_2251.method_9637().method_31710(mapColor).method_22488().method_9632(0.1F).method_9626(class_2498.field_27196).method_9631(class_5544.field_27177).method_50012(class_3619.field_15971);
    }

    public static class_4970.class_2251 wallVariant(class_2248 baseBlock, boolean overrideDescription) {
        class_4970.class_2251 properties = class_4970.class_2251.method_9637().method_63502(baseBlock.method_26162());

        if (overrideDescription) {
            properties = properties.method_63501(baseBlock.method_63499());
        }

        return properties;
    }

    public static <E extends class_2586, A extends class_2586> class_5558<A> createTickerHelper(class_2591<A> blockEntityTypeAtPos, class_2591<E> blockEntityType, class_5558<? super E> blockEntityTicker) {
        return blockEntityType == blockEntityTypeAtPos ? (class_5558<A>) blockEntityTicker : null;
    }
}
