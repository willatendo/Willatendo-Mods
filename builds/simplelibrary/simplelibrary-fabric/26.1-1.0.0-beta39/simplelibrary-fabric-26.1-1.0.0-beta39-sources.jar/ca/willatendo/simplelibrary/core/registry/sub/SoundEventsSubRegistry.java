package ca.willatendo.simplelibrary.core.registry.sub;

import ca.willatendo.simplelibrary.core.holder.SimpleHolder;
import ca.willatendo.simplelibrary.core.registry.SimpleRegistry;
import ca.willatendo.simplelibrary.core.utils.CoreUtils;
import net.minecraft.class_3414;
import net.minecraft.class_7924;

public class SoundEventsSubRegistry extends SimpleRegistry<class_3414> {
    public SoundEventsSubRegistry(String modId) {
        super(class_7924.field_41225, modId);
    }

    public SimpleHolder<class_3414> registerVariableRange(String name) {
        return this.register(name, () -> class_3414.method_47908(CoreUtils.resource(this.modId, name)));
    }
}
