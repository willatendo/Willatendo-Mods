package ca.willatendo.simplelibrary.server.event;

import ca.willatendo.simplelibrary.server.conditions.ICondition;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_3302;
import net.minecraft.class_5350;
import java.util.List;

public final class AddReloadListenersEvent {
    public static final Event<AddReloadListenersCallback> EVENT = EventFactory.createArrayBacked(AddReloadListenersCallback.class, callbacks -> (preparableReloadListeners, context, reloadableServerResources) -> {
        for (AddReloadListenersCallback callback : callbacks) {
            callback.onAddReloadListeners(preparableReloadListeners, context, reloadableServerResources);
        }
    });

    public interface AddReloadListenersCallback {
        void onAddReloadListeners(List<class_3302> preparableReloadListeners, ICondition.IContext context, class_5350 reloadableServerResources);
    }
}
