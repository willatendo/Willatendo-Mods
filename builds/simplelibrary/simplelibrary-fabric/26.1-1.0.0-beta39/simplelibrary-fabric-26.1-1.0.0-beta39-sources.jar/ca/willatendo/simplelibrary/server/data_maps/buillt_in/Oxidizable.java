package ca.willatendo.simplelibrary.server.data_maps.buillt_in;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_2248;
import net.minecraft.class_7923;

public record Oxidizable(class_2248 nextOxidationStage) {
    public static final Codec<Oxidizable> OXIDIZABLE_CODEC = class_7923.field_41175.method_39673().xmap(Oxidizable::new, Oxidizable::nextOxidationStage);
    public static final Codec<Oxidizable> CODEC = Codec.withAlternative(RecordCodecBuilder.create(instance -> instance.group(class_7923.field_41175.method_39673().fieldOf("next_oxidation_stage").forGetter(Oxidizable::nextOxidationStage)).apply(instance, Oxidizable::new)), OXIDIZABLE_CODEC);
}
