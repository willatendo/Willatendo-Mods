package ca.willatendo.simplelibrary.mixin;

import ca.willatendo.simplelibrary.server.MonsterRoomHooks;
import net.minecraft.class_1299;
import net.minecraft.class_3103;
import net.minecraft.class_5819;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_3103.class)
public class MonsterRoomFeatureMixin {
    @Inject(at = @At("HEAD"), method = "randomEntityId", cancellable = true)
    private void randomEntityId(class_5819 randomSource, CallbackInfoReturnable<class_1299<?>> cir) {
        cir.setReturnValue(MonsterRoomHooks.getRandomMonsterRoomMob(randomSource));
    }
}
