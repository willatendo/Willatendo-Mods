package ca.willatendo.simplelibrary.mixin;

import ca.willatendo.simplelibrary.injects.RegistryLookupExtension;
import ca.willatendo.simplelibrary.server.data_maps.DataMapType;
import net.minecraft.class_5321;
import net.minecraft.class_7225;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_7225.class_7226.class_7875.class)
public interface HolderLookupRegistryLookupDelegateMixin<T> extends RegistryLookupExtension<T> {
    @Shadow
    class_7225.class_7226<T> parent();

    @Override
    default <A> A getData(DataMapType<T, A> attachment, class_5321<T> key) {
        return (A) this.parent().getData(attachment, key);
    }
}
