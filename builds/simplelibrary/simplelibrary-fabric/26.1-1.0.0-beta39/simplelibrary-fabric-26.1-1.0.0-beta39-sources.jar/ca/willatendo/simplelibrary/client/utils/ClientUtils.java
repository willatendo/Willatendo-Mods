package ca.willatendo.simplelibrary.client.utils;

import net.minecraft.class_2960;
import net.minecraft.class_4719;
import net.minecraft.class_4722;
import net.minecraft.class_4730;

public final class ClientUtils {
    private ClientUtils() {
    }

    public static void createSheetForWoodType(class_4719 woodType) {
        class_2960 identifier = class_2960.method_60654(woodType.comp_1299());
        class_4722.field_21712.put(woodType, new class_4730(class_4722.field_21708, class_2960.method_60655(identifier.method_12836(), "entity/signs/" + identifier.method_12832())));
        class_4722.field_40515.put(woodType, new class_4730(class_4722.field_21708, class_2960.method_60655(identifier.method_12836(), "entity/signs/hanging/" + identifier.method_12832())));
    }
}
