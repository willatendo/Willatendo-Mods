package ca.willatendo.simplelibrary.server;

import ca.willatendo.simplelibrary.core.registry.RegisterFunction;
import ca.willatendo.simplelibrary.core.registry.SimpleRegistry;
import ca.willatendo.simplelibrary.core.registry.sub.AttachmentTypesSubRegistry;
import ca.willatendo.simplelibrary.core.registry.sub.EntityDataSerializerSubRegistry;
import ca.willatendo.simplelibrary.core.utils.CoreUtils;
import ca.willatendo.simplelibrary.network.PacketRegistryListener;
import ca.willatendo.simplelibrary.network.PacketSupplier;
import ca.willatendo.simplelibrary.server.event.AddReloadListenersEvent;
import ca.willatendo.simplelibrary.server.event.EntityTickEvent;
import ca.willatendo.simplelibrary.server.event.LightingBoltEvent;
import ca.willatendo.simplelibrary.server.event.RegisterRecipeBookSearchCategoriesEvent;
import ca.willatendo.simplelibrary.server.utils.WrappedStateAwareListener;
import com.mojang.serialization.Codec;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.registry.DynamicRegistries;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.trade.TradeOfferHelper;
import net.fabricmc.fabric.api.object.builder.v1.world.poi.PointOfInterestHelper;
import net.fabricmc.fabric.api.resource.v1.pack.PackActivationType;
import net.fabricmc.fabric.impl.resource.ResourceLoaderImpl;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.minecraft.class_1317;
import net.minecraft.class_2246;
import net.minecraft.class_2358;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3264;
import net.minecraft.class_3302;
import net.minecraft.class_3785;
import net.minecraft.class_5321;
import net.minecraft.class_5350;
import net.minecraft.class_5497;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import java.util.Arrays;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Supplier;

public record FabricModInit(String modId) implements ModInit {
    @Override
    public void register(SimpleRegistry<?>... simpleRegistries) {
        Arrays.stream(simpleRegistries).forEach(simpleRegistry -> simpleRegistry.addEntries(new RegisterFunction() {
            @Override
            public <T> void register(class_5321<? extends class_2378<T>> registryKey, class_2960 identifier, Supplier<T> value) {
                class_2378.method_10230((class_2378<T>) class_7923.field_41167.method_63535(registryKey.method_29177()), identifier, value.get());
            }
        }));
    }

    @Override
    public void register(EntityDataSerializerSubRegistry entityDataSerializerSubRegistry) {
    }

    @Override
    public void register(AttachmentTypesSubRegistry attachmentTypesSubRegistry) {
    }

    @Override
    public void eventListener(EventListener eventListener) {
        eventListener.commonSetup();

        // Registry

        eventListener.registerAttributes(FabricDefaultAttributeRegistry::register);

        Event<CommandRegistrationCallback> event = CommandRegistrationCallback.EVENT;
        event.register((commandDispatcher, commandBuildContext, commandSelection) -> eventListener.registerCommands(commandRegisterInformation -> commandRegisterInformation.register(commandDispatcher, commandBuildContext, commandSelection)));

        eventListener.registerDynamicRegistries(new EventListener.DynamicRegistryRegister() {
            @Override
            public <T> void apply(class_5321<class_2378<T>> resourceKey, Codec<T> codec) {
                DynamicRegistries.register(resourceKey, codec);
            }

            @Override
            public <T> void apply(class_5321<class_2378<T>> resourceKey, Codec<T> codec, Codec<T> networkCodec) {
                DynamicRegistries.registerSynced(resourceKey, codec, networkCodec);
            }
        });

        eventListener.registerNewRegistries(new EventListener.NewRegistryRegister() {
            @Override
            public <T> void apply(class_2378<T> registry) {
            }
        });

        eventListener.registerPOI((id, poiType) -> {
            PointOfInterestHelper.register(CoreUtils.resource(this.modId, id), poiType.get().comp_816(), poiType.get().comp_817(), poiType.get().comp_815());
            return poiType;
        });

        RegisterRecipeBookSearchCategoriesEvent.EVENT.register(biConsumer -> eventListener.registerRecipeBookSearchCategory((extendedRecipeBookCategory, recipeBookCategories) -> biConsumer.accept(extendedRecipeBookCategory, Arrays.asList(recipeBookCategories))));

        eventListener.registerBuiltInResourcePacks((modId, resourcePackName, packType, packSource, alwaysActive, position) -> {
            Optional<ModContainer> modContainer = FabricLoader.getInstance().getModContainer(modId);
            boolean datapack = packType == class_3264.field_14190;
            class_2960 identifier = CoreUtils.resource(modId, resourcePackName);
            ResourceLoaderImpl.registerBuiltinPack(identifier, (datapack ? "data/" + modId + "/datapacks/" : "resourcepacks/") + identifier.method_12832(), modContainer.get(), CoreUtils.translation((datapack ? "dataPack" : "resourcePack"), modId, resourcePackName + ".name"), alwaysActive ? PackActivationType.ALWAYS_ENABLED : PackActivationType.NORMAL);
        });

        AddReloadListenersEvent.EVENT.register((preparableReloadListeners, context, reloadableServerResources) -> eventListener.registerServerReloadListener(new EventListener.ServerReloadListenerRegister() {
            @Override
            public <T extends class_3302> T apply(class_2960 identifier, T preparableReloadListener) {
                preparableReloadListeners.add(new WrappedStateAwareListener(identifier, preparableReloadListener));
                return preparableReloadListener;
            }

            @Override
            public class_5350 getServerResources() {
                return reloadableServerResources;
            }
        }));

        eventListener.registerSpawnPlacements(class_1317::method_20637);

        // Modification

        eventListener.modifyFlammables((class_2358) class_2246.field_10036);

        eventListener.modifyVillagerTrades((villagerProfession, level1Trades, level2Trades, level3Trades, level4Trades, level5Trades) -> {
            TradeOfferHelper.registerVillagerOffers(villagerProfession, 1, itemListings -> itemListings.addAll(level1Trades));
            TradeOfferHelper.registerVillagerOffers(villagerProfession, 2, itemListings -> itemListings.addAll(level2Trades));
            TradeOfferHelper.registerVillagerOffers(villagerProfession, 3, itemListings -> itemListings.addAll(level3Trades));
            TradeOfferHelper.registerVillagerOffers(villagerProfession, 4, itemListings -> itemListings.addAll(level4Trades));
            TradeOfferHelper.registerVillagerOffers(villagerProfession, 5, itemListings -> itemListings.addAll(level5Trades));
        });

        // Events
        EntityTickEvent.PRE.register(eventListener::preEntityTickEvent);

        EntityTickEvent.POST.register(eventListener::postEntityTickEvent);

        LightingBoltEvent.ENTITY_STRUCK_BY_LIGHTING.register((entity, lightningBolt) -> {
            AtomicBoolean cancel = new AtomicBoolean(false);
            eventListener.entityStruckByLightningBoltEvent(entity, lightningBolt, cancel::set);
            return cancel.get();
        });

        ServerLifecycleEvents.END_DATA_PACK_RELOAD.register((minecraftServer, closeableResourceManager, success) -> eventListener.dataReloadEvent(minecraftServer));

        ServerLifecycleEvents.SYNC_DATA_PACK_CONTENTS.register((serverPlayer, joined) -> eventListener.syncDataPackContentsEvent(serverPlayer));

        ServerLifecycleEvents.SERVER_STARTING.register(minecraftServer -> {
            eventListener.serverAboutToStartEvent(minecraftServer);

            eventListener.modifyStructurePools(new EventListener.StructurePoolModification() {
                @Override
                public class_2378<class_3785> getTemplatePoolRegistry() {
                    return minecraftServer.method_30611().method_30530(class_7924.field_41249);
                }

                @Override
                public class_2378<class_5497> getProcessorListRegistry() {
                    return minecraftServer.method_30611().method_30530(class_7924.field_41247);
                }
            });
        });

        ServerLifecycleEvents.SERVER_STOPPED.register(eventListener::serverStoppedEvent);
    }

    @Override
    public void packetRegistryListener(PacketRegistryListener packetRegistryListener) {
        packetRegistryListener.registerServerboundPackets(new PacketRegistryListener.ServerboundPacketRegister() {
            @Override
            public <T extends class_8710> void apply(class_8710.class_9154<T> type, class_9139<? super class_9129, T> codec, PacketSupplier<T> packetSupplier) {
                PayloadTypeRegistry.playC2S().register(type, codec);

                ServerPlayNetworking.registerGlobalReceiver(type, (customPacketPayload, context) -> packetSupplier.handle(customPacketPayload, context.player()));
            }
        });
    }
}
