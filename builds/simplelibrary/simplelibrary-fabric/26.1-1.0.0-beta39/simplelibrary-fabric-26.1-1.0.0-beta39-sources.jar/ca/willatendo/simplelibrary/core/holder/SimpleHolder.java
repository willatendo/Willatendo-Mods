package ca.willatendo.simplelibrary.core.holder;

import com.mojang.datafixers.util.Either;
import java.util.Locale;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.stream.Stream;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_7876;
import net.minecraft.class_7923;

public final class SimpleHolder<T> implements class_6880<T>, Supplier<T> {
    public static <T> SimpleHolder<T> create(class_5321<? extends class_2378<T>> registryKey, class_2960 valueId) {
        return SimpleHolder.create(class_5321.method_29179(registryKey, valueId));
    }

    public static <T> SimpleHolder<T> create(class_2960 registryId, class_2960 valueId) {
        return SimpleHolder.create(class_5321.method_29180(registryId), valueId);
    }

    public static <T> SimpleHolder<T> create(class_5321<T> key) {
        return new SimpleHolder<>(key);
    }

    private final class_5321<T> holderKey;
    private class_6880<T> holder = null;

    private SimpleHolder(class_5321<T> holderKey) {
        this.holderKey = holderKey;
    }

    private class_2378<T> getRegistry() {
        return (class_2378<T>) class_7923.field_41167.method_63535(this.holderKey.method_41185());
    }

    public void bind(boolean throwOnMissingRegistry) {
        if (this.holder != null) {
            return;
        }

        class_2378<T> registry = this.getRegistry();
        if (registry != null) {
            this.holder = registry.method_46746(this.holderKey).orElse(null);
        } else if (throwOnMissingRegistry) {
            throw new IllegalStateException("Registry not present for " + this + ": " + this.holderKey.method_41185());
        }
    }

    public class_2960 getIdentifier() {
        return this.holderKey.method_29177();
    }

    public class_5321<T> getHolderKey() {
        return this.holderKey;
    }

    @Override
    public T get() {
        return this.comp_349();
    }

    @Override
    public T comp_349() {
        this.bind(true);
        if (this.holder == null) {
            throw new NullPointerException("Trying to access unbound value: " + this.holderKey);
        }

        return (T) this.holder.comp_349();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return obj instanceof SimpleHolder<?> simpleHolder && simpleHolder.holderKey == this.holderKey;
    }

    @Override
    public int hashCode() {
        return this.holderKey.hashCode();
    }

    @Override
    public String toString() {
        return String.format(Locale.ENGLISH, "SimpleHolder{%s}", this.holderKey);
    }

    @Override
    public boolean method_40227() {
        this.bind(false);
        return this.holder != null && this.holder.method_40227();
    }

    @Override
    public boolean method_40226(class_2960 identifier) {
        return identifier.equals(this.holderKey.method_29177());
    }

    @Override
    public boolean method_40225(class_5321 resourceKey) {
        return resourceKey == this.holderKey;
    }

    @Override
    public boolean method_40224(Predicate<class_5321<T>> predicate) {
        return predicate.test(this.holderKey);
    }

    @Override
    public boolean method_55838(class_6880<T> holder) {
        this.bind(false);
        return this.holder != null && this.holder.method_55838(holder);
    }

    @Override
    public boolean method_40220(class_6862 tagKey) {
        this.bind(false);
        return this.holder != null && this.holder.method_40220(tagKey);
    }

    @Override
    public Stream<class_6862<T>> method_40228() {
        this.bind(false);
        return this.holder != null ? this.holder.method_40228() : Stream.empty();
    }

    @Override
    public Either<class_5321<T>, T> method_40229() {
        return Either.left(this.holderKey);
    }

    @Override
    public Optional<class_5321<T>> method_40230() {
        return Optional.of(this.holderKey);
    }

    @Override
    public class_6882 method_40231() {
        return class_6882.field_36446;
    }

    @Override
    public boolean method_46745(class_7876 holderOwner) {
        this.bind(false);
        return this.holder != null && this.holder.method_46745(holderOwner);
    }
}
