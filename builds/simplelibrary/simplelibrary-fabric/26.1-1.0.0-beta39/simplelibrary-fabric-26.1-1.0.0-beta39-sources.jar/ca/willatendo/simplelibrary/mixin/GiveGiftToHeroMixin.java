package ca.willatendo.simplelibrary.mixin;

import ca.willatendo.simplelibrary.server.data_maps.SimpleLibraryDataMaps;
import ca.willatendo.simplelibrary.server.data_maps.buillt_in.RaidHeroGift;
import net.minecraft.class_1646;
import net.minecraft.class_4243;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_4243.class)
public class GiveGiftToHeroMixin {
    @Inject(at = @At("HEAD"), method = "getLootTableToThrow", cancellable = true)
    private static void getLootTableToThrow(class_1646 villager, CallbackInfoReturnable<class_5321<class_52>> cir) {
        if (!villager.method_6109()) {
            RaidHeroGift raidHeroGift = (RaidHeroGift) villager.method_7231().comp_3521().getData(SimpleLibraryDataMaps.RAID_HERO_GIFTS);
            if (raidHeroGift != null) {
                cir.setReturnValue(raidHeroGift.lootTable());
            }
        }
    }
}
