package ca.willatendo.simplelibrary.server.conditions;

import ca.willatendo.simplelibrary.core.registry.SimpleLibraryBuiltInRegistries;
import ca.willatendo.simplelibrary.server.ServerLifecycleHooks;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.mojang.serialization.*;
import net.minecraft.class_3902;
import net.minecraft.class_5455;
import net.minecraft.class_6862;
import net.minecraft.class_6903;
import net.minecraft.class_7225;
import net.minecraft.class_7699;
import net.minecraft.class_7701;
import net.minecraft.server.MinecraftServer;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;

// Modified from Neoforge
public interface ICondition {
    Codec<ICondition> CODEC = SimpleLibraryBuiltInRegistries.CONDITION_SERIALIZERS.method_39673().dispatch(ICondition::codec, Function.identity());
    Codec<List<ICondition>> LIST_CODEC = CODEC.listOf();

    static <V, T> Optional<T> getConditionally(Codec<T> codec, DynamicOps<V> ops, V element) {
        return ICondition.getWithConditionalCodec(ConditionalOps.createConditionalCodec(codec), ops, element);
    }

    static <V, T> Optional<T> getWithConditionalCodec(Codec<Optional<T>> codec, DynamicOps<V> ops, V element) {
        return codec.parse(ops, element).getOrThrow(JsonParseException::new);
    }

    static <V, T> Optional<T> getWithWithConditionsCodec(Codec<Optional<WithConditions<T>>> codec, DynamicOps<V> ops, V elements) {
        return codec.parse(ops, elements).promotePartial((string) -> {
        }).getOrThrow(JsonParseException::new).map(WithConditions::carrier);
    }

    static <V> boolean conditionsMatched(DynamicOps<V> ops, V element) {
        final Codec<class_3902> codec = MapCodec.unitCodec(class_3902.field_17274);
        return ICondition.getConditionally(codec, ops, element).isPresent();
    }

    static void writeConditions(class_7225.class_7874 registries, JsonObject jsonObject, ICondition... conditions) {
        ICondition.writeConditions(registries, jsonObject, List.of(conditions));
    }

    static void writeConditions(class_7225.class_7874 registries, JsonObject jsonObject, List<ICondition> conditions) {
        ICondition.writeConditions(class_6903.method_46632(JsonOps.INSTANCE, registries), jsonObject, conditions);
    }

    static void writeConditions(DynamicOps<JsonElement> jsonOps, JsonObject jsonObject, List<ICondition> conditions) {
        if (!conditions.isEmpty()) {
            DataResult<JsonElement> result = LIST_CODEC.encodeStart(jsonOps, conditions);
            JsonElement serializedConditions = result.result().orElseThrow(() -> new RuntimeException("Failed to serialize conditions"));
            jsonObject.add(ConditionalOps.DEFAULT_CONDITIONS_KEY, serializedConditions);
        }
    }

    boolean test(IContext context);

    MapCodec<? extends ICondition> codec();

    interface IContext {
        IContext EMPTY = new IContext() {
            @Override
            public <T> boolean isTagLoaded(class_6862<T> key) {
                return false;
            }
        };

        IContext TAGS_INVALID = new IContext() {
            @Override
            public <T> boolean isTagLoaded(class_6862<T> key) {
                throw new UnsupportedOperationException("Usage of tag-based conditions is not permitted in this context!");
            }
        };

        <T> boolean isTagLoaded(class_6862<T> key);

        default class_5455 registryAccess() {
            return class_5455.field_40585;
        }

        default class_7699 enabledFeatures() {
            MinecraftServer minecraftServer = ServerLifecycleHooks.getCurrentServer();
            return minecraftServer == null ? class_7701.field_40182 : minecraftServer.method_27728().method_45560();
        }
    }
}
