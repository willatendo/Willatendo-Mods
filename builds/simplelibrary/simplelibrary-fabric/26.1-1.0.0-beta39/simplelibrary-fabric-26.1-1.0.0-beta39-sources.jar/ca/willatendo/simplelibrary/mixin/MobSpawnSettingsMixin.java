package ca.willatendo.simplelibrary.mixin;

import ca.willatendo.simplelibrary.injects.MobSpawnSettingsExtension;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Collections;
import java.util.Map;
import java.util.Set;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_5483;
import net.minecraft.class_6012;

@Mixin(class_5483.class)
public class MobSpawnSettingsMixin implements MobSpawnSettingsExtension {
    @Shadow
    @Final
    private Map<class_1311, class_6012<class_5483.class_1964>> spawners;
    @Shadow
    @Final
    private Map<class_1299<?>, class_5483.class_5265> mobSpawnCosts;
    private Set<class_1311> typesView;
    private Set<class_1299<?>> costView;

    @Inject(at = @At("TAIL"), method = "<init>")
    private void simpleLibrary_init(float creatureGenerationProbability, Map<class_1311, class_6012<class_5483.class_1964>> spawners, Map<class_1299<?>, class_5483.class_5265> mobSpawnCosts, CallbackInfo ci) {
        this.typesView = Collections.unmodifiableSet(this.spawners.keySet());
        this.costView = Collections.unmodifiableSet(this.mobSpawnCosts.keySet());
    }

    @Override
    public Set<class_1311> getSpawnerTypes() {
        return this.typesView;
    }

    @Override
    public Set<class_1299<?>> getEntityTypes() {
        return this.costView;
    }
}
