package ca.willatendo.simplelibrary.mixin;

import ca.willatendo.simplelibrary.server.event.LightingBoltEvent;
import com.llamalad7.mixinextras.injector.v2.WrapWithCondition;
import net.minecraft.class_1297;
import net.minecraft.class_1538;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_1538.class)
public class LightningBoltMixin {
    @WrapWithCondition(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Entity;thunderHit(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/world/entity/LightningBolt;)V"))
    private boolean simpleLibrary_lightningStrike(class_1297 entity, class_3218 serverLevel, class_1538 lightningBolt) {
        return LightingBoltEvent.ENTITY_STRUCK_BY_LIGHTING.invoker().onEntityStruckByLightning(entity, lightningBolt);
    }

}
