package ca.willatendo.simplelibrary.server.conditions;

import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_2378;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_6862;
import net.minecraft.class_7225;
import net.minecraft.class_7699;

public class ConditionContext implements ICondition.IContext {
    private final Map<class_5321<? extends class_2378<?>>, class_7225.class_7226<?>> pendingTags = new IdentityHashMap();
    private final class_7699 enabledFeatures;
    private final class_5455 registryAccess;

    public ConditionContext(List<class_2378.class_10106<?>> pendingTags, class_5455 registryAccess, class_7699 enabledFeatures) {
        this.registryAccess = registryAccess;
        this.enabledFeatures = enabledFeatures;

        for (class_2378.class_10106<?> tags : pendingTags) {
            this.pendingTags.put(tags.method_62693(), tags.method_62695());
        }
    }

    public void clear() {
        this.pendingTags.clear();
    }

    public <T> boolean isTagLoaded(class_6862<T> key) {
        class_7225.class_7226<?> lookup = this.pendingTags.get(key.comp_326());
        return lookup != null && lookup.method_46733((class_6862) key).isPresent();
    }

    public class_5455 registryAccess() {
        return this.registryAccess;
    }

    public class_7699 enabledFeatures() {
        return this.enabledFeatures;
    }
}
