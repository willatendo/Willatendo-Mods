package ca.willatendo.simplelibrary.server.biome_modifier;

import com.google.gson.JsonElement;
import com.mojang.serialization.DynamicOps;
import com.mojang.serialization.JsonOps;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.List;
import net.minecraft.class_1959;
import net.minecraft.class_4763;
import net.minecraft.class_5455;
import net.minecraft.class_5483;
import net.minecraft.class_5485;
import net.minecraft.class_6880;
import net.minecraft.class_6903;

// Modified from Neoforge
public final class ModifiableBiomeInfo {
    private static final Logger LOGGER = LogManager.getLogger(ModifiableBiomeInfo.class);

    private final BiomeInfo originalBiomeInfo;
    private BiomeInfo modifiedBiomeInfo = null;

    public ModifiableBiomeInfo(final BiomeInfo originalBiomeInfo) {
        this.originalBiomeInfo = originalBiomeInfo;
    }

    public BiomeInfo get() {
        return this.modifiedBiomeInfo == null ? this.originalBiomeInfo : this.modifiedBiomeInfo;
    }

    public BiomeInfo getOriginalBiomeInfo() {
        return this.originalBiomeInfo;
    }

    public BiomeInfo getModifiedBiomeInfo() {
        return this.modifiedBiomeInfo;
    }

    public boolean applyBiomeModifiers(final class_6880<class_1959> biome, final List<BiomeModifier> biomeModifiers, class_5455 registryAccess) {
        if (this.modifiedBiomeInfo != null) {
            LOGGER.info("Modified already exists");
            return true;
        }

        BiomeInfo original = this.getOriginalBiomeInfo();
        BiomeInfo.Builder builder = BiomeInfo.Builder.copyOf(original);
        for (BiomeModifier.Phase phase : BiomeModifier.Phase.values()) {
            for (BiomeModifier modifier : biomeModifiers) {
                modifier.modify(biome, phase, builder);
            }
        }
        DynamicOps<JsonElement> ops = class_6903.method_46632(JsonOps.INSTANCE, registryAccess);
        JsonElement originalJson = class_1959.field_26633.encodeStart(ops, biome.comp_349()).result().orElse(null);
        this.modifiedBiomeInfo = builder.build();
        JsonElement modifiedJson = class_1959.field_26633.encodeStart(ops, biome.comp_349()).result().orElse(null);
        if (originalJson == null || modifiedJson == null) {
            LOGGER.warn("Failed to determine whether biome {} was modified", biome);
            return true;
        }
        return !originalJson.equals(modifiedJson);
    }

    public record BiomeInfo(class_1959.class_5482 climateSettings, class_4763 effects, class_5485 generationSettings, class_5483 mobSpawnSettings) {
        public static final class Builder {
            private final ClimateSettingsBuilder climateSettings;
            private final BiomeSpecialEffectsBuilder effects;
            private final BiomeGenerationSettingsBuilder generationSettings;
            private final MobSpawnSettingsBuilder mobSpawnSettings;

            public static Builder copyOf(final BiomeInfo original) {
                final ClimateSettingsBuilder climateBuilder = ClimateSettingsBuilder.copyOf(original.climateSettings());
                final BiomeSpecialEffectsBuilder effectsBuilder = BiomeSpecialEffectsBuilder.copyOf(original.effects());
                final BiomeGenerationSettingsBuilder generationBuilder = new BiomeGenerationSettingsBuilder(original.generationSettings());
                final MobSpawnSettingsBuilder mobSpawnBuilder = new MobSpawnSettingsBuilder(original.mobSpawnSettings());

                return new Builder(climateBuilder, effectsBuilder, generationBuilder, mobSpawnBuilder);
            }

            private Builder(final ClimateSettingsBuilder climateSettings, final BiomeSpecialEffectsBuilder effects, final BiomeGenerationSettingsBuilder generationSettings, final MobSpawnSettingsBuilder mobSpawnSettings) {
                this.climateSettings = climateSettings;
                this.effects = effects;
                this.generationSettings = generationSettings;
                this.mobSpawnSettings = mobSpawnSettings;
            }

            public BiomeInfo build() {
                return new BiomeInfo(this.climateSettings.build(), this.effects.method_24391(), this.generationSettings.method_46671(), this.mobSpawnSettings.method_31007());
            }

            public ClimateSettingsBuilder getClimateSettings() {
                return this.climateSettings;
            }

            public BiomeSpecialEffectsBuilder getSpecialEffects() {
                return this.effects;
            }

            public BiomeGenerationSettingsBuilder getGenerationSettings() {
                return this.generationSettings;
            }

            public MobSpawnSettingsBuilder getMobSpawnSettings() {
                return this.mobSpawnSettings;
            }
        }
    }
}
