package ca.willatendo.simplelibrary.mixin;

import ca.willatendo.simplelibrary.injects.ServerRecipeBookExtension;
import ca.willatendo.simplelibrary.network.clientbound.ClientboundCustomRecipeBookSettingsPacket;
import ca.willatendo.simplelibrary.network.utils.NetworkUtils;
import ca.willatendo.simplelibrary.server.stats.CustomRecipeBookSettings;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.function.Predicate;
import net.minecraft.class_10266;
import net.minecraft.class_1860;
import net.minecraft.class_3222;
import net.minecraft.class_3439;
import net.minecraft.class_3441;
import net.minecraft.class_5321;

@Mixin(class_3441.class)
public class ServerRecipeBookMixin extends class_3439 implements ServerRecipeBookExtension {
    @Shadow
    @Final
    protected Set<class_5321<class_1860<?>>> known;
    @Shadow
    @Final
    protected Set<class_5321<class_1860<?>>> highlight;
    @Shadow
    @Final
    private class_3441.class_10271 displayResolver;

    @Override
    public void loadCustomUntrusted(CustomRecipeBookSettings customRecipeBookSettings, Predicate<class_5321<class_1860<?>>> predicate) {
        this.getCustomRecipeBookSettings().replaceFrom(customRecipeBookSettings);
    }

    @Inject(at = @At("HEAD"), method = "copyOverData")
    private void copyOverData(class_3441 serverRecipeBook, CallbackInfo ci) {
        this.getCustomRecipeBookSettings().replaceFrom(serverRecipeBook.getCustomRecipeBookSettings());
    }

    @Inject(at = @At("HEAD"), method = "sendInitialRecipeBook", cancellable = true)
    private void sendInitialRecipeBook(class_3222 serverPlayer, CallbackInfo ci) {
        NetworkUtils.sendToClient(serverPlayer, new ClientboundCustomRecipeBookSettingsPacket(this.field_25734.method_30178(), this.getCustomRecipeBookSettings().copy()));
        List<class_10266.class_10267> list = new ArrayList<>(this.known.size());

        for (class_5321<class_1860<?>> recipeResourceKey : this.known) {
            this.displayResolver.displaysForRecipe(recipeResourceKey, recipeDisplayEntry -> list.add(new class_10266.class_10267(recipeDisplayEntry, false, this.highlight.contains(recipeResourceKey))));
        }

        serverPlayer.field_13987.method_14364(new class_10266(list, true));
        ci.cancel();
    }
}
