package ca.willatendo.simplelibrary.mixin.client;

import ca.willatendo.simplelibrary.client.RecipeBookManager;
import ca.willatendo.simplelibrary.server.stats.utils.RecipeBookUtils;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import net.minecraft.class_10287;
import net.minecraft.class_10331;
import net.minecraft.class_1729;
import net.minecraft.class_299;
import net.minecraft.class_310;
import net.minecraft.class_507;
import net.minecraft.class_512;
import net.minecraft.class_5421;
import net.minecraft.class_5427;

@Mixin(class_507.class)
public class RecipeBookComponentMixin<T extends class_1729> {
    @Shadow
    @Final
    protected T menu;
    @Shadow
    protected class_310 minecraft;
    @Shadow
    @Final
    private List<class_512> tabButtons;
    @Shadow
    private int xOffset;
    @Shadow
    private int width;
    @Shadow
    private int height;
    @Shadow
    private class_299 book;

    @Inject(at = @At("HEAD"), method = "updateTabs", cancellable = true)
    private void updateTabs(boolean isFiltering, CallbackInfo ci) {
        int x = (this.width - 147) / 2 - this.xOffset - 30;
        int y = (this.height - 166) / 2 + 3;
        int i = 0;

        for (class_512 recipeBookTabButton : this.tabButtons) {
            class_10287 extendedRecipeBookCategory = recipeBookTabButton.method_2623();
            if (extendedRecipeBookCategory instanceof class_10331 || RecipeBookManager.getSearchCategories().containsKey(extendedRecipeBookCategory)) {
                recipeBookTabButton.field_22764 = true;
                recipeBookTabButton.method_48229(x, y + 27 * i++);
            } else if (recipeBookTabButton.method_2624(this.book)) {
                recipeBookTabButton.method_48229(x, y + 27 * i++);
                recipeBookTabButton.method_2622(this.book, isFiltering);
            }
        }
        ci.cancel();
    }

    @Inject(at = @At(value = "HEAD"), method = "sendUpdateSettings", cancellable = true)
    private void sendUpdateSettings(CallbackInfo ci) {
        if (this.minecraft.method_1562() != null) {
            class_5421 recipeBookType = this.menu.method_30264();
            if (RecipeBookUtils.isModded(recipeBookType)) {
                boolean isOpen = this.book.getCustomRecipeBookSettings().isOpen(recipeBookType);
                boolean isFiltering = this.book.getCustomRecipeBookSettings().isFiltering(recipeBookType);
                this.minecraft.method_1562().method_52787(new class_5427(recipeBookType, isOpen, isFiltering));
                ci.cancel();
            }
        }
    }
}
