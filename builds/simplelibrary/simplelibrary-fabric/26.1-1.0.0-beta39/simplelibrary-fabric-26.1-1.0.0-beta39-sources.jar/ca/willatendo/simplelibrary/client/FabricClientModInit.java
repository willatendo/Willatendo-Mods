package ca.willatendo.simplelibrary.client;

import ca.willatendo.simplelibrary.client.event.RegisterRecipeBookOverlayEvent;
import ca.willatendo.simplelibrary.client.event.SimpleScreenEvents;
import ca.willatendo.simplelibrary.network.PacketRegistryListener;
import ca.willatendo.simplelibrary.network.PacketSupplier;
import ca.willatendo.simplelibrary.server.event.RegisterTextureAtlasesEvent;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;
import net.fabricmc.fabric.api.client.particle.v1.ParticleRenderEvents;
import net.fabricmc.fabric.api.client.rendering.v1.ColorProviderRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.resource.v1.ResourceLoader;
import net.minecraft.class_10517;
import net.minecraft.class_11939;
import net.minecraft.class_11954;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_2394;
import net.minecraft.class_2396;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_3264;
import net.minecraft.class_339;
import net.minecraft.class_3929;
import net.minecraft.class_5614;
import net.minecraft.class_5616;
import net.minecraft.class_5617;
import net.minecraft.class_5619;
import net.minecraft.class_707;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import java.util.Arrays;
import java.util.List;

public record FabricClientModInit() implements ClientModInit {
    @Override
    public void clientEventListener(ClientEventListener clientEventListener) {
        clientEventListener.clientSetup();

        clientEventListener.registerBlockColors(ColorProviderRegistry.BLOCK::register);

        ResourceLoader resourceLoader = ResourceLoader.get(class_3264.field_14188);
        clientEventListener.registerClientReloadListener(resourceLoader::registerReloader);

        clientEventListener.registerKeyMappings(KeyBindingHelper::registerKeyBinding);

        clientEventListener.registerMenuScreens(class_3929::method_17542);

        clientEventListener.registerLayerDefinitions((modelLayerLocation, layerDefinition) -> EntityModelLayerRegistry.registerModelLayer(modelLayerLocation, layerDefinition::get));

        clientEventListener.registerRenderers(new ClientEventListener.RendererRegister() {
            @Override
            public <T extends class_1297> void apply(class_1299<? extends T> entityType, class_5617<T> entityRendererProvider) {
                class_5619.method_32173(entityType, entityRendererProvider);
            }

            @Override
            public <T extends class_2586, S extends class_11954> void apply(class_2591<? extends T> blockEntityType, class_5614<T, S> blockEntityRendererProvider) {
                class_5616.method_32144(blockEntityType, blockEntityRendererProvider);
            }
        });

        RegisterRecipeBookOverlayEvent.EVENT.register(biConsumer -> clientEventListener.registerRecipeBookOverlay(biConsumer::accept));

        clientEventListener.registerParticleColorExemptions(blocks -> Arrays.stream(blocks).forEach(block -> ParticleRenderEvents.ALLOW_BLOCK_DUST_TINT.register((blockState, clientLevel, blockPos) -> !blockState.method_27852(block))));

        clientEventListener.registerParticleProviders(new ClientEventListener.ParticleProviderRegister() {
            @Override
            public <T extends class_2394> void apply(class_2396<T> particleType, class_707<T> particleFactory) {
                ParticleFactoryRegistry.getInstance().register(particleType, particleFactory);
            }

            @Override
            public <T extends class_2394> void apply(class_2396<T> particleType, class_707.class_8187<T> sprite) {
                ParticleFactoryRegistry.getInstance().register(particleType, sprite::method_74291);
            }

            @Override
            public <T extends class_2394> void apply(class_2396<T> particleType, class_11939.class_4091<T> particleMetaFactory) {
                ParticleFactoryRegistry.getInstance().register(particleType, particleMetaFactory::create);
            }
        });

        clientEventListener.registerSpecialModelRenderers(class_10517.field_55453::method_65325);

        clientEventListener.registerTextureAtlases(atlasConfig -> RegisterTextureAtlasesEvent.EVENT.register(consumer -> consumer.accept(atlasConfig)));

        ClientTickEvents.START_CLIENT_TICK.register(clientEventListener::clientTickPreEvent);

        ClientTickEvents.END_CLIENT_TICK.register(clientEventListener::clientTickPostEvent);

        ScreenEvents.BEFORE_INIT.register((minecraft, screen, scaledWidth, scaledHeight) -> {
            ScreenEvents.beforeRender(screen).register((screenIn, guiGraphics, mouseX, mouseY, partialTick) -> clientEventListener.screenRenderPreEvent(screenIn, guiGraphics, mouseX, mouseY));
            List<class_339> widgets = Screens.getButtons(screen);
            clientEventListener.screenInitPreEvent(screen, widgets::add);
            ScreenEvents.afterRender(screen).register((screenIn, guiGraphics, mouseX, mouseY, partialTick) -> clientEventListener.screenRenderPostEvent(screenIn, guiGraphics, mouseX, mouseY));
        });

        ScreenEvents.AFTER_INIT.register((minecraft, screen, scaledWidth, scaledHeight) -> {
            List<class_339> widgets = Screens.getButtons(screen);
            clientEventListener.screenInitPostEvent(screen, widgets::add);
        });

        SimpleScreenEvents.CLOSING.register(clientEventListener::screenCloseEvent);

        ClientPlayConnectionEvents.DISCONNECT.register((clientPacketListener, minecraft) -> clientEventListener.clientPlayerLoggingOut());
    }

    @Override
    public void packetRegistryListener(PacketRegistryListener packetRegistryListener) {
        packetRegistryListener.registerClientboundPackets(new PacketRegistryListener.ClientboundPacketRegister() {
            @Override
            public <T extends class_8710> void apply(class_8710.class_9154<T> type, class_9139<? super class_9129, T> codec, PacketSupplier<T> packetSupplier) {
                PayloadTypeRegistry.playS2C().register(type, codec);

                ClientPlayNetworking.registerGlobalReceiver(type, (customPacketPayload, context) -> packetSupplier.handle(customPacketPayload, context.player()));
            }
        });
    }
}
