package ca.willatendo.simplelibrary.injects;

import java.util.Set;
import net.minecraft.class_1299;
import net.minecraft.class_1311;

public interface MobSpawnSettingsExtension {
    default Set<class_1311> getSpawnerTypes() {
        return Set.of();
    }

    default Set<class_1299<?>> getEntityTypes() {
        return Set.of();
    }
}
