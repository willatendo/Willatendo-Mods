package ca.willatendo.simplelibrary.client.filter;

import com.google.common.collect.ImmutableList;
import org.apache.commons.compress.utils.Lists;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_3532;
import net.minecraft.class_437;
import net.minecraft.class_481;

public final class CreativeModeTabFilter {
    public static final List<CreativeModeTabFilter> CREATIVE_MODE_TAB_FILTERS = Lists.newArrayList();
    private final class_1761 creativeModeTab;
    private final List<Filter> categories;
    private class_339 selectAllButton;
    private class_339 deselectAllButton;
    private class_339 scrollUpButton;
    private class_339 scrollDownButton;
    private class_1761 lastTab;
    private int guiLeft;
    private int guiTop;
    private int scroll;

    public static void create(class_1761 creativeModeTab, ImmutableList.Builder<Filter> categories) {
        CreativeModeTabFilter creativeModeTabFilter = new CreativeModeTabFilter(creativeModeTab, categories.build());
        CREATIVE_MODE_TAB_FILTERS.add(creativeModeTabFilter);
    }

    private CreativeModeTabFilter(class_1761 creativeModeTab, List<Filter> categories) {
        this.creativeModeTab = creativeModeTab;
        this.categories = categories;
    }

    public List<Filter> getCategories() {
        return this.categories;
    }

    public void modifyWidgetsEvent(class_437 screen, Consumer<class_339> addWidgets) {
        if (screen instanceof class_481 creativeModeInventoryScreen) {
            this.guiLeft = creativeModeInventoryScreen.field_2776;
            this.guiTop = creativeModeInventoryScreen.field_2800;
            this.categories.forEach(Filter::loadItems);
            this.injectWidgets(creativeModeInventoryScreen, addWidgets);
        }
    }

    public void closedEvent(class_437 screen) {
        if (screen instanceof class_481) {
            this.categories.forEach(category -> {
                this.scrollUpButton = null;
                this.scrollDownButton = null;
                category.setFilterButton(null);
            });
        }
    }

    public void beforeDrawEvent(class_437 screen, class_332 guiGraphics, int mouseX, int mouseY) {
        if (screen instanceof class_481 creativeModeInventoryScreen) {
            class_1761 selectedTab = class_481.field_2896;
            if (this.lastTab != selectedTab) {
                this.onSwitchCreativeTab(selectedTab, creativeModeInventoryScreen);
                this.lastTab = selectedTab;
            }
            this.drawFilterTabTooltips(guiGraphics, mouseX, mouseY);
        }
    }

    public void loggingOutEvent() {
        this.categories.forEach(category -> {
            category.resetItems();
            category.setEnabled(true);
        });
    }

    private void injectWidgets(class_481 creativeModeInventoryScreen, Consumer<class_339> addWidgets) {
        this.categories.forEach(category -> {
            FilterButton filterButton = new FilterButton(this.guiLeft - 28, this.guiTop, category, button -> {
                class_310 minecraft = class_310.method_1551();
                if (minecraft.method_74188() || minecraft.method_74187()) {
                    category.setEnabled(!category.isEnabled());
                } else {
                    this.categories.forEach(c -> c.setEnabled(false));
                    category.setEnabled(true);
                }
                this.updateItems(creativeModeInventoryScreen);
            });
            filterButton.field_22764 = false;
            addWidgets.accept(filterButton);
        });
        addWidgets.accept(this.selectAllButton = new FilterSelectButton(this, creativeModeInventoryScreen, this.guiLeft - 52, this.guiTop - 12, true));
        addWidgets.accept(this.deselectAllButton = new FilterSelectButton(this, creativeModeInventoryScreen, this.guiLeft - 52, this.guiTop + 13, false));
        addWidgets.accept(this.scrollUpButton = new ArrowButton(this.guiLeft - 22, this.guiTop - 12, true, btn -> {
            if (this.scroll > 0) {
                this.scroll--;
            }
            this.updateWidgets();
        }));
        addWidgets.accept(this.scrollDownButton = new ArrowButton(this.guiLeft - 22, this.guiTop + 127, false, btn -> {
            if (this.scroll <= this.categories.size() - 4 - 1) {
                this.scroll++;
            }
            this.updateWidgets();
        }));
        this.updateWidgets();
        this.onSwitchCreativeTab(class_481.field_2896, creativeModeInventoryScreen);
    }

    void updateItems(class_481 creativeModeInventoryScreen) {
        LinkedHashSet<class_1799> sortedItemStacks = new LinkedHashSet<>();
        this.creativeModeTab.method_47313().forEach(itemStack -> this.categories.stream().filter(Filter::isEnabled).forEach(category -> {
            if (itemStack.method_31573(category.getFilterTag())) {
                sortedItemStacks.add(itemStack.method_7972());
            }
        }));
        if (sortedItemStacks.isEmpty()) {
            sortedItemStacks.addAll(this.creativeModeTab.method_47313());
        }
        class_2371<class_1799> items = creativeModeInventoryScreen.method_17577().field_2897;
        items.clear();
        items.addAll(sortedItemStacks);
        creativeModeInventoryScreen.method_17577().method_2473(0);
    }

    private void updateWidgets() {
        this.categories.forEach(category -> category.setVisible(false));
        for (int scroll = this.scroll; scroll < this.scroll + 4 && scroll < this.categories.size(); scroll++) {
            Filter filter = this.categories.get(scroll);
            filter.setY(this.guiTop + 29 * (scroll - this.scroll) + 11);
            filter.setVisible(true);
        }
        this.scrollUpButton.field_22763 = this.scroll > 0;
        this.scrollDownButton.field_22763 = this.scroll <= this.categories.size() - 4 - 1;
    }

    private void onSwitchCreativeTab(class_1761 creativeModeTab, class_481 screen) {
        boolean update = creativeModeTab == this.creativeModeTab;
        this.selectAllButton.field_22764 = update;
        this.deselectAllButton.field_22764 = update;
        this.scrollUpButton.field_22764 = update;
        this.scrollDownButton.field_22764 = update;
        if (update) {
            this.updateWidgets();
            this.updateItems(screen);
            return;
        }
        this.categories.forEach(category -> category.setVisible(false));
    }

    public boolean onMouseScroll(double mouseX, double mouseY, double scroll) {
        class_1761 selectedTab = class_481.field_2896;
        if (selectedTab != this.creativeModeTab) {
            return false;
        }

        double startX = this.guiLeft - 28;
        double startY = this.guiTop + 29;
        if (mouseX >= startX && mouseX < startX + 28 && mouseY >= startY && mouseY < startY + 113) {
            int oldScroll = this.scroll;
            this.scroll += scroll > 0 ? -1 : 1;
            this.scroll = class_3532.method_15340(this.scroll, 0, this.categories.size() - 4);
            if (this.scroll != oldScroll) {
                this.updateWidgets();
            }
            return true;
        }
        return false;
    }

    private void drawFilterTabTooltips(class_332 guiGraphics, int mouseX, int mouseY) {
        for (Filter category : this.categories) {
            FilterButton filterButton = category.getFilterButton();
            if (filterButton != null && filterButton.field_22764 && filterButton.method_49606()) {
                guiGraphics.method_71276(filterButton.getFilterTooltip(), mouseX, mouseY);
                return;
            }
        }
    }
}
