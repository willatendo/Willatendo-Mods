package ca.willatendo.simplelibrary.server.recipe;

import net.minecraft.class_10289;

public final class SyncedRecipeData {
    private static class_10289 RECIPES = class_10289.field_54643;

    private SyncedRecipeData() {
    }

    public static void addRecipes(class_10289 recipes) {
        SyncedRecipeData.RECIPES = recipes;
    }

    public static class_10289 getRecipes() {
        return RECIPES;
    }
}
