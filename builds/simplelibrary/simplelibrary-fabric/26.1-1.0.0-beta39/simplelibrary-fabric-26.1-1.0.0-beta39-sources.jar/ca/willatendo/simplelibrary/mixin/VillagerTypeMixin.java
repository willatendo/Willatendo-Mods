package ca.willatendo.simplelibrary.mixin;

import ca.willatendo.simplelibrary.server.data_maps.SimpleLibraryDataMaps;
import ca.willatendo.simplelibrary.server.data_maps.buillt_in.BiomeVillagerType;
import net.minecraft.class_1959;
import net.minecraft.class_3854;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_3854.class)
public class VillagerTypeMixin {
    @Inject(at = @At("HEAD"), method = "byBiome", cancellable = true)
    private static void byBiome(class_6880<class_1959> holder, CallbackInfoReturnable<class_5321<class_3854>> cir) {
        BiomeVillagerType fromDataMap = (BiomeVillagerType) holder.getData(SimpleLibraryDataMaps.VILLAGER_TYPES);
        if (fromDataMap != null) {
            cir.setReturnValue(fromDataMap.type());
        }
    }
}
