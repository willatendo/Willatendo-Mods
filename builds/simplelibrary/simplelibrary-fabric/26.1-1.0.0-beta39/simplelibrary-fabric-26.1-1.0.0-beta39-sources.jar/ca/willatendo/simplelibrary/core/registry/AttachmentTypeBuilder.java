package ca.willatendo.simplelibrary.core.registry;

import com.mojang.serialization.Codec;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public final class AttachmentTypeBuilder<T> {
    private final T defaultValue;
    private Codec<T> codec;
    private boolean copyOnDeath = false;
    private class_9139<class_9129, T> streamCodec;

    public static <T> AttachmentTypeBuilder<T> builder(T defaultValue) {
        return new AttachmentTypeBuilder<>(defaultValue);
    }

    private AttachmentTypeBuilder(T defaultValue) {
        this.defaultValue = defaultValue;
    }

    public AttachmentTypeBuilder<T> serialize(Codec<T> codec) {
        this.codec = codec;
        return this;
    }

    public AttachmentTypeBuilder<T> copyOnDeath() {
        this.copyOnDeath = true;
        return this;
    }

    public AttachmentTypeBuilder<T> sync(class_9139<class_9129, T> streamCodec) {
        this.streamCodec = streamCodec;
        return this;
    }

    public T getDefaultValue() {
        return this.defaultValue;
    }

    public boolean doSerialize() {
        return this.codec != null;
    }

    public Codec<T> getCodec() {
        return this.codec;
    }

    public boolean doCopyOnDeath() {
        return this.copyOnDeath;
    }

    public boolean doSync() {
        return this.streamCodec != null;
    }

    public class_9139<class_9129, T> getStreamCodec() {
        return this.streamCodec;
    }
}
