package ca.willatendo.simplelibrary.server.conditions;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

// Modified from Neoforge
public record TagEmptyCondition<T>(class_6862<T> tag) implements ICondition {
    public static final MapCodec<TagEmptyCondition<?>> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(class_2960.field_25139.optionalFieldOf("registry", class_7924.field_41197.method_29177()).forGetter(condition -> condition.tag().comp_326().method_29177()), class_2960.field_25139.fieldOf("tag").forGetter(condition -> condition.tag().comp_327())).apply(instance, TagEmptyCondition::new));

    private TagEmptyCondition(class_2960 registryType, class_2960 tagName) {
        this(class_6862.method_40092(class_5321.method_29180(registryType), tagName));
    }

    @Override
    public boolean test(ICondition.IContext context) {
        return !context.isTagLoaded(this.tag);
    }

    @Override
    public MapCodec<? extends ICondition> codec() {
        return CODEC;
    }
}
